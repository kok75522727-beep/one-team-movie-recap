from datetime import datetime, timezone

import pytest

from membership import (
    CREDITS_FOR_BASE_VIDEO,
    MembershipError,
    VIP_TIERS,
    credit_balance,
    credits_for_duration,
    effective_plan,
    evaluate_export,
    myanmar_export_day,
    simple_trial_days_remaining,
    simple_trial_expired,
)
from media_engine import fitted_source_rect, srt_to_ass


def member(**overrides):
    return {"status": "active", "plan": "simple", "role": "member", "credit_balance": 0, **overrides}


def test_confirmed_vip_prices_and_daily_limits():
    assert [(tier["price"], tier["daily_limit"], tier["days"]) for tier in VIP_TIERS.values()] == [
        (25000, 2, 30), (45000, 4, 30), (99000, 8, 30),
    ]


def test_simple_and_vip_limits_are_checked_server_side():
    assert evaluate_export(member(), 180, 1).route == "simple"
    with pytest.raises(MembershipError, match="2 ပုဒ်"):
        evaluate_export(member(), 180, 2)
    creator = member(plan="pro", subscription_tier="creator")
    assert evaluate_export(creator, 180, 1).route == "vip"
    with pytest.raises(MembershipError, match="4 ပုဒ်"):
        evaluate_export(creator, 180, 4)


def test_credit_math_and_long_video_access_match_legacy_policy():
    assert credits_for_duration(180) == CREDITS_FOR_BASE_VIDEO == 6
    assert credits_for_duration(181) == 8
    assert credits_for_duration(300) == 10
    entitlement = evaluate_export(member(credit_balance=8), 181, 0)
    assert (entitlement.route, entitlement.credits_required) == ("credits", 8)
    with pytest.raises(MembershipError, match="30 မိနစ်"):
        evaluate_export(member(credit_balance=999), 1801, 0)


def test_expiry_and_myanmar_export_day():
    assert effective_plan(member(plan="pro", plan_expires_at="2025-01-01T00:00:00Z")) == "none"
    assert credit_balance(member(credit_balance=40, credit_expires_at="2025-01-01T00:00:00Z")) == 0
    assert myanmar_export_day(datetime(2026, 8, 26, 18, 0, tzinfo=timezone.utc)) == "2026-08-27"


def test_expired_simple_trial_cannot_use_credits_or_vip_route():
    expired = member(plan_expires_at="2025-01-01T00:00:00Z", credit_balance=999)
    assert simple_trial_expired(expired)
    with pytest.raises(MembershipError, match="Simple Trial 7 ရက်ကုန်"):
        evaluate_export(expired, 600, 0)
    entitlement = evaluate_export(member(credit_balance=8), 181, 0)
    assert (entitlement.route, entitlement.plan, entitlement.credits_required) == ("credits", "simple", 8)


def test_simple_trial_days_remaining_uses_stored_expiry():
    now = datetime(2026, 8, 27, 0, 0, tzinfo=timezone.utc)
    active = member(plan_expires_at="2026-09-02T01:00:00Z")
    assert simple_trial_days_remaining(active, now) == 7
    assert simple_trial_days_remaining(member(plan_expires_at="2026-08-26T23:59:00Z"), now) == 0


def test_letterboxed_output_uses_source_visible_rect_for_subtitle_position():
    rect = fitted_source_rect({"width": 1920, "height": 1080}, 720, 1280)
    assert rect == {"x": 0, "y": 437, "width": 720, "height": 405}
    ass = srt_to_ass("1\n00:00:00,000 --> 00:00:01,000\nHello", {"subtitle_x": 50, "subtitle_y": 50}, 720, 1280, rect)
    assert "\\pos(360,640)" in ass

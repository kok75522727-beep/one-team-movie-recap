"""Source-only checks that do not require a live Gemini key or FFmpeg render."""

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_browser_editor_keeps_drag_local_and_one_click_export() -> None:
    source = (ROOT / "static" / "editor.js").read_text(encoding="utf-8")
    assert "pointermove" in source
    assert "state.masks" in source
    assert "fetch('/api/jobs'" in source
    assert "setTimeout(pollJob, 1500)" in source
    assert "location.reload" not in source


def test_simple_key_remains_browser_session_only() -> None:
    source = (ROOT / "static" / "editor.js").read_text(encoding="utf-8")
    assert "sessionStorage.setItem('one-team-gemini-key'" in source
    assert "window.oneTeamSaveKey" in source
    assert "localStorage" not in source
    server = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "Simple Trial အတွက် ကိုယ့် Gemini API Key" in server
    assert "trial_days_remaining" in server
    assert 'if entitlement.plan == "simple"' in server
    engine = (ROOT / "media_engine.py").read_text(encoding="utf-8")
    assert 'TEXT_MODEL = "gemini-3.7-flash"' in engine
    assert 'TTS_MODEL = "gemini-3.1-flash-tts-preview"' in engine
    assert "generate_tts(api_key, script" in server
    assert "ONE_TEAM_VIP_GEMINI_API_KEY" in server


def test_voice_uses_the_supported_interactions_rest_contract() -> None:
    source = (ROOT / "media_engine.py").read_text(encoding="utf-8")
    for marker in ("v1beta/interactions", "gemini-3.1-flash-tts-preview", "Api-Revision", "output_audio", "payload.get(\"steps\")"):
        assert marker in source


def test_final_renderer_accepts_overlay_settings() -> None:
    source = (ROOT / "media_engine.py").read_text(encoding="utf-8")
    for marker in ("blur_masks", "subtitle_font", "subtitle_x", "subtitle_y", "logo_text", "logo_size", "logo_x", "logo_y", "fitted_source_rect", "auto_zoom", "background_blur", "music_volume"):
        assert marker in source


def test_all_original_control_tabs_remain_in_browser_payload() -> None:
    source = (ROOT / "static" / "editor.js").read_text(encoding="utf-8")
    for marker in ("aspect", "quality", "auto_zoom", "mirror", "color_filter", "background_blur", "pitch_alter", "original_audio", "logo_text", "voice"):
        assert marker in source


def test_voice_tab_is_automatic_movie_recap_voice_not_a_manual_tts_page() -> None:
    markup = (ROOT / "static" / "editor.html").read_text(encoding="utf-8")
    voice_page = markup.split('data-page="voice"', 1)[1].split("</div>", 1)[0]
    assert "စာရိုက်ပြီးအသံထုတ်စရာမလိုပါ" in voice_page
    assert "textarea" not in voice_page
    assert 'type="text"' not in voice_page


def test_editor_does_not_submit_a_client_selected_plan() -> None:
    source = (ROOT / "static" / "editor.js").read_text(encoding="utf-8")
    assert "plan: sessionStorage" not in source
    assert "relativePoint" in source
    assert "state.activeTab === 'blur'" in source
    server = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "MEMBERSHIP.member_from_token" in server
    assert "evaluate_export" in server
    assert "already" not in server  # source messages remain user-facing Burmese
    assert "existing.status in {\"queued\", \"running\"}" in server
    assert "job.status, job.message = \"cancelled\"" in server

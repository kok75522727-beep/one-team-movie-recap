# One Team Movie Recap — NiceGUI + FastAPI

This is the replacement source bundle for the former Streamlit editor. The video stays in the browser during routine editing, so changing a tab, slider, font, colour, subtitle position, or blur box does **not** reload the source video. The browser sends one final settings snapshot only when the member selects **Export Video**.

## Preserved One Team rules

| Area | Implemented rule |
|---|---|
| One Team identity | The existing One Team name, Burmese copy and dark mobile-first direction remain. The supplied reference was used only to inform interaction flow, not text, branding, colours, or design. |
| Simple Trial | A newly registered member receives **seven days** of Simple Trial access. Script and Gemini narration both use **only their own Gemini API key**. It is held in browser `sessionStorage`, submitted only for that export, and has no owner/VIP-key fallback. |
| VIP access | The server reads the verified member record from Supabase, not a browser-selected plan. VIP uses `ONE_TEAM_VIP_GEMINI_API_KEY`; the key is never returned to the browser. |
| VIP offers | Start: 25,000 MMK / 30 days / 2 final videos daily; Creator: 45,000 MMK / 30 days / 4 daily; Studio: 99,000 MMK / 30 days / 8 daily. |
| Credits | 3 minutes costs 6 credits; every additional started minute costs 2. Credit export maximum is 30 minutes. Credits and daily quota are recorded only after a successful final MP4. |
| AI models | Script: `gemini-3.7-flash`; automatic Movie Recap narration: `gemini-3.1-flash-tts-preview` through Gemini Interactions REST. There is no manual type-text-then-speak page. |
| Final render | FFmpeg creates the MP4 with the selected subtitle, blur masks, logo image/text, aspect ratio, zoom, mirror, colour, background blur, pitch, original audio and background music settings. |

## Project layout

| File or folder | Purpose |
|---|---|
| `main.py` | FastAPI/NiceGUI routes, upload endpoints, authenticated job lifecycle and progress API. |
| `membership.py` | Server-side Supabase membership lookup, plan/expiry, daily quota and success-only credit rules. |
| `media_engine.py` | Gemini script/TTS requests and FFmpeg final MP4 renderer. |
| `static/editor.html` | Browser editor markup. |
| `static/editor.js` | Local video object URL, touch drag/resize, visible-video coordinate geometry, account session, and one-click export. |
| `static/editor.css` | Responsive One Team dark UI and browser subtitle fonts. |
| `fonts/` | Bundled Myanmar and Latin fonts for browser preview and FFmpeg/libass output. Do not omit this folder. |
| `tests/` | Rules, browser contract and deterministic FFmpeg smoke tests. |

## Run locally

Install **FFmpeg** and **FFprobe** first. On Ubuntu:

```bash
sudo apt-get update
sudo apt-get install -y ffmpeg python3-venv
cd nicegui_one_team
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python main.py
```

Open `http://localhost:8080`. The server reads the `PORT` environment variable, so a hosting platform can supply its own port.

## Required production environment

Use the same Supabase project and `members` / `export_usage` / credit RPC schema from the legacy application. The values below must be configured as host secrets, never committed to GitHub or placed under `static/`.

```bash
# VIP/owner Gemini route only
export ONE_TEAM_VIP_GEMINI_API_KEY="..."

# Existing One Team membership data
export MEMBERSHIP_SUPABASE_URL="https://YOUR-PROJECT.supabase.co"
export MEMBERSHIP_SUPABASE_ANON_KEY="..."
export MEMBERSHIP_SUPABASE_SERVICE_KEY="..."

# The existing designated owner email for the secure owner route
export ONE_TEAM_ADMIN_EMAIL="owner@example.com"
```

The browser uses the Supabase **anon** key to sign in by Email/Password and gives its short-lived access token to this server. The server independently validates that token through Supabase, obtains the associated `members` record using the protected service key, and gives a new member a stored seven-day Simple Trial expiry. It calculates the effective plan and then enforces the limit. A request body field cannot make a Simple member VIP, and a credit balance cannot turn an expired Simple Trial into a VIP-key route.

> Before switching live traffic, run the legacy `supabase_membership_schema.sql` against the same Supabase project if it has not already been applied, and ensure the `consume_member_credits` RPC exists. Back up the database first.

## Export behavior

The editor shows only the feature currently being positioned: Subtitle when the Subtitle tab is active, blur masks when the Blur tab is active, and logo when the Logo tab is active. The enabled switches still decide what appears in the final MP4. Blur, subtitle, and logo positions are normalized against the actual visible video rectangle, not the surrounding letterbox area, to keep browser placement consistent with final rendering. The Voice tab sets the automatic recap voice, language, duration, and tone; users do not type a separate text-to-speech script.

Export is a background job. Its progress states are metadata check, Gemini Script, Gemini Voice, and FFmpeg render. Cancel marks the job as cancelled and prevents a completed file from being offered; a provider or FFmpeg process already in progress cannot be interrupted safely by a plain Python thread.

Gemini and FFmpeg work cannot be instantaneous. In particular, a user-owned Simple Trial key can legitimately return a Gemini `429` quota response. This source reports that provider failure and does **not** substitute the VIP/owner key. At the end of the seven-day trial, the member must renew or enter VIP; the service key is never used for an expired trial member.

## Test before deployment

```bash
python3 -m py_compile main.py media_engine.py membership.py tests/verify_media_render.py
python3 -m pytest -q tests
python3 tests/verify_media_render.py
```

The deterministic smoke test writes a temporary synthetic video and validates an H.264/AAC 9:16 output, blur, mixed Myanmar/English logo text, Myanmar font selection, subtitle placement, colour/mirror/zoom/background blur/pitch and audio mixing. It deliberately does not call Gemini. A real end-to-end Simple export requires a member account and a real Gemini key with active 3.1 TTS quota.

## Deployment notes

This app must run on a Python service that has FFmpeg and writable temporary/export storage. It cannot run on GitHub Pages or an Android PHP/HTML runner. The development bundle stores job state and uploads under `data/`, so use persistent disk for a single-process deployment. For multi-instance production, move `PROJECTS`, `JOBS`, uploads, and completed files to a shared database/object store before enabling autoscaling.

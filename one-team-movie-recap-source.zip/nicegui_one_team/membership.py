"""Server-side One Team membership, quota and credit enforcement.

This module intentionally accepts only a verified Supabase access token. The browser
never chooses a plan and cannot access the service-role key used for member data.
"""

from __future__ import annotations

import os
import math
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import quote

import requests


SIMPLE_MAX_SECONDS = 180
SIMPLE_DAILY_LIMIT = 2
SIMPLE_TRIAL_DAYS = 7
PAID_MAX_SECONDS = 180
CREDIT_MAX_SECONDS = 1800
CREDITS_FOR_BASE_VIDEO = 6
CREDIT_BASE_SECONDS = 180
CREDITS_PER_EXTRA_MINUTE = 2
VIP_TIERS = {
    "start": {"label": "One Start VIP", "price": 25000, "daily_limit": 2, "days": 30},
    "creator": {"label": "One Creator VIP", "price": 45000, "daily_limit": 4, "days": 30},
    "studio": {"label": "One Studio VIP", "price": 99000, "daily_limit": 8, "days": 30},
}


class MembershipError(RuntimeError):
    """A customer-facing access or membership configuration error."""


@dataclass(frozen=True)
class Entitlement:
    route: str  # simple, vip, credits, owner
    plan: str  # simple or pro for usage rows
    tier: str
    credits_required: int = 0


def _env(*names: str) -> str:
    for name in names:
        value = os.getenv(name, "").strip()
        if value:
            return value
    return ""


def myanmar_export_day(now: datetime | None = None) -> str:
    # Asia/Yangon has no daylight-saving transitions and stays UTC+06:30.
    return (now or datetime.now(timezone.utc)).astimezone(timezone(timedelta(hours=6, minutes=30))).date().isoformat()


def _parse_time(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(timezone.utc)
    except ValueError:
        return None


def effective_plan(member: dict[str, Any], now: datetime | None = None) -> str:
    if str(member.get("status") or "") != "active":
        return "none"
    plan = str(member.get("plan") or "none").lower()
    if plan not in {"simple", "pro"}:
        return "none"
    expiry = _parse_time(member.get("plan_expires_at"))
    if expiry and expiry <= (now or datetime.now(timezone.utc)):
        return "none"
    return plan


def simple_trial_expired(member: dict[str, Any], now: datetime | None = None) -> bool:
    """True only for a Simple membership whose explicitly stored trial has ended."""
    if str(member.get("plan") or "").lower() != "simple":
        return False
    expiry = _parse_time(member.get("plan_expires_at"))
    return bool(expiry and expiry <= (now or datetime.now(timezone.utc)))


def simple_trial_days_remaining(member: dict[str, Any], now: datetime | None = None) -> int:
    """Return the visible remaining whole days for an active seven-day Simple Trial."""
    if effective_plan(member, now) != "simple":
        return 0
    expiry = _parse_time(member.get("plan_expires_at"))
    if not expiry:
        return 0
    seconds = (expiry - (now or datetime.now(timezone.utc))).total_seconds()
    return max(0, math.ceil(seconds / 86400))


def credit_balance(member: dict[str, Any], now: datetime | None = None) -> int:
    if str(member.get("status") or "") != "active":
        return 0
    expiry = _parse_time(member.get("credit_expires_at"))
    if expiry and expiry <= (now or datetime.now(timezone.utc)):
        return 0
    try:
        return max(0, int(member.get("credit_balance") or 0))
    except (TypeError, ValueError):
        return 0


def credits_for_duration(duration_seconds: float) -> int:
    seconds = max(1, int(float(duration_seconds) + 0.999999))
    if seconds <= CREDIT_BASE_SECONDS:
        return CREDITS_FOR_BASE_VIDEO
    extra_minutes = int(((seconds - CREDIT_BASE_SECONDS) + 59) // 60)
    return CREDITS_FOR_BASE_VIDEO + extra_minutes * CREDITS_PER_EXTRA_MINUTE


def tier_for(member: dict[str, Any]) -> str:
    tier = str(member.get("subscription_tier") or "").lower()
    return tier if tier in VIP_TIERS else "start"


def is_owner(member: dict[str, Any]) -> bool:
    configured_email = _env("ONE_TEAM_ADMIN_EMAIL", "MEMBERSHIP_ADMIN_EMAIL").lower()
    email = str(member.get("email") or "").lower()
    return bool(configured_email and email and email == configured_email and str(member.get("role") or "") == "admin")


def evaluate_export(member: dict[str, Any], duration_seconds: float, successful_today: int) -> Entitlement:
    """Apply unchanged plan limits before any Gemini or FFmpeg work begins."""
    seconds = max(0.0, float(duration_seconds or 0))
    if seconds <= 0:
        raise MembershipError("Video duration မမှန်ပါ")
    if is_owner(member):
        return Entitlement("owner", "pro", "owner")
    if seconds > CREDIT_MAX_SECONDS:
        raise MembershipError("Credit Video က 30 မိနစ်အထိသာ ထုတ်လို့ရပါတယ်")
    plan = effective_plan(member)
    if plan == "none":
        if simple_trial_expired(member):
            raise MembershipError("Simple Trial 7 ရက်ကုန်သွားပါပြီ။ VIP ဝင်ပြီးမှ Video Export လုပ်ပါ")
        raise MembershipError("VIP သက်တမ်းကုန်သွားပါပြီ။ Admin ကိုဆက်သွယ်ပြီး Renew လုပ်ပါ")
    if plan == "simple":
        if successful_today >= SIMPLE_DAILY_LIMIT:
            raise MembershipError(f"Simple Trial ရဲ့ ဒီနေ့ Final Video {SIMPLE_DAILY_LIMIT} ပုဒ် ထုတ်ပြီးပါပြီ။ မနက်ဖြန်ပြန်ထုတ်ပါ")
        if seconds > SIMPLE_MAX_SECONDS:
            needed = credits_for_duration(seconds)
            balance = credit_balance(member)
            if balance < needed:
                raise MembershipError(f"ဒီ Video အတွက် {needed} Credits လိုပါတယ်။ လက်ကျန် {balance} Credits ပဲရှိပါတယ်")
            return Entitlement("credits", "simple", "simple", needed)
        return Entitlement("simple", "simple", "simple")
    if plan == "pro":
        tier = tier_for(member)
        limit = int(VIP_TIERS[tier]["daily_limit"])
        if successful_today >= limit:
            raise MembershipError(f"{VIP_TIERS[tier]['label']} ရဲ့ ဒီနေ့ {limit} ပုဒ် Limit ပြည့်သွားပါပြီ")
        if seconds > PAID_MAX_SECONDS:
            needed = credits_for_duration(seconds)
            balance = credit_balance(member)
            if balance < needed:
                raise MembershipError(f"ဒီ Video အတွက် {needed} Credits လိုပါတယ်။ လက်ကျန် {balance} Credits ပဲရှိပါတယ်")
            return Entitlement("credits", "pro", tier, needed)
        return Entitlement("vip", "pro", tier)
    raise MembershipError("Account plan မမှန်ပါ")


class SupabaseMembership:
    """Small REST adapter compatible with the existing One Team Supabase schema."""

    def __init__(self) -> None:
        self.url = _env("MEMBERSHIP_SUPABASE_URL", "SUPABASE_URL").rstrip("/")
        self.anon_key = _env("MEMBERSHIP_SUPABASE_ANON_KEY", "SUPABASE_ANON_KEY")
        self.service_key = _env("MEMBERSHIP_SUPABASE_SERVICE_KEY", "SUPABASE_SERVICE_KEY")

    @property
    def ready(self) -> bool:
        return bool(self.url and self.anon_key and self.service_key)

    def public_config(self) -> dict[str, str]:
        if not self.url or not self.anon_key:
            return {"enabled": "false"}
        return {"enabled": "true", "url": self.url, "anon_key": self.anon_key}

    def _service_headers(self, prefer: str = "") -> dict[str, str]:
        if not self.ready:
            raise MembershipError("Account Database setting မပြည့်သေးပါ။ Admin ကိုဆက်သွယ်ပါ")
        headers = {"apikey": self.service_key, "Authorization": f"Bearer {self.service_key}", "Content-Type": "application/json"}
        if prefer:
            headers["Prefer"] = prefer
        return headers

    def _request(self, method: str, path: str, *, headers: dict[str, str] | None = None, json: Any = None, timeout: int = 20) -> Any:
        try:
            response = requests.request(method, f"{self.url}{path}", headers=headers, json=json, timeout=(8, timeout))
        except requests.RequestException as exc:
            raise MembershipError("Account Database ကိုခဏမဆက်သွယ်နိုင်ပါ") from exc
        if not response.ok:
            raise MembershipError("Account Database စစ်ဆေးမရသေးပါ။ ခဏနောက်ပြန်စမ်းပါ")
        try:
            return response.json()
        except ValueError:
            return None

    def member_from_token(self, access_token: str) -> dict[str, Any]:
        if not self.ready:
            raise MembershipError("Account Database setting မပြည့်သေးပါ။ Admin ကိုဆက်သွယ်ပါ")
        token = str(access_token or "").strip()
        if not token:
            raise MembershipError("Account ဝင်ပြီးမှ Video Export လုပ်ပါ")
        identity = self._request("GET", "/auth/v1/user", headers={"apikey": self.anon_key, "Authorization": f"Bearer {token}"})
        if not isinstance(identity, dict) or not identity.get("email"):
            raise MembershipError("Account session မမှန်ပါ။ ပြန်ဝင်ပါ")
        email = str(identity["email"]).strip().lower()
        subject = str(identity.get("id") or "")
        found = self._request("GET", f"/rest/v1/members?select=*&email=eq.{quote(email, safe='')}&limit=1", headers=self._service_headers()) or []
        member = dict(found[0]) if found else None
        if member is None and subject:
            found = self._request("GET", f"/rest/v1/members?select=*&google_subject=eq.{quote(subject, safe='')}&limit=1", headers=self._service_headers()) or []
            member = dict(found[0]) if found else None
        if member is None:
            trial_expires_at = (datetime.now(timezone.utc) + timedelta(days=SIMPLE_TRIAL_DAYS)).isoformat()
            created = self._request("POST", "/rest/v1/members", headers=self._service_headers("return=representation"), json={
                "google_subject": subject, "email": email, "display_name": str((identity.get("user_metadata") or {}).get("display_name") or email.split("@", 1)[0]),
                "status": "active", "plan": "simple", "plan_expires_at": trial_expires_at, "role": "member",
            }) or []
            member = dict(created[0]) if created else None
        if member is None:
            raise MembershipError("Account ဖွင့်မရသေးပါ။ ခဏနောက်ပြန်ဝင်ပါ")
        member["effective_plan"] = "pro" if is_owner(member) else effective_plan(member)
        member["is_admin"] = is_owner(member)
        member["trial_days_remaining"] = simple_trial_days_remaining(member)
        member["trial_expired"] = simple_trial_expired(member)
        return member

    def successful_exports_today(self, member: dict[str, Any], plan: str) -> int:
        subject = quote(str(member.get("google_subject") or ""), safe="")
        if not subject:
            raise MembershipError("Account identity မမှန်ပါ။ ပြန်ဝင်ပါ")
        day = myanmar_export_day()
        rows = self._request("GET", f"/rest/v1/export_usage?select=id&google_subject=eq.{subject}&plan=eq.{quote(plan, safe='')}&outcome=eq.success&export_day=eq.{day}", headers=self._service_headers()) or []
        return len(rows)

    def record_success(self, member: dict[str, Any], entitlement: Entitlement, duration_seconds: float) -> None:
        subject = str(member.get("google_subject") or "")
        if not subject:
            raise MembershipError("Account identity မမှန်ပါ။ ပြန်ဝင်ပါ")
        if entitlement.route == "credits":
            result = self._request("POST", "/rest/v1/rpc/consume_member_credits", headers=self._service_headers(), json={
                "p_google_subject": subject, "p_credits": entitlement.credits_required,
                "p_note": f"Successful {round(duration_seconds)} second credit export",
            })
            if not result:
                raise MembershipError("Credits ဖြတ်မရသေးပါ။ Final Video ကိုမသိမ်းပါ")
        if entitlement.route == "owner":
            return
        self._request("POST", "/rest/v1/export_usage", headers=self._service_headers(), json={
            "google_subject": subject, "plan": entitlement.plan, "subscription_tier": entitlement.tier,
            "export_day": myanmar_export_day(), "source_duration_seconds": round(float(duration_seconds), 2), "outcome": "success",
        })

    def record_failure(self, member: dict[str, Any], duration_seconds: float, entitlement: Entitlement | None = None) -> None:
        if not self.ready or not member.get("google_subject"):
            return
        try:
            self._request("POST", "/rest/v1/export_usage", headers=self._service_headers(), json={
                "google_subject": str(member["google_subject"]), "plan": entitlement.plan if entitlement else effective_plan(member),
                "subscription_tier": entitlement.tier if entitlement else tier_for(member), "export_day": myanmar_export_day(),
                "source_duration_seconds": round(float(duration_seconds), 2), "outcome": "failed",
            })
        except MembershipError:
            pass

from __future__ import annotations

import shutil
import subprocess
import tempfile
from pathlib import Path

from media_engine import prepare_analysis_video, probe_video

folder = Path(tempfile.mkdtemp(prefix="one-team-analysis-check-"))
source = folder / "source.mp4"
try:
    subprocess.run([
        "ffmpeg", "-y", "-f", "lavfi", "-i", "testsrc2=size=320x240:rate=8",
        "-t", "65", "-c:v", "libx264", "-pix_fmt", "yuv420p", str(source),
    ], check=True, capture_output=True, text=True)
    proxy, cleanup = prepare_analysis_video(source)
    assert cleanup == proxy
    assert proxy.exists()
    proxy_duration = float(probe_video(proxy)["duration"])
    assert 63.0 <= proxy_duration <= 67.0
    print(f"full-duration analysis proxy passed: {proxy_duration:.1f}s")
finally:
    shutil.rmtree(folder, ignore_errors=True)

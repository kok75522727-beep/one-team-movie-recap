"""Server-enforced One Team memberships and manual-payment workflow."""

from __future__ import annotations

import math
import os
import re
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import PurePosixPath
from typing import Any
from urllib.parse import quote

import requests

SIMPLE_MAX_SECONDS = 360  
SIMPLE_TRIAL_DAILY_LIMIT = 2
SIMPLE_TRIAL_DAYS = 3
PAID_MAX_SECONDS = 360  
CREDIT_MAX_SECONDS = 1800  

VIP_TIERS = {
    "silver_vip": {
        "label": "Silver VIP",
        "price": 15000,
        "daily_limit": 2,
        "days": 30,
        "key_mode": "user",
        "description": "၆ မိနစ်အထိ Video တစ်နေ့ ၂ ပုဒ် (တစ်လ အပုဒ် ၆၀) · 100% Error Refund အာမခံ",
    },
    "gold_vip": {
        "label": "Gold VIP",
        "price": 30000,
        "daily_limit": 4,
        "days": 30,
        "key_mode": "user",
        "description": "၆ မိနစ်အထိ Video တစ်နေ့ ၄ ပုဒ် (တစ်လ အပုဒ် ၁၂၀) · VIP Full Warranty အာမခံ",
    },
}

CREDIT_PACKS: dict[str, dict[str, int]] = {
    "credit_starter": {"label": "Starter Credit", "price": 5000, "credits": 25, "days": 60, "description": "25 Credits (မိနစ် ၃၀ အထိ Video များ စိတ်ကြိုက် ထုတ်လုပ်နိုင်သည်)"},
    "credit_popular": {"label": "Popular Credit", "price": 10000, "credits": 55, "days": 90, "description": "55 Credits (မိနစ် ၃၀ အထိ Video များ စိတ်ကြိုက် ထုတ်လုပ်နိုင်သည်)"},
    "credit_pro": {"label": "Pro Credit", "price": 20000, "credits": 120, "days": 120, "description": "120 Credits (မိနစ် ၃၀ အထိ Video များ စိတ်ကြိုက် ထုတ်လုပ်နိုင်သည်)"},
}

DEFAULT_PAYMENT_DESTINATIONS = {
    "KBZPay": {"phone": "09670132806", "account_name": "Nay Lin Aung"},
    "WavePay": {"phone": "09670132806", "account_name": "Nay Lin Aung"},
}
PAYMENT_RECEIPT_BUCKET = "payment-receipts"
MAX_PAYMENT_RECEIPT_BYTES = 5 * 1024 * 1024
ALLOWED_RECEIPT_TYPES = {"image/jpeg": "jpg", "image/png": "png", "image/webp": "webp"}

class MembershipError(RuntimeError):
    pass

@dataclass(frozen=True)
class Entitlement:
    route: str  
    plan: str  
    tier: str
    key_mode: str  
    credits_required: int = 0

def _env(*names: str) -> str:
    for name in names:
        value = os.getenv(name, "").strip()
        if value:
            return value
    return ""

def myanmar_export_day(now: datetime | None = None) -> str:
    return (now or datetime.now(timezone.utc)).astimezone(timezone(timedelta(hours=6, minutes=30))).date().isoformat()

def _parse_time(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).astimezone(timezone.utc)
    except ValueError:
        return None

def effective_plan(member: dict[str, Any], now: datetime | None = None) -> str:
    if str(member.get("status") or "") != "active":
        return "none"
    plan = str(member.get("plan") or "none").lower()
    if plan not in {"simple", "pro"}:
        return "none"
    expiry = _parse_time(member.get("plan_expires_at"))
    if expiry and expiry <= (now or datetime.now(timezone.utc)):
        return "none"
    return plan

def credit_balance(member: dict[str, Any], now: datetime | None = None) -> int:
    if str(member.get("status") or "") != "active":
        return 0
    expiry = _parse_time(member.get("credit_expires_at"))
    if expiry and expiry <= (now or datetime.now(timezone.utc)):
        return 0
    try:
        return max(0, int(member.get("credit_balance") or 0))
    except (TypeError, ValueError):
        return 0

def credits_for_duration(duration_seconds: float) -> int:
    return max(1, math.ceil(duration_seconds / 60))

def is_owner(member: dict[str, Any]) -> bool:
    configured_email = _env("ONE_TEAM_ADMIN_EMAIL", "MEMBERSHIP_ADMIN_EMAIL").lower()
    email = str(member.get("email") or "").lower()
    return bool(configured_email and email and email == configured_email and str(member.get("role") or "") == "admin")

def evaluate_export(member: dict[str, Any], duration_seconds: float, successful_today: int) -> Entitlement:
    seconds = max(0.0, float(duration_seconds or 0))
    if seconds <= 0:
        raise MembershipError("Video duration မမှန်ပါ")
    if is_owner(member):
        return Entitlement("owner", "pro", "owner", "user")
    
    plan = effective_plan(member)
    credits_needed = credits_for_duration(seconds)
    current_credits = credit_balance(member)

    # ၆ မိနစ် (၃၆၀ စက္ကန့်) ထက်ကျော်ပါက VIP အခွင့်အရေးကို လုံးဝမသုံးဘဲ Credit သာ စစ်ဆေးမည်
    if seconds > PAID_MAX_SECONDS:
        if current_credits >= credits_needed:
            if seconds > CREDIT_MAX_SECONDS:
                raise MembershipError("Credit ဖြင့် တစ်ကြိမ်လျှင် အများဆုံး မိနစ် ၃၀ (၁,၈၀၀ စက္ကန့်) အထိသာ ထုတ်နိုင်ပါသည်။")
            return Entitlement("credits", "credits", "credit_user", "user", credits_required=credits_needed)
        else:
            raise MembershipError("၆ မိနစ်ထက်ကျော်လွန်သော Video များအတွက် Credit လိုအပ်ပါသည်။ သင်၏ Credit လက်ကျန် မလုံလောက်ပါ။")

    # ၆ မိနစ်အောက်ဖြစ်ပါက VIP အပုဒ်ရေ အရင်စစ်မည်
    if plan == "pro":
        tier = str(member.get("subscription_tier") or "silver_vip").lower()
        offer = VIP_TIERS.get(tier, VIP_TIERS["silver_vip"])
        
        # VIP အပုဒ်ရေ မပြည့်သေးလျှင် VIP စနစ်ဖြင့်ပေးမည်
        if successful_today < int(offer["daily_limit"]):
            return Entitlement("user_key", "pro", tier, "user")
        
        # VIP အပုဒ်ရေ ပြည့်သွားပါက Credit ဆက်စစ်မည်
        if current_credits >= credits_needed:
            return Entitlement("credits", "credits", "credit_user", "user", credits_required=credits_needed)
        else:
            raise MembershipError(f"ယနေ့အတွက် {offer['label']} ၏ နေ့စဉ် ကန့်သတ်ချက် ပြည့်သွားပါပြီ။ ဆက်လက်ထုတ်လုပ်ရန် Credit လိုအပ်ပါသည်။")
            
    if plan == "simple":
        if successful_today >= SIMPLE_TRIAL_DAILY_LIMIT:
            raise MembershipError("ယနေ့အတွက် Trial ကန့်သတ်ချက် ပြည့်သွားပါပြီ။ Plan သို့မဟုတ် Credit ဝယ်ယူပါ။")
        return Entitlement("trial", "simple", "trial", "user")
        
    # Plan မရှိသူဖြစ်ပါက Credit ဖြင့်သာ သုံးခွင့်ပေးမည်
    if current_credits >= credits_needed:
        return Entitlement("credits", "credits", "credit_user", "user", credits_required=credits_needed)
        
    raise MembershipError("Plan သက်တမ်းကုန်သွားပါပြီ (သို့) Credit မလုံလောက်ပါ။ ဝယ်ယူအားပေးပါ။")

class SupabaseMembership:
    def __init__(self) -> None:
        self.url = _env("MEMBERSHIP_SUPABASE_URL", "SUPABASE_URL").rstrip("/")
        self.anon_key = _env("MEMBERSHIP_SUPABASE_ANON_KEY", "SUPABASE_ANON_KEY")
        self.service_key = _env("MEMBERSHIP_SUPABASE_SERVICE_KEY", "SUPABASE_SERVICE_KEY", "SUPABASE_SERVICE_ROLE_KEY")

    @property
    def ready(self) -> bool:
        return bool(self.url and self.anon_key and self.service_key)

    def public_config(self) -> dict[str, str]:
        return {"enabled": "true", "url": self.url, "anon_key": self.anon_key} if self.url and self.anon_key else {"enabled": "false"}

    def public_payment_info(self) -> dict[str, Any]:
        plans = [{"key": k, "label": v["label"], "price": v["price"], "description": v["description"], "kind": "plan"} for k, v in VIP_TIERS.items()]
        credits = [{"key": k, "label": v["label"], "price": v["price"], "description": v["description"], "kind": "credits"} for k, v in CREDIT_PACKS.items()]
        return {"plans": plans, "credit_packs": credits, "destinations": self.payment_destinations()}

    def payment_destinations(self) -> dict[str, dict[str, str]]:
        result: dict[str, dict[str, str]] = {}
        for method, defaults in DEFAULT_PAYMENT_DESTINATIONS.items():
            prefix = "ONE_TEAM_KBZPAY" if method == "KBZPay" else "ONE_TEAM_WAVEPAY"
            result[method] = {
                "phone": _env(f"{prefix}_PHONE") or str(defaults["phone"]),
                "account_name": _env(f"{prefix}_ACCOUNT_NAME") or str(defaults["account_name"]),
            }
        return result

    def _service_headers(self, prefer: str = "") -> dict[str, str]:
        headers = {"apikey": self.service_key, "Authorization": f"Bearer {self.service_key}", "Content-Type": "application/json"}
        if prefer: headers["Prefer"] = prefer
        return headers

    def _request(self, method: str, path: str, *, headers: dict[str, str] | None = None, json: Any = None) -> Any:
        try:
            res = requests.request(method, f"{self.url}{path}", headers=headers, json=json, timeout=(8, 20))
            return res.json() if res.ok else None
        except Exception:
            return None

    def member_from_token(self, access_token: str) -> dict[str, Any]:
        token = str(access_token or "").strip()
        identity = self._request("GET", "/auth/v1/user", headers={"apikey": self.anon_key, "Authorization": f"Bearer {token}"})
        if not isinstance(identity, dict) or not identity.get("email"):
            raise MembershipError("Account session မမှန်ပါ။ ပြန်ဝင်ပါ")
        email = str(identity["email"]).strip().lower()
        subject = str(identity.get("id") or "")
        found = self._request("GET", f"/rest/v1/members?select=*&email=eq.{quote(email, safe='')}&limit=1", headers=self._service_headers()) or []
        member = dict(found[0]) if found else None
        if member is None:
            trial_expires_at = (datetime.now(timezone.utc) + timedelta(days=SIMPLE_TRIAL_DAYS)).isoformat()
            created = self._request("POST", "/rest/v1/members", headers=self._service_headers("return=representation"), json={
                "google_subject": subject, "email": email, "display_name": email.split("@", 1)[0],
                "status": "active", "plan": "simple", "subscription_tier": "trial", "plan_expires_at": trial_expires_at, "role": "member"
            }) or []
            member = dict(created[0]) if created else None
        
        member["effective_plan"] = "pro" if is_owner(member) else effective_plan(member)
        member["is_admin"] = is_owner(member)
        member["credit_balance"] = credit_balance(member)
        expiry = _parse_time(member.get("plan_expires_at"))
        member["trial_days_remaining"] = max(0, math.ceil((expiry - datetime.now(timezone.utc)).total_seconds() / 86400)) if expiry else 0
        return member

    def successful_exports_today(self, member: dict[str, Any], plan: str) -> int:
        subject = quote(str(member.get("google_subject") or ""), safe="")
        day = myanmar_export_day()
        rows = self._request("GET", f"/rest/v1/export_usage?select=id&google_subject=eq.{subject}&plan=eq.{quote(plan, safe='')}&outcome=eq.success&export_day=eq.{day}", headers=self._service_headers()) or []
        return len(rows)

    def record_success(self, member: dict[str, Any], entitlement: Entitlement, duration_seconds: float) -> None:
        subject = str(member.get("google_subject") or "")
        if entitlement.route == "credits":
            self._request("POST", "/rest/v1/rpc/consume_member_credits", headers=self._service_headers(), json={
                "p_google_subject": subject, "p_credits": entitlement.credits_required, "p_note": f"Export {round(duration_seconds)}s"
            })
        if entitlement.route != "owner":
            self._request("POST", "/rest/v1/export_usage", headers=self._service_headers(), json={
                "google_subject": subject, "plan": entitlement.plan, "subscription_tier": entitlement.tier,
                "export_day": myanmar_export_day(), "source_duration_seconds": round(float(duration_seconds), 2), "outcome": "success"
            })

    def record_failure(self, member: dict[str, Any], duration_seconds: float, entitlement: Entitlement | None = None) -> None:
        subject = str(member.get("google_subject") or "")
        if entitlement and entitlement.route != "owner":
            self._request("POST", "/rest/v1/export_usage", headers=self._service_headers(), json={
                "google_subject": subject, "plan": entitlement.plan, "subscription_tier": entitlement.tier,
                "export_day": myanmar_export_day(), "source_duration_seconds": round(float(duration_seconds), 2), "outcome": "failed"
            })

    def create_payment_request(self, member: dict[str, Any], *, kind: str, offer_key: str, payment_method: str, transaction_id: str, receipt: bytes = b"", receipt_mime: str = "") -> dict[str, Any]:
        subject = str(member.get("google_subject") or "")
        offer = VIP_TIERS.get(offer_key) if kind == "plan" else CREDIT_PACKS.get(offer_key)
        if not offer: raise MembershipError("ရွေးထားသော Plan/Credit မမှန်ပါ")
        row = {
            "google_subject": subject, "plan": "pro" if kind == "plan" else "credits", "request_kind": kind,
            "requested_tier": offer_key, "requested_credits": int(offer.get("credits", 0)), "amount_mmk": int(offer["price"]),
            "payment_method": payment_method, "transaction_id": transaction_id, "status": "submitted"
        }
        created = self._request("POST", "/rest/v1/payment_requests", headers=self._service_headers("return=representation"), json=row) or []
        return dict(created[0])

    def owner_overview(self) -> dict[str, Any]:
        now = datetime.now(timezone.utc)
        members = self._request("GET", "/rest/v1/members?select=*", headers=self._service_headers()) or []
        pending = self._request("GET", "/rest/v1/payment_requests?select=*&status=eq.submitted&order=submitted_at.asc", headers=self._service_headers()) or []
        exports = self._request("GET", "/rest/v1/export_usage?select=outcome", headers=self._service_headers()) or []
        
        return {
            "active_vip_count": len([m for m in members if effective_plan(m, now) == "pro"]),
            "active_simple_count": len([m for m in members if effective_plan(m, now) == "simple"]),
            "pending_payment_count": len(pending),
            "success_exports": sum(1 for e in exports if e.get("outcome") == "success"),
            "fail_exports": sum(1 for e in exports if e.get("outcome") != "success"),
            "members": members,
            "payments": pending,
        }

    def approve_payment(self, request_id: int, actor: str, note: str = "") -> bool:
        payment = self._request("GET", f"/rest/v1/payment_requests?select=*&id=eq.{int(request_id)}&limit=1", headers=self._service_headers()) or []
        if not payment: raise MembershipError("Payment မတွေ့ပါ")
        p = payment[0]
        subject = str(p["google_subject"])
        now = datetime.now(timezone.utc)
        if p["request_kind"] == "credits":
            credits = int(p["requested_credits"])
            exp = (now + timedelta(days=90)).isoformat()
            self._request("POST", "/rest/v1/rpc/grant_member_credits", headers=self._service_headers(), json={
                "p_google_subject": subject, "p_credits": credits, "p_credit_expires_at": exp, "p_payment_id": int(request_id), "p_note": "Owner Approval"
            })
        else:
            tier = str(p["requested_tier"])
            offer = VIP_TIERS.get(tier, VIP_TIERS["silver_vip"])
            self._request("PATCH", f"/rest/v1/members?google_subject=eq.{quote(subject, safe='')}", headers=self._service_headers(), json={
                "status": "active", "plan": "pro", "subscription_tier": tier,
                "plan_expires_at": (now + timedelta(days=int(offer["days"]))).isoformat(), "admin_note": note or offer["label"]
            })
        self._request("PATCH", f"/rest/v1/payment_requests?id=eq.{int(request_id)}", headers=self._service_headers(), json={"status": "approved", "reviewed_at": now.isoformat(), "reviewed_by": actor})
        return True

    def reject_payment(self, request_id: int, actor: str, note: str = "") -> bool:
        self._request("PATCH", f"/rest/v1/payment_requests?id=eq.{int(request_id)}", headers=self._service_headers(), json={"status": "rejected", "reviewed_at": datetime.now(timezone.utc).isoformat(), "reviewed_by": actor})
        return True

    def grant_manual_credits(self, email: str, credits: int, actor: str, note: str = "") -> bool:
        found = self._request("GET", f"/rest/v1/members?select=*&email=eq.{quote(email.strip().lower(), safe='')}&limit=1", headers=self._service_headers()) or []
        if not found:
            raise MembershipError("User email ရှာမတွေ့ပါ")
        subject = str(found[0]["google_subject"])
        now = datetime.now(timezone.utc)
        exp = (now + timedelta(days=90)).isoformat()
        self._request("POST", "/rest/v1/rpc/grant_member_credits", headers=self._service_headers(), json={
            "p_google_subject": subject, "p_credits": int(credits), "p_credit_expires_at": exp, "p_note": note or f"Manual Grant by {actor}"
        })
        return True

    def extend_user_plan(self, email: str, add_days: int, actor: str) -> bool:
        found = self._request("GET", f"/rest/v1/members?select=*&email=eq.{quote(email.strip().lower(), safe='')}&limit=1", headers=self._service_headers()) or []
        if not found:
            raise MembershipError("User email ရှာမတွေ့ပါ")
        member = found[0]
        subject = str(member["google_subject"])
        
        current_expiry = _parse_time(member.get("plan_expires_at"))
        now = datetime.now(timezone.utc)
        if not current_expiry or current_expiry < now:
            new_expiry = now + timedelta(days=add_days)
        else:
            new_expiry = current_expiry + timedelta(days=add_days)
            
        self._request("PATCH", f"/rest/v1/members?google_subject=eq.{quote(subject, safe='')}", headers=self._service_headers(), json={
            "plan_expires_at": new_expiry.isoformat(),
            "admin_note": f"Extended {add_days} days by {actor}"
        })
        return True

    # VIP များ Error ဖြစ်၍ အပုဒ်ရေ ပြန်လျော်ပေးသည့်စနစ်
    def refund_daily_count(self, email: str, count: int, actor: str) -> bool:
        found = self._request("GET", f"/rest/v1/members?select=*&email=eq.{quote(email.strip().lower(), safe='')}&limit=1", headers=self._service_headers()) or []
        if not found:
            raise MembershipError("User email ရှာမတွေ့ပါ")
        subject = str(found[0]["google_subject"])
        day = myanmar_export_day()
        
        # ယနေ့အသုံးပြုထားသော မှတ်တမ်းများကို ခေါ်ယူပြီး သတ်မှတ်ထားသော အရေအတွက်အတိုင်း "refunded" သို့ ပြောင်းလဲခြင်း
        exports = self._request("GET", f"/rest/v1/export_usage?select=id&google_subject=eq.{subject}&outcome=eq.success&export_day=eq.{day}&limit={count}", headers=self._service_headers()) or []
        if not exports:
            raise MembershipError("ယနေ့အတွက် ပြန်လျော်ပေးရန် Video မှတ်တမ်း မရှိပါ။")
            
        for exp in exports:
            self._request("PATCH", f"/rest/v1/export_usage?id=eq.{exp['id']}", headers=self._service_headers(), json={
                "outcome": "refunded"
            })
        return True

    def bulk_repair_vip(self, repair_days: int, actor: str) -> int:
        return 0
"""FastAPI server for One Team Movie Recap Studio."""

from __future__ import annotations

import os
import uuid
import shutil
from pathlib import Path
from typing import Any, Optional
from datetime import datetime, timezone

from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Header, Body
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import media_engine

app = FastAPI(title="One Team Movie Recap Studio")

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
UPLOAD_DIR = ROOT / "uploads"
OUTPUT_DIR = ROOT / "outputs"
FONTS_DIR = ROOT / "fonts"

for folder in [STATIC_DIR, UPLOAD_DIR, OUTPUT_DIR, FONTS_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/fonts", StaticFiles(directory=str(FONTS_DIR)), name="fonts")

JOBS: dict[str, dict[str, Any]] = {}
PROJECTS: dict[str, dict[str, Any]] = {}
DAILY_EXPORTS: dict[str, list[str]] = {}

class JobSettings(BaseModel):
    project_id: str
    settings: dict[str, Any]
    simple_api_key: Optional[str] = ""

# --- Pages ---
@app.get("/")
async def serve_index():
    return FileResponse(STATIC_DIR / "editor.html")

@app.get("/login")
async def serve_login():
    login_file = STATIC_DIR / "login.html"
    return FileResponse(login_file if login_file.exists() else STATIC_DIR / "editor.html")

@app.get("/owner")
async def serve_owner():
    owner_file = STATIC_DIR / "owner.html"
    return FileResponse(owner_file if owner_file.exists() else STATIC_DIR / "editor.html")

# --- Auth, Owner & Config APIs ---
@app.get("/api/auth-config")
async def get_auth_config():
    return {
        "enabled": "false",
        "url": "",
        "anon_key": "",
    }

@app.post("/api/browser-session")
async def bridge_session():
    return {"status": "ok"}

@app.delete("/api/browser-session")
async def clear_session():
    return {"status": "cleared"}

@app.get("/api/membership")
async def get_membership(authorization: Optional[str] = Header(None)):
    return {
        "email": "owner@oneteam.com",
        "plan": "pro",
        "tier": "vip",
        "is_admin": True,
        "trial_days_remaining": 30,
        "trial_expired": False,
        "pending_payment": False,
    }

@app.get("/api/owner/metrics")
async def get_owner_metrics():
    return {
        "active_vip": 1,
        "simple_trial": 0,
        "pending_payments": 0,
        "export_report": {"total": len(JOBS), "done": sum(1 for j in JOBS.values() if j.get("status") == "done")},
        "payments": [],
        "users": []
    }

@app.get("/api/plans")
async def get_plans():
    return {
        "plans": [
            {"key": "simple_monthly", "label": "Simple Plan", "price": 10000, "description": "အခြေခံ အသံများနှင့် တစ်နေ့ ၁ ပုဒ် Script ရေးသားထုတ်လုပ်ခွင့်"},
            {"key": "vip_monthly", "label": "Pro VIP Plan", "price": 30000, "description": "VIP သီးသန့် အသံများအပါအဝင် တစ်လ အပုဒ် ၁၀၀ (တစ်နေ့ ၃-၄ ပုဒ်) ထုတ်လုပ်ခွင့်"},
        ],
        "destinations": {
            "KBZPay": {"phone": "09123456789", "account_name": "One Team Studio"},
            "WavePay": {"phone": "09123456789", "account_name": "One Team Studio"},
        }
    }

@app.post("/api/payments")
async def submit_payment(
    kind: str = Form(...),
    offer_key: str = Form(...),
    payment_method: str = Form(...),
    transaction_id: str = Form(...),
    receipt: Optional[UploadFile] = File(None)
):
    return {"status": "ok", "message": "ငွေလွှဲအချက်အလက် ပေးပို့မှု အောင်မြင်ပါသည်။"}

# --- Media APIs ---
@app.post("/api/video")
async def upload_video(file: UploadFile = File(...), project_id: str = Form(...)):
    file_id = f"{uuid.uuid4()}_{file.filename}"
    target_path = UPLOAD_DIR / file_id
    with target_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    try:
        info = media_engine.probe_video(target_path)
    except Exception as exc:
        target_path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=str(exc))

    # ဗီဒီယို အရှည် စစ်ဆေးခြင်း (အများဆုံး ၁၀ မိနစ် = ၆၀၀ စက္ကန့်)
    if info.get("duration", 0) > 600:
        target_path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail="ဗီဒီယို အရှည်သည် အများဆုံး ၁၀ မိနစ်ထက် မကျော်ရပါ။")

    PROJECTS[project_id] = {
        "video_path": str(target_path),
        "filename": file.filename,
        "info": info
    }
    return info

@app.post("/api/assets")
async def upload_asset(file: UploadFile = File(...), kind: str = Form(...), project_id: str = Form(...)):
    file_id = f"{kind}_{uuid.uuid4()}_{file.filename}"
    target_path = UPLOAD_DIR / file_id
    with target_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return {"path": str(target_path)}

@app.post("/api/preview-ms-voice")
async def preview_ms_voice(payload: dict = Body(...)):
    voice_id = payload.get("voice", "Nilar")
    text = "မင်္ဂလာပါ၊ One Team Movie Recap ရဲ့ အသံဖြစ်ပါတယ်"
    try:
        audio_bytes = media_engine.generate_microsoft_tts(text, voice_id)
        return Response(content=audio_bytes, media_type="audio/mpeg")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# --- Jobs Processing ---
@app.post("/api/jobs")
async def create_job(payload: JobSettings):
    user_email = "owner@oneteam.com"
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    user_key = f"{user_email}_{today}"

    # နေ့စဉ် ကန့်သတ်ချက် စစ်ဆေးခြင်း (၅ ပုဒ် ကန့်သတ်ချက်)
    current_count = len(DAILY_EXPORTS.get(user_key, []))
    if current_count >= 5:
        raise HTTPException(status_code=429, detail="ယနေ့အတွက် သတ်မှတ်ထားသော ဗီဒီယို ၅ ပုဒ် ပြည့်သွားပါပြီ။")

    proj = PROJECTS.get(payload.project_id)
    if not proj:
        raise HTTPException(status_code=400, detail="Video ဖိုင် ရှာမတွေ့ပါ၊ ပြန်လည် တင်ပေးပါ")

    if user_key not in DAILY_EXPORTS:
        DAILY_EXPORTS[user_key] = []
    DAILY_EXPORTS[user_key].append(str(uuid.uuid4()))

    job_id = str(uuid.uuid4())
    JOBS[job_id] = {
        "id": job_id,
        "status": "running",
        "progress": 5,
        "step": "upload",
        "message": "အချက်အလက်များကို စစ်ဆေးနေပါသည်",
        "download_url": "",
        "error": ""
    }

    import threading
    def task_worker():
        try:
            settings = payload.settings
            video_path = Path(proj["video_path"])
            api_key = payload.simple_api_key or os.getenv("GEMINI_API_KEY", "")

            def update_progress(percent: int, msg: str):
                JOBS[job_id]["progress"] = percent
                JOBS[job_id]["message"] = msg
                if percent >= 50:
                    JOBS[job_id]["step"] = "voice"
                elif percent >= 25:
                    JOBS[job_id]["step"] = "script"

            update_progress(20, "Script ရေးသားနေပါသည်")
            script = media_engine.generate_script(
                api_key=api_key,
                video_path=video_path,
                mime_type="video/mp4",
                language=settings.get("language", "Myanmar"),
                duration_seconds=int(proj["info"]["duration"]),
                tone=settings.get("tone", "Cinematic"),
                recap_type=settings.get("recapType", "Movie Recap"),
                timing_mode="Natural",
                progress=update_progress
            )
            settings["script"] = script

            update_progress(65, "အသံ ဖိုင် ထုတ်ယူနေပါသည်")
            voice_choice = settings.get("voice", "Nilar")
            if voice_choice in media_engine.GEMINI_VOICES:
                tts_wav = media_engine.generate_gemini_tts(script, voice_choice, api_key)
            else:
                tts_wav = media_engine.generate_microsoft_tts(script, voice_choice)

            update_progress(80, "Final Video ပေါင်းစပ်နေပါသည်")
            JOBS[job_id]["step"] = "render"
            out_file = OUTPUT_DIR / f"final_{job_id}.mp4"
            media_engine.render_final(video_path, tts_wav, settings, out_file)

            JOBS[job_id]["status"] = "done"
            JOBS[job_id]["progress"] = 100
            JOBS[job_id]["message"] = "Final MP4 အဆင်သင့်ပါပြီ"
            JOBS[job_id]["download_url"] = f"/api/download/{out_file.name}"

        except Exception as exc:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["error"] = str(exc)
            JOBS[job_id]["message"] = "Video ထုတ်လုပ်မှု မအောင်မြင်ပါ"

    thread = threading.Thread(target=task_worker, daemon=True)
    thread.start()

    return JOBS[job_id]

@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str):
    if job_id in JOBS:
        JOBS[job_id]["status"] = "cancelled"
        JOBS[job_id]["message"] = "လုပ်ငန်းစဉ်ကို ပယ်ဖျက်လိုက်ပါသည်"
    return {"status": "ok"}

@app.get("/api/download/{filename}")
async def download_file(filename: str):
    file_path = OUTPUT_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path, media_type="video/mp4", filename=filename)

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8080))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
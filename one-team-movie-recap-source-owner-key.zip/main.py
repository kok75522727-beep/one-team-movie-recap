"""FastAPI server for One Team Movie Recap Studio."""

from __future__ import annotations
import os, uuid, shutil, subprocess, requests, json, re, time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional
from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Header, Body
from fastapi.responses import FileResponse, Response, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from google.cloud import storage

import yt_dlp
import media_engine
import membership

app = FastAPI(title="One Team Movie Recap Studio")

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
UPLOAD_DIR = ROOT / "uploads"
OUTPUT_DIR = ROOT / "outputs"
FONTS_DIR = ROOT / "fonts"

for folder in [STATIC_DIR, UPLOAD_DIR, OUTPUT_DIR, FONTS_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/fonts", StaticFiles(directory=str(FONTS_DIR)), name="fonts")

# ----------------- Google Cloud Storage Helpers -----------------
BUCKET_NAME = os.getenv("GCS_BUCKET_NAME", "oneteam-recap-storage-2026")
storage_client = storage.Client()

def get_bucket():
    return storage_client.bucket(BUCKET_NAME)

def upload_to_gcs(local_path: Path | str, blob_name: str, content_type: str = "application/octet-stream") -> str:
    bucket = get_bucket()
    blob = bucket.blob(blob_name)
    blob.upload_from_filename(str(local_path), content_type=content_type)
    try:
        blob.make_public()
    except Exception:
        pass
    return blob.public_url

def download_from_gcs(blob_name: str, local_path: Path | str) -> bool:
    try:
        bucket = get_bucket()
        blob = bucket.blob(blob_name)
        if not blob.exists():
            return False
        Path(local_path).parent.mkdir(parents=True, exist_ok=True)
        blob.download_to_filename(str(local_path))
        return True
    except Exception:
        return False

def save_json_to_gcs(blob_name: str, data: dict):
    bucket = get_bucket()
    blob = bucket.blob(blob_name)
    blob.upload_from_string(json.dumps(data, ensure_ascii=False), content_type="application/json")

def load_json_from_gcs(blob_name: str) -> dict | None:
    try:
        bucket = get_bucket()
        blob = bucket.blob(blob_name)
        if not blob.exists():
            return None
        content = blob.download_as_text()
        return json.loads(content) if content else None
    except Exception:
        return None
# ----------------------------------------------------------------

class JobSettings(BaseModel):
    project_id: str
    settings: dict[str, Any]
    simple_api_key: Optional[str] = ""

def extract_token(auth_header: Optional[str]) -> str:
    if not auth_header: return ""
    if auth_header.startswith("Bearer "): return auth_header[7:]
    return auth_header

def save_data(type_str: str, id_str: str, data: dict):
    path = UPLOAD_DIR / f"{type_str}_{id_str}.json"
    tmp_path = UPLOAD_DIR / f"{type_str}_{id_str}.tmp"
    try:
        tmp_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp_path.replace(path)
    except Exception:
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    
    try:
        save_json_to_gcs(f"data/{type_str}_{id_str}.json", data)
    except Exception:
        pass

def load_data(type_str: str, id_str: str) -> dict | None:
    path = UPLOAD_DIR / f"{type_str}_{id_str}.json"
    if path.exists() and path.stat().st_size > 0:
        try:
            content = path.read_text(encoding="utf-8").strip()
            if content:
                return json.loads(content)
        except Exception:
            pass
            
    gcs_data = load_json_from_gcs(f"data/{type_str}_{id_str}.json")
    if gcs_data:
        try:
            path.write_text(json.dumps(gcs_data, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass
        return gcs_data
        
    return None

def update_job(job_id: str, updates: dict):
    job = load_data("job", job_id)
    if job:
        job.update(updates)
        save_data("job", job_id, job)

def send_telegram_alert(message: str):
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id:
        return
    try:
        url = f"https://api.telegram.org/bot{token}/sendMessage"
        payload = {"chat_id": chat_id, "text": message, "parse_mode": "HTML"}
        requests.post(url, json=payload, timeout=10)
    except Exception:
        pass

@app.get("/")
async def serve_index(): return FileResponse(STATIC_DIR / "editor.html")

@app.get("/login")
async def serve_login(): return FileResponse(STATIC_DIR / "login.html")

@app.get("/owner")
async def serve_owner(): return FileResponse(STATIC_DIR / "owner.html")

@app.get("/api/auth-config")
async def get_auth_config():
    db = membership.SupabaseMembership()
    return db.public_config()

@app.post("/api/browser-session")
async def bridge_session(): return {"status": "ok"}

@app.delete("/api/browser-session")
async def clear_session(): return {"status": "cleared"}

@app.get("/api/membership")
async def get_membership(authorization: Optional[str] = Header(None)):
    db = membership.SupabaseMembership()
    try:
        return db.member_from_token(extract_token(authorization))
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))

@app.get("/api/plans")
async def get_plans():
    db = membership.SupabaseMembership()
    return db.public_payment_info()

@app.post("/api/payments")
async def submit_payment(
    authorization: Optional[str] = Header(None), kind: str = Form(...), offer_key: str = Form(...),
    payment_method: str = Form(...), transaction_id: str = Form(...), receipt: Optional[UploadFile] = File(None)
):
    db = membership.SupabaseMembership()
    try:
        member = db.member_from_token(extract_token(authorization))
        receipt_bytes = await receipt.read() if receipt else b""
        db.create_payment_request(member, kind=kind, offer_key=offer_key, payment_method=payment_method, transaction_id=transaction_id, receipt=receipt_bytes, receipt_mime=receipt.content_type if receipt else "")
        return {"status": "ok", "message": "ငွေလွှဲအချက်အလက် ပို့ပြီးပါပြီ။ Admin အတည်ပြုမှုကို စောင့်ပါ။"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/owner/metrics")
async def get_owner_metrics(authorization: Optional[str] = Header(None)):
    try:
        db = membership.SupabaseMembership()
        member = db.member_from_token(extract_token(authorization))
        if not member.get("is_admin"): raise HTTPException(status_code=403, detail="Owner only")
        return db.owner_overview()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/owner/approve-payment")
async def approve_payment_api(payload: dict = Body(...), authorization: Optional[str] = Header(None)):
    try:
        db = membership.SupabaseMembership()
        member = db.member_from_token(extract_token(authorization))
        if not member.get("is_admin"): raise HTTPException(status_code=403, detail="Not authorized")
        req_id = payload.get("request_id") or payload.get("id")
        db.approve_payment(int(req_id), member.get("email", "admin"), payload.get("note", ""))
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/owner/reject-payment")
async def reject_payment_api(payload: dict = Body(...), authorization: Optional[str] = Header(None)):
    try:
        db = membership.SupabaseMembership()
        member = db.member_from_token(extract_token(authorization))
        if not member.get("is_admin"): raise HTTPException(status_code=403, detail="Not authorized")
        req_id = payload.get("request_id") or payload.get("id")
        db.reject_payment(int(req_id), member.get("email", "admin"), payload.get("note", ""))
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/owner/grant-credits")
async def grant_credits_api(payload: dict = Body(...), authorization: Optional[str] = Header(None)):
    try:
        db = membership.SupabaseMembership()
        member = db.member_from_token(extract_token(authorization))
        if not member.get("is_admin"): raise HTTPException(status_code=403, detail="Not authorized")
        db.grant_manual_credits(payload.get("email", ""), int(payload.get("credits", 1)), member.get("email", "admin"), payload.get("note", "Manual Grant"))
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/owner/extend-user")
async def extend_user_api(payload: dict = Body(...), authorization: Optional[str] = Header(None)):
    try:
        db = membership.SupabaseMembership()
        member = db.member_from_token(extract_token(authorization))
        if not member.get("is_admin"): raise HTTPException(status_code=403, detail="Not authorized")
        db.extend_user_plan(payload.get("email", ""), int(payload.get("days", 1)), member.get("email", "admin"))
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/video")
async def upload_video(file: UploadFile = File(...), project_id: str = Form(...)):
    file_id = f"{uuid.uuid4()}_{file.filename}"
    target_path = UPLOAD_DIR / file_id
    with target_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    try:
        info = media_engine.probe_video(target_path)
        upload_to_gcs(target_path, f"uploads/{file_id}", content_type="video/mp4")
        save_data("proj", project_id, {
            "video_path": str(target_path), 
            "filename": file.filename, 
            "file_id": file_id,
            "gcs_path": f"uploads/{file_id}",
            "info": info
        })
        return info
    except Exception as exc:
        target_path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=str(exc))

@app.get("/api/play/{filename}")
async def play_video(filename: str):
    file_path = UPLOAD_DIR / filename
    if not file_path.exists():
        success = download_from_gcs(f"uploads/{filename}", file_path)
        if not success:
            raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path, media_type="video/mp4")

@app.post("/api/link-preview")
async def get_link_preview(payload: dict = Body(...)):
    url = payload.get("url", "").strip()
    if not url:
        raise HTTPException(status_code=400, detail="Link မပါပါ")
    
    project_id = str(uuid.uuid4())
    job_id = f"dl_{project_id}"
    save_data("job", job_id, {"status": "running", "progress": 0, "message": "Link ချိတ်ဆက်နေပါသည်...", "project_id": project_id})
    
    import threading
    def dl_worker():
        filename = f"link_{project_id}.mp4"
        dl_path = UPLOAD_DIR / filename
        browser_headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
            "Referer": "https://www.tiktok.com/"
        }
        try:
            if "tiktok.com" in url:
                update_job(job_id, {"progress": 10, "message": "TikTok ဗီဒီယို လင့်ခ် ရယူနေပါသည်..."})
                api_res = requests.post("https://www.tikwm.com/api/", data={"url": url, "hd": 1}, headers=browser_headers, timeout=15)
                
                if api_res.ok and api_res.json().get("data", {}).get("play"):
                    play_url = api_res.json()["data"]["play"]
                    update_job(job_id, {"progress": 25, "message": "ဗီဒီယို ဒေါင်းလုဒ်ဆွဲနေပါသည်..."})
                    
                    with requests.get(play_url, stream=True, headers=browser_headers, timeout=60) as vid_res:
                        vid_res.raise_for_status()
                        total_length = int(vid_res.headers.get('content-length', 0))
                        dl_size = 0
                        with open(dl_path, 'wb') as f:
                            for chunk in vid_res.iter_content(chunk_size=1048576):
                                if chunk:
                                    f.write(chunk)
                                    dl_size += len(chunk)
                                    if total_length > 0:
                                        pct = min(95, int((dl_size / total_length) * 100))
                                        update_job(job_id, {"progress": pct, "message": f"ဒေါင်းလုဒ်ဆွဲနေပါသည်... {pct}%"})
                
                if not dl_path.exists() or dl_path.stat().st_size == 0:
                    raise ValueError("TikTok API တုံ့ပြန်မှု မရရှိပါ")
            else:
                def progress_hook(d):
                    if d['status'] == 'downloading':
                        p = d.get('_percent_str', '0%')
                        p = re.sub(r'\x1b\[[0-9;]*m', '', p).replace('%', '').strip()
                        try:
                            pct = int(float(p))
                            update_job(job_id, {"progress": pct, "message": f"ဒေါင်းလုဒ်ဆွဲနေပါသည်... {pct}%"})
                        except:
                            pass

                ydl_opts = {
                    'format': 'bestvideo[height<=720][ext=mp4]+bestaudio[ext=m4a]/best[height<=720][ext=mp4]/best',
                    'outtmpl': str(dl_path),
                    'quiet': True,
                    'no_warnings': True,
                    'progress_hooks': [progress_hook],
                    'extractor_args': {'youtube': {'player_client': ['android']}},
                    'http_headers': browser_headers
                }
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    ydl.download([url])
                
            if not dl_path.exists() or dl_path.stat().st_size == 0:
                raise ValueError("Video ဖိုင်ကို အပြည့်အဝ ဒေါင်းလုဒ်ဆွဲ၍ မရပါ")
                
            info = media_engine.probe_video(dl_path)
            upload_to_gcs(dl_path, f"uploads/{filename}", content_type="video/mp4")
            
            save_data("proj", project_id, {
                "video_path": str(dl_path), 
                "filename": filename, 
                "file_id": filename,
                "gcs_path": f"uploads/{filename}",
                "info": info
            })
            
            update_job(job_id, {
                "status": "done",
                "progress": 100,
                "message": "ဒေါင်းလုဒ်ဆွဲခြင်း ပြီးဆုံးပါပြီ",
                "duration": info.get("duration", 0),
                "video_url": f"/api/play/{filename}"
            })
        except Exception as e:
            if dl_path.exists():
                dl_path.unlink(missing_ok=True)
            update_job(job_id, {"status": "error", "error": str(e), "message": f"Link မှ ဒေါင်းလုဒ်ဆွဲ၍ မရပါ: {str(e)}"})

    threading.Thread(target=dl_worker, daemon=True).start()
    return {"status": "started", "job_id": job_id}

@app.post("/api/assets")
async def upload_asset(file: UploadFile = File(...), kind: str = Form(...), project_id: str = Form(...)):
    filename = f"{kind}_{uuid.uuid4()}_{file.filename}"
    target_path = UPLOAD_DIR / filename
    with target_path.open("wb") as buffer: 
        shutil.copyfileobj(file.file, buffer)
    upload_to_gcs(target_path, f"assets/{filename}")
    return {"path": str(target_path)}

@app.post("/api/preview-ms-voice")
async def preview_ms_voice(payload: dict = Body(...)):
    voice_id = payload.get("voice", "Nilar")
    text = "မင်္ဂလာပါ၊ One Team မှ ကြိုဆိုပါတယ်။"
    api_key = os.getenv("GEMINI_API_KEY", "")
    try:
        if voice_id in media_engine.GEMINI_VOICES:
            audio_bytes = media_engine.generate_gemini_tts(text, voice_id, api_key)
        else:
            audio_bytes = media_engine.generate_microsoft_tts(text, voice_id)
        return Response(content=audio_bytes, media_type="audio/mpeg")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/jobs")
async def create_job(payload: JobSettings, authorization: Optional[str] = Header(None)):
    db = membership.SupabaseMembership()
    try:
        member = db.member_from_token(extract_token(authorization))
    except Exception:
        raise HTTPException(status_code=401, detail="Session expired")

    proj = load_data("proj", payload.project_id)
    if not proj: raise HTTPException(status_code=400, detail="Video ဖိုင် ရှာမတွေ့ပါ။")

    duration_seconds = float(proj["info"].get("duration", 0))
    plan = membership.effective_plan(member)
    
    try:
        entitlement = membership.evaluate_export(member, duration_seconds, db.successful_exports_today(member, plan))
    except Exception as e:
        raise HTTPException(status_code=403, detail=str(e))

    job_id = str(uuid.uuid4())
    job_data = {
        "id": job_id, 
        "status": "running", 
        "progress": 5, 
        "step": "upload", 
        "message": "အချက်အလက်များကို စစ်ဆေးနေပါသည်", 
        "download_url": "", 
        "error": "",
        "user_email": member.get("email", ""),
        "filename": proj.get("filename", "Video"),
        "duration": duration_seconds,
        "created_at": time.time()
    }
    save_data("job", job_id, job_data)

    import threading
    def task_worker():
        try:
            settings = payload.settings
            api_key = payload.simple_api_key or os.getenv("GEMINI_API_KEY", "")
            video_path = Path(proj["video_path"])
            
            if not video_path.exists():
                gcs_key = proj.get("gcs_path") or f"uploads/{proj.get('file_id', video_path.name)}"
                download_from_gcs(gcs_key, video_path)

            voice_choice = settings.get("voice", "Nilar")
            
            def update_progress(percent: int, msg: str):
                step = "render" if percent >= 80 else "voice" if percent >= 50 else "script" if percent >= 20 else "upload"
                update_job(job_id, {"progress": percent, "message": msg, "step": step})

            update_progress(25, "Script ရေးသားနေပါသည်")
            script = media_engine.generate_script(
                api_key=api_key, video_path=video_path, mime_type="video/mp4",
                language=settings.get("language", "Myanmar"), duration_seconds=int(duration_seconds),
                tone=settings.get("tone", "Cinematic"), recap_type=settings.get("recapType", "Movie Recap"),
                timing_mode="Natural", progress=update_progress
            )
            settings["script"] = script

            update_progress(65, "အသံ ဖိုင် ထုတ်ယူနေပါသည်")
            if voice_choice in media_engine.GEMINI_VOICES:
                tts_wav = media_engine.generate_gemini_tts(script, voice_choice, api_key)
            else:
                tts_wav = media_engine.generate_microsoft_tts(script, voice_choice)

            update_progress(80, "Final Video ပေါင်းစပ်နေပါသည်")
            out_file = OUTPUT_DIR / f"final_{job_id}.mp4"
            media_engine.render_final(video_path, tts_wav, settings, out_file)

            gcs_url = upload_to_gcs(out_file, f"outputs/{out_file.name}", content_type="video/mp4")

            db.record_success(member, entitlement, duration_seconds)
            update_job(job_id, {
                "status": "done", 
                "progress": 100, 
                "message": "Final MP4 အဆင်သင့်ပါပြီ", 
                "download_url": f"/api/download/{out_file.name}",
                "gcs_url": gcs_url
            })

            raw_name = member.get("user_metadata", {}).get("full_name")
            raw_email = member.get("email", "")
            user_name = raw_name if raw_name else (raw_email.split("@")[0] if "@" in raw_email else "User")
                
            v_title = proj.get("filename", "video.mp4")
            telegram_msg = (
                f"🎬 <b>Video Recap ပြီးစီးပါပြီ!</b>\n\n"
                f"👤 <b>အသုံးပြုသူ:</b> {user_name}\n"
                f"📁 <b>ဖိုင်အမည်:</b> {v_title}\n"
                f"⏱ <b>ကြာချိန်:</b> {int(duration_seconds)} စက္ကန့်\n"
                f"✅ <b>Status:</b> Ready to Download"
            )
            send_telegram_alert(telegram_msg)

        except Exception as exc:
            db.record_failure(member, duration_seconds, entitlement)
            update_job(job_id, {"status": "error", "error": str(exc), "message": "Video ထုတ်လုပ်မှု မအောင်မြင်ပါ"})

            raw_name = member.get("user_metadata", {}).get("full_name")
            raw_email = member.get("email", "")
            user_name = raw_name if raw_name else (raw_email.split("@")[0] if "@" in raw_email else "User")
                
            v_title = proj.get("filename", "video.mp4")
            err_msg = (
                f"⚠️ <b>Video Recap ထုတ်လုပ်မှု မအောင်မြင်ပါ!</b>\n\n"
                f"👤 <b>အသုံးပြုသူ:</b> {user_name}\n"
                f"📁 <b>ဖိုင်အမည်:</b> {v_title}\n"
                f"❌ <b>Error:</b> <code>{str(exc)[:250]}</code>"
            )
            send_telegram_alert(err_msg)

    threading.Thread(target=task_worker, daemon=True).start()
    return load_data("job", job_id)

@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    job = load_data("job", job_id)
    if not job: raise HTTPException(status_code=404, detail="Job not found")
    return job

@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str):
    update_job(job_id, {"status": "cancelled", "message": "လုပ်ငန်းစဉ်ကို ပယ်ဖျက်လိုက်ပါသည်"})
    return {"status": "ok"}


# ================== အသစ်ပြင်ဆင်ထားသော DIRECT GCS DOWNLOAD API ==================
@app.get("/api/download/{filename}")
async def download_file(filename: str):
    try:
        bucket = get_bucket()
        blob = bucket.blob(f"outputs/{filename}")
        
        if blob.exists():
            # ဖုန်းထဲ တိုက်ရိုက် ဒေါင်းလုဒ်ဖြစ်စေရန် (Force Download Metadata ထည့်ခြင်း)
            blob.content_disposition = f'attachment; filename="{filename}"'
            blob.patch()
            
            # ဖိုင်ကို Public အဖြစ်ပြောင်းပေးမည်
            try:
                blob.make_public()
            except Exception:
                pass
            
            # Google Storage Link ဆီ တိုက်ရိုက် လွှဲပေးမည် (Error လုံးဝမတက်တော့ပါ)
            return RedirectResponse(url=blob.public_url)
    except Exception:
        pass

    # GCS မှ မရပါက Local ထဲတွင် ရှာမည်
    local_path = OUTPUT_DIR / filename
    if local_path.exists() and local_path.stat().st_size > 0:
        return FileResponse(
            str(local_path),
            media_type="video/mp4",
            filename=filename,
            headers={"Content-Disposition": f'attachment; filename="{filename}"'}
        )
        
    raise HTTPException(status_code=404, detail="ဗီဒီယိုဖိုင် ရှာမတွေ့ပါ။")
# ==============================================================================


@app.get("/api/history")
async def get_history(authorization: Optional[str] = Header(None)):
    db = membership.SupabaseMembership()
    try:
        member = db.member_from_token(extract_token(authorization))
    except Exception:
        raise HTTPException(status_code=401, detail="Session expired")
        
    history_list = []
    local_jobs = {}
    for f in sorted(UPLOAD_DIR.glob("job_*.json"), key=os.path.getmtime, reverse=True):
        try:
            job = json.loads(f.read_text(encoding="utf-8"))
            if job.get("user_email") == member.get("email"):
                local_jobs[job.get("id")] = job
        except Exception:
            pass

    try:
        bucket = get_bucket()
        blobs = bucket.list_blobs(prefix="data/job_")
        for b in blobs:
            try:
                job = json.loads(b.download_as_text())
                if job.get("user_email") == member.get("email"):
                    local_jobs[job.get("id")] = job
            except Exception:
                pass
    except Exception:
        pass

    sorted_jobs = sorted(local_jobs.values(), key=lambda x: x.get("created_at", 0), reverse=True)
    for job in sorted_jobs:
        status = job.get("status")
        dl_url = job.get("download_url", "")
        if dl_url == "expired": dl_url = ""
            
        history_list.append({
            "filename": job.get("filename", "Video Recap"),
            "status": "success" if status == "done" else ("fail" if status in ["error", "cancelled"] else "running"),
            "download_url": dl_url,
            "duration": job.get("duration", 0),
            "date": datetime.fromtimestamp(job.get("created_at", time.time())).strftime("%Y-%m-%d %H:%M")
        })
        
    return history_list

def file_cleanup_worker():
    while True:
        now = time.time()
        for folder in [UPLOAD_DIR, OUTPUT_DIR]:
            for f in folder.iterdir():
                try:
                    if f.is_file() and (now - f.stat().st_mtime > 14400):
                        f.unlink(missing_ok=True)
                except Exception:
                    pass
        time.sleep(3600)

import threading
threading.Thread(target=file_cleanup_worker, daemon=True).start()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.getenv("PORT", 8080)))
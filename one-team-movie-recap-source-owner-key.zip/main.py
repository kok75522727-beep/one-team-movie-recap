"""FastAPI server for One Team Movie Recap Studio."""

from __future__ import annotations
import os, uuid, shutil, subprocess, requests, json, re, time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional
from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Header, Body
from fastapi.responses import FileResponse, Response, RedirectResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from google.cloud import storage

import yt_dlp
import media_engine
import membership

app = FastAPI(title="One Team Movie Recap Studio")

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
UPLOAD_DIR = ROOT / "uploads"
OUTPUT_DIR = ROOT / "outputs"
FONTS_DIR = ROOT / "fonts"

for folder in [STATIC_DIR, UPLOAD_DIR, OUTPUT_DIR, FONTS_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/fonts", StaticFiles(directory=str(FONTS_DIR)), name="fonts")

# ----------------- Telegram Webhook Auto Setup -----------------
@app.on_event("startup")
async def setup_telegram_webhook():
    bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    base_url = os.getenv("BASE_URL", "").strip()
    if bot_token and base_url:
        webhook_url = f"{base_url}/api/telegram/webhook"
        try:
            requests.get(f"https://api.telegram.org/bot{bot_token}/setWebhook?url={webhook_url}", timeout=10)
            print("Telegram Webhook Auto-Set Successfully!")
        except: pass

BUCKET_NAME = os.getenv("GCS_BUCKET_NAME", "oneteam-recap-storage-2026")
storage_client = storage.Client()

def get_bucket():
    return storage_client.bucket(BUCKET_NAME)

def upload_to_gcs(local_path: Path | str, blob_name: str, content_type: str = "application/octet-stream") -> str:
    bucket = get_bucket()
    blob = bucket.blob(blob_name)
    blob.upload_from_filename(str(local_path), content_type=content_type)
    try: blob.make_public()
    except: pass
    return blob.public_url

def download_from_gcs(blob_name: str, local_path: Path | str) -> bool:
    try:
        bucket = get_bucket()
        blob = bucket.blob(blob_name)
        if not blob.exists(): return False
        Path(local_path).parent.mkdir(parents=True, exist_ok=True)
        blob.download_to_filename(str(local_path))
        return True
    except: return False

def save_json_to_gcs(blob_name: str, data: dict):
    bucket = get_bucket()
    blob = bucket.blob(blob_name)
    blob.upload_from_string(json.dumps(data, ensure_ascii=False), content_type="application/json")

def load_json_from_gcs(blob_name: str) -> dict | None:
    try:
        bucket = get_bucket()
        blob = bucket.blob(blob_name)
        if not blob.exists(): return None
        content = blob.download_as_text()
        return json.loads(content) if content else None
    except: return None

class JobSettings(BaseModel):
    project_id: str
    settings: dict[str, Any]
    simple_api_key: Optional[str] = ""

def extract_token(auth_header: Optional[str]) -> str:
    if not auth_header: return ""
    if auth_header.startswith("Bearer "): return auth_header[7:]
    return auth_header

def save_data(type_str: str, id_str: str, data: dict):
    path = UPLOAD_DIR / f"{type_str}_{id_str}.json"
    tmp_path = UPLOAD_DIR / f"{type_str}_{id_str}.tmp"
    try:
        tmp_path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
        tmp_path.replace(path)
    except:
        path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")
    try: save_json_to_gcs(f"data/{type_str}_{id_str}.json", data)
    except: pass

def load_data(type_str: str, id_str: str) -> dict | None:
    path = UPLOAD_DIR / f"{type_str}_{id_str}.json"
    if path.exists() and path.stat().st_size > 0:
        try:
            content = path.read_text(encoding="utf-8").strip()
            if content: return json.loads(content)
        except: pass
    gcs_data = load_json_from_gcs(f"data/{type_str}_{id_str}.json")
    if gcs_data:
        try: path.write_text(json.dumps(gcs_data, ensure_ascii=False), encoding="utf-8")
        except: pass
        return gcs_data
    return None

def update_job(job_id: str, updates: dict):
    job = load_data("job", job_id)
    if job:
        job.update(updates)
        save_data("job", job_id, job)

def send_telegram_alert(message: str):
    token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
    chat_id = os.getenv("TELEGRAM_CHAT_ID", "").strip()
    if not token or not chat_id: return
    try:
        requests.post(f"https://api.telegram.org/bot{token}/sendMessage", json={"chat_id": chat_id, "text": message, "parse_mode": "HTML"}, timeout=10)
    except: pass

@app.get("/")
async def serve_index(): return FileResponse(STATIC_DIR / "editor.html")
@app.get("/login")
async def serve_login(): return FileResponse(STATIC_DIR / "login.html")
@app.get("/owner")
async def serve_owner(): return FileResponse(STATIC_DIR / "owner.html")

@app.get("/api/auth-config")
async def get_auth_config():
    return membership.SupabaseMembership().public_config()

@app.post("/api/browser-session")
async def bridge_session(): return {"status": "ok"}
@app.delete("/api/browser-session")
async def clear_session(): return {"status": "cleared"}

@app.get("/api/membership")
async def get_membership(authorization: Optional[str] = Header(None)):
    try: return membership.SupabaseMembership().member_from_token(extract_token(authorization))
    except Exception as e: raise HTTPException(status_code=401, detail=str(e))

@app.get("/api/plans")
async def get_plans(): return membership.SupabaseMembership().public_payment_info()

@app.post("/api/payments")
async def submit_payment(
    authorization: Optional[str] = Header(None), kind: str = Form(...), offer_key: str = Form(...),
    payment_method: str = Form(...), transaction_id: str = Form(...), receipt: Optional[UploadFile] = File(None)
):
    db = membership.SupabaseMembership()
    try:
        member = db.member_from_token(extract_token(authorization))
        receipt_bytes = await receipt.read() if receipt else b""
        db.create_payment_request(member, kind=kind, offer_key=offer_key, payment_method=payment_method, transaction_id=transaction_id, receipt=receipt_bytes, receipt_mime=receipt.content_type if receipt else "")
        return {"status": "ok", "message": "ငွေလွှဲအချက်အလက် ပို့ပြီးပါပြီ။ Admin အတည်ပြုမှုကို စောင့်ပါ။"}
    except Exception as e: raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/telegram/webhook")
async def telegram_webhook(payload: dict = Body(...)):
    try:
        message = payload.get("message", {})
        text = message.get("text", "")
        chat_id = str(message.get("chat", {}).get("id", ""))
        if text.startswith("/start "):
            user_key = text.split(" ")[1].strip() 
            save_data("tg_bind", user_key, {"chat_id": chat_id})
            bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
            if bot_token:
                requests.post(
                    f"https://api.telegram.org/bot{bot_token}/sendMessage",
                    json={"chat_id": chat_id, "text": "✅ One Team Movie Recap Studio နှင့် အောင်မြင်စွာ ချိတ်ဆက်ပြီးပါပြီ။ Video ပြီးစီးပါက ဤနေရာသို့ တိုက်ရိုက် ပို့ပေးပါမည်။"}
                )
    except Exception as e: print("Webhook Error:", e)
    return {"status": "ok"}

# ----------------- GCS Direct Upload (Presigned URL) -----------------
@app.post("/api/get-presigned-url")
async def get_presigned_url(payload: dict = Body(...)):
    """User Browser မှ Google Cloud သို့ တိုက်ရိုက်တင်ခွင့် လက်မှတ် (Signed URL) ထုတ်ပေးခြင်း"""
    filename = payload.get("filename", "video.mp4")
    project_id = payload.get("project_id", str(uuid.uuid4()))
    file_id = f"{project_id}_{filename.replace(' ', '_')}"
    blob_name = f"uploads/{file_id}"
    
    try:
        bucket = get_bucket()
        blob = bucket.blob(blob_name)
        url = blob.generate_signed_url(
            version="v4",
            expiration=timedelta(minutes=60),
            method="PUT",
            content_type="video/mp4" 
        )
        return {"url": url, "file_id": file_id, "blob_name": blob_name, "project_id": project_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"URL ထုတ်မရပါ: {str(e)}")

@app.post("/api/finalize-upload")
async def finalize_upload(payload: dict = Body(...)):
    """Google Cloud သို့ တိုက်ရိုက်ရောက်သွားသောဖိုင်ကို ဆာဗာမှ ပြန်လည်မှတ်သားခြင်း"""
    project_id = payload.get("project_id")
    file_id = payload.get("file_id")
    filename = payload.get("filename")
    blob_name = payload.get("blob_name")
    
    local_path = UPLOAD_DIR / file_id
    download_from_gcs(blob_name, local_path)
    
    try:
        info = media_engine.probe_video(local_path)
        save_data("proj", project_id, {
            "video_path": str(local_path), 
            "filename": filename, 
            "file_id": file_id,
            "gcs_path": blob_name,
            "info": info
        })
        return info
    except Exception as exc:
        if local_path.exists(): local_path.unlink()
        raise HTTPException(status_code=400, detail="Video ဖိုင် မှားယွင်းနေပါသည်")
# ----------------------------------------------------------------------

@app.get("/api/play/{filename}")
async def play_video(filename: str):
    file_path = UPLOAD_DIR / filename
    if not file_path.exists():
        if not download_from_gcs(f"uploads/{filename}", file_path): raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path, media_type="video/mp4")

@app.post("/api/link-preview")
async def get_link_preview(payload: dict = Body(...)):
    url = payload.get("url", "").strip()
    if not url: raise HTTPException(status_code=400, detail="Link မပါပါ")
    project_id = str(uuid.uuid4())
    job_id = f"dl_{project_id}"
    save_data("job", job_id, {"status": "running", "progress": 0, "message": "Link ချိတ်ဆက်နေပါသည်...", "project_id": project_id})
    
    import threading
    def dl_worker():
        filename = f"link_{project_id}.mp4"
        dl_path = UPLOAD_DIR / filename
        try:
            update_job(job_id, {"progress": 15, "message": "ဗီဒီယို ရှာဖွေနေပါသည်..."})
            downloaded = False
            try:
                cobalt_payload = {"url": url, "vCodec": "h264", "vQuality": "720"}
                api_res = requests.post("https://api.cobalt.tools/api/json", json=cobalt_payload, headers={"Accept": "application/json", "Content-Type": "application/json"}, timeout=20)
                if api_res.ok:
                    res_json = api_res.json()
                    video_url = res_json.get("url") or (res_json.get("picker")[0].get("url") if res_json.get("picker") else None)
                    if video_url:
                        update_job(job_id, {"progress": 40, "message": "ဒေါင်းလုဒ် ဆွဲယူနေပါသည်..."})
                        with requests.get(video_url, stream=True, timeout=60) as r:
                            r.raise_for_status()
                            with open(dl_path, 'wb') as f:
                                for chunk in r.iter_content(chunk_size=1048576): 
                                    if chunk: f.write(chunk)
                        downloaded = True
            except: pass 
            if not downloaded or not dl_path.exists() or dl_path.stat().st_size == 0:
                update_job(job_id, {"progress": 30, "message": "အရန်စနစ်ဖြင့် ချိတ်ဆက်နေပါသည်..."})
                ydl_opts = {'format': 'best', 'outtmpl': str(dl_path), 'quiet': True, 'nocheckcertificate': True}
                with yt_dlp.YoutubeDL(ydl_opts) as ydl: ydl.download([url])
            if not dl_path.exists() or dl_path.stat().st_size == 0: raise ValueError("Video ဖိုင်ကို အပြည့်အဝ ဒေါင်းလုဒ်ဆွဲ၍ မရပါ။")
            info = media_engine.probe_video(dl_path)
            upload_to_gcs(dl_path, f"uploads/{filename}", content_type="video/mp4")
            save_data("proj", project_id, {"video_path": str(dl_path), "filename": filename, "gcs_path": f"uploads/{filename}", "info": info})
            update_job(job_id, {"status": "done", "progress": 100, "message": "ပြီးဆုံးပါပြီ", "duration": info.get("duration", 0), "video_url": f"/api/play/{filename}"})
        except Exception as e:
            if dl_path.exists(): dl_path.unlink(missing_ok=True)
            update_job(job_id, {"status": "error", "error": str(e), "message": f"Link မှ ဒေါင်းလုဒ်ဆွဲ၍ မရပါ: {str(e)}"})
    threading.Thread(target=dl_worker, daemon=True).start()
    return {"status": "started", "job_id": job_id}

@app.post("/api/jobs")
async def create_job(payload: JobSettings, authorization: Optional[str] = Header(None)):
    db = membership.SupabaseMembership()
    try: member = db.member_from_token(extract_token(authorization))
    except Exception: raise HTTPException(status_code=401, detail="Session expired")

    proj = load_data("proj", payload.project_id)
    if not proj: raise HTTPException(status_code=400, detail="Video ဖိုင် ရှာမတွေ့ပါ။")

    duration_seconds = float(proj["info"].get("duration", 0))
    plan = membership.effective_plan(member)
    try: entitlement = membership.evaluate_export(member, duration_seconds, db.successful_exports_today(member, plan))
    except Exception as e: raise HTTPException(status_code=403, detail=str(e))

    job_id = str(uuid.uuid4())
    job_data = {
        "id": job_id, "status": "running", "progress": 5, "step": "upload", 
        "message": "အချက်အလက်များကို စစ်ဆေးနေပါသည်", "download_url": "", "thumb_url": "",
        "user_email": member.get("email", ""), "filename": proj.get("filename", "Video"),
        "duration": duration_seconds, "created_at": time.time()
    }
    save_data("job", job_id, job_data)

    import threading
    def task_worker():
        try:
            settings = payload.settings
            api_key = payload.simple_api_key or os.getenv("GEMINI_API_KEY", "")
            video_path = Path(proj["video_path"])
            if not video_path.exists(): download_from_gcs(proj.get("gcs_path") or f"uploads/{proj.get('file_id', video_path.name)}", video_path)

            voice_choice = settings.get("voice", "Nilar")
            def update_progress(percent: int, msg: str):
                update_job(job_id, {"progress": percent, "message": msg, "step": "render" if percent >= 80 else "voice" if percent >= 50 else "script" if percent >= 20 else "upload"})

            update_progress(25, "Script ရေးသားနေပါသည်")
            script = media_engine.generate_script(api_key, video_path, "video/mp4", settings.get("language", "Myanmar"), int(duration_seconds), settings.get("tone", "Cinematic"), settings.get("recapType", "Movie Recap"), "Natural", update_progress)
            settings["script"] = script

            update_progress(65, "အသံ ဖိုင် ထုတ်ယူနေပါသည်")
            tts_wav = media_engine.generate_gemini_tts(script, voice_choice, api_key) if voice_choice in media_engine.GEMINI_VOICES else media_engine.generate_microsoft_tts(script, voice_choice)

            update_progress(80, "Final Video ပေါင်းစပ်နေပါသည်")
            out_file = OUTPUT_DIR / f"final_{job_id}.mp4"
            media_engine.render_final(video_path, tts_wav, settings, out_file)
            gcs_url = upload_to_gcs(out_file, f"outputs/{out_file.name}", content_type="video/mp4")

            update_progress(95, "ကာဗာပုံ (Thumbnail) ဖန်တီးနေပါသည်...")
            thumb_file = OUTPUT_DIR / f"thumb_{job_id}.jpg"
            thumb_result = media_engine.generate_thumbnail(video_path, script, settings.get("aspect", "9:16"), api_key, thumb_file)
            
            thumb_download_url = ""
            if thumb_result and thumb_result.exists():
                upload_to_gcs(thumb_file, f"outputs/{thumb_file.name}", content_type="image/jpeg")
                thumb_download_url = f"/api/download/{thumb_file.name}"

            db.record_success(member, entitlement, duration_seconds)
            update_job(job_id, {"status": "done", "progress": 100, "message": "Final MP4 နှင့် ကာဗာပုံ အဆင်သင့်ပါပြီ", "download_url": f"/api/download/{out_file.name}", "thumb_url": thumb_download_url, "gcs_url": gcs_url})

            user_name = member.get("user_metadata", {}).get("full_name") or member.get("email", "").split("@")[0]
            v_title = proj.get("filename", "video.mp4")
            
            send_telegram_alert(f"🎬 <b>Video Recap ပြီးစီးပါပြီ!</b>\n\n👤 <b>အသုံးပြုသူ:</b> {user_name}\n📁 <b>ဖိုင်အမည်:</b> {v_title}\n⏱ <b>ကြာချိန်:</b> {int(duration_seconds)} စက္ကန့်")

            bind_info = load_data("tg_bind", member.get("email", ""))
            user_chat_id = bind_info.get("chat_id", "") if bind_info else ""
            bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
            base_url = os.getenv("BASE_URL", "https://your-website.com").strip()
            
            if user_chat_id and bot_token:
                try:
                    direct_dl_url = f"{base_url}/api/download/{out_file.name}"
                    reply_markup = {"inline_keyboard": [[{"text": "📥 Video 100% Quality ဒေါင်းလုဒ်ဆွဲရန်", "url": direct_dl_url}]]}
                    if thumb_result and thumb_result.exists():
                        with open(thumb_result, "rb") as f:
                            requests.post(f"https://api.telegram.org/bot{bot_token}/sendPhoto", data={"chat_id": user_chat_id, "caption": f"🎬 သင့်ရဲ့ Video ပြီးပါပြီ: {v_title}", "reply_markup": json.dumps(reply_markup)}, files={"photo": f}, timeout=20)
                    else:
                        requests.post(f"https://api.telegram.org/bot{bot_token}/sendMessage", json={"chat_id": user_chat_id, "text": f"🎬 သင့်ရဲ့ Video ပြီးပါပြီ: {v_title}", "reply_markup": reply_markup}, timeout=20)
                except: pass

        except Exception as exc:
            db.record_failure(member, duration_seconds, entitlement)
            update_job(job_id, {"status": "error", "error": str(exc), "message": "Video ထုတ်လုပ်မှု မအောင်မြင်ပါ"})
            user_name = member.get("user_metadata", {}).get("full_name") or member.get("email", "").split("@")[0]
            send_telegram_alert(f"⚠️ <b>Video Recap ထုတ်လုပ်မှု မအောင်မြင်ပါ!</b>\n\n👤 <b>အသုံးပြုသူ:</b> {user_name}\n📁 <b>ဖိုင်အမည်:</b> {proj.get('filename', 'video.mp4')}\n❌ <b>Error:</b> <code>{str(exc)[:250]}</code>")

    threading.Thread(target=task_worker, daemon=True).start()
    return load_data("job", job_id)

@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    job = load_data("job", job_id)
    if not job: raise HTTPException(status_code=404, detail="Job not found")
    return job

@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str):
    update_job(job_id, {"status": "cancelled", "message": "လုပ်ငန်းစဉ်ကို ပယ်ဖျက်လိုက်ပါသည်"})
    return {"status": "ok"}

@app.get("/api/download/{filename}")
async def download_file(filename: str):
    try:
        bucket = get_bucket()
        blob = bucket.blob(f"outputs/{filename}")
        if blob.exists():
            blob.content_disposition = f'attachment; filename="{filename}"'
            blob.content_type = 'application/octet-stream'
            blob.patch()
            try: blob.make_public()
            except: pass
            return RedirectResponse(url=blob.public_url)
    except: pass
    local_path = OUTPUT_DIR / filename
    if local_path.exists() and local_path.stat().st_size > 0:
        return FileResponse(str(local_path), media_type="application/octet-stream", filename=filename, headers={"Content-Disposition": f'attachment; filename="{filename}"'})
    raise HTTPException(status_code=404, detail="ဖိုင် ရှာမတွေ့ပါ။")

@app.get("/api/history")
async def get_history(authorization: Optional[str] = Header(None)):
    db = membership.SupabaseMembership()
    try: member = db.member_from_token(extract_token(authorization))
    except Exception: raise HTTPException(status_code=401, detail="Session expired")
    history_list, local_jobs = [], {}
    for f in sorted(UPLOAD_DIR.glob("job_*.json"), key=os.path.getmtime, reverse=True):
        try:
            job = json.loads(f.read_text(encoding="utf-8"))
            if job.get("user_email") == member.get("email"): local_jobs[job.get("id")] = job
        except: pass
    sorted_jobs = sorted(local_jobs.values(), key=lambda x: x.get("created_at", 0), reverse=True)
    for job in sorted_jobs:
        status = job.get("status")
        dl_url = job.get("download_url", "")
        history_list.append({"filename": job.get("filename", "Video Recap"), "status": "success" if status == "done" else ("fail" if status in ["error", "cancelled"] else "running"), "download_url": dl_url if dl_url != "expired" else "", "thumb_url": job.get("thumb_url", ""), "duration": job.get("duration", 0), "date": datetime.fromtimestamp(job.get("created_at", time.time())).strftime("%Y-%m-%d %H:%M")})
    return history_list

def file_cleanup_worker():
    while True:
        now = time.time()
        for folder in [UPLOAD_DIR, OUTPUT_DIR]:
            for f in folder.iterdir():
                try:
                    if f.is_file() and (now - f.stat().st_mtime > 14400): f.unlink(missing_ok=True)
                except: pass
        time.sleep(3600)
import threading
threading.Thread(target=file_cleanup_worker, daemon=True).start()

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.getenv("PORT", 8080)))
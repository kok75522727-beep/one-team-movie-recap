from datetime import timedelta

@app.get("/api/download/{filename}")
async def download_file(filename: str):
    try:
        bucket = get_bucket()
        blob = bucket.blob(f"outputs/{filename}")
        
        # 1 နာရီ သက်တမ်းရှိပြီး ဖုန်းထဲ Force Download ဖြစ်စေမည့် Direct Signed URL
        signed_url = blob.generate_signed_url(
            version="v4",
            expiration=timedelta(hours=1),
            method="GET",
            response_disposition=f'attachment; filename="{filename}"'
        )
        return RedirectResponse(url=signed_url)
    except Exception:
        local_path = OUTPUT_DIR / filename
        if local_path.exists():
            return FileResponse(
                str(local_path),
                media_type="video/mp4",
                filename=filename,
                headers={"Content-Disposition": f'attachment; filename="{filename}"'}
            )
        raise HTTPException(status_code=404, detail="File not found")
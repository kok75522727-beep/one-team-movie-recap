"""FastAPI server for One Team Movie Recap Studio."""

from __future__ import annotations
import os, uuid, shutil, subprocess, requests, json, re
from pathlib import Path
from typing import Any, Optional
from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Header, Body
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import yt_dlp
import media_engine
import membership

app = FastAPI(title="One Team Movie Recap Studio")

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
UPLOAD_DIR = ROOT / "uploads"
OUTPUT_DIR = ROOT / "outputs"
FONTS_DIR = ROOT / "fonts"

for folder in [STATIC_DIR, UPLOAD_DIR, OUTPUT_DIR, FONTS_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/fonts", StaticFiles(directory=str(FONTS_DIR)), name="fonts")

class JobSettings(BaseModel):
    project_id: str
    settings: dict[str, Any]
    simple_api_key: Optional[str] = ""

def extract_token(auth_header: Optional[str]) -> str:
    if not auth_header: return ""
    if auth_header.startswith("Bearer "): return auth_header[7:]
    return auth_header

def save_data(type_str: str, id_str: str, data: dict):
    path = UPLOAD_DIR / f"{type_str}_{id_str}.json"
    path.write_text(json.dumps(data, ensure_ascii=False), encoding="utf-8")

def load_data(type_str: str, id_str: str) -> dict | None:
    path = UPLOAD_DIR / f"{type_str}_{id_str}.json"
    if path.exists(): return json.loads(path.read_text(encoding="utf-8"))
    return None

def update_job(job_id: str, updates: dict):
    job = load_data("job", job_id)
    if job:
        job.update(updates)
        save_data("job", job_id, job)

@app.get("/")
async def serve_index(): return FileResponse(STATIC_DIR / "editor.html")

@app.get("/login")
async def serve_login(): return FileResponse(STATIC_DIR / "login.html")

@app.get("/owner")
async def serve_owner(): return FileResponse(STATIC_DIR / "owner.html")

@app.get("/api/auth-config")
async def get_auth_config():
    db = membership.SupabaseMembership()
    return db.public_config()

@app.post("/api/browser-session")
async def bridge_session(): return {"status": "ok"}

@app.delete("/api/browser-session")
async def clear_session(): return {"status": "cleared"}

@app.get("/api/membership")
async def get_membership(authorization: Optional[str] = Header(None)):
    db = membership.SupabaseMembership()
    try:
        return db.member_from_token(extract_token(authorization))
    except Exception as e:
        raise HTTPException(status_code=401, detail=str(e))

@app.get("/api/plans")
async def get_plans():
    db = membership.SupabaseMembership()
    return db.public_payment_info()

@app.post("/api/payments")
async def submit_payment(
    authorization: Optional[str] = Header(None), kind: str = Form(...), offer_key: str = Form(...),
    payment_method: str = Form(...), transaction_id: str = Form(...), receipt: Optional[UploadFile] = File(None)
):
    db = membership.SupabaseMembership()
    try:
        member = db.member_from_token(extract_token(authorization))
        receipt_bytes = await receipt.read() if receipt else b""
        db.create_payment_request(member, kind=kind, offer_key=offer_key, payment_method=payment_method, transaction_id=transaction_id, receipt=receipt_bytes, receipt_mime=receipt.content_type if receipt else "")
        return {"status": "ok", "message": "ငွေလွှဲအချက်အလက် ပို့ပြီးပါပြီ။ Admin အတည်ပြုမှုကို စောင့်ပါ။"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/api/owner/metrics")
async def get_owner_metrics(authorization: Optional[str] = Header(None)):
    try:
        db = membership.SupabaseMembership()
        member = db.member_from_token(extract_token(authorization))
        if not member.get("is_admin"): raise HTTPException(status_code=403, detail="Owner only")
        return db.owner_overview()
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/owner/approve-payment")
async def approve_payment_api(payload: dict = Body(...), authorization: Optional[str] = Header(None)):
    try:
        db = membership.SupabaseMembership()
        member = db.member_from_token(extract_token(authorization))
        if not member.get("is_admin"): raise HTTPException(status_code=403, detail="Not authorized")
        req_id = payload.get("request_id") or payload.get("id")
        db.approve_payment(int(req_id), member.get("email", "admin"), payload.get("note", ""))
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/owner/reject-payment")
async def reject_payment_api(payload: dict = Body(...), authorization: Optional[str] = Header(None)):
    try:
        db = membership.SupabaseMembership()
        member = db.member_from_token(extract_token(authorization))
        if not member.get("is_admin"): raise HTTPException(status_code=403, detail="Not authorized")
        req_id = payload.get("request_id") or payload.get("id")
        db.reject_payment(int(req_id), member.get("email", "admin"), payload.get("note", ""))
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/owner/grant-credits")
async def grant_credits_api(payload: dict = Body(...), authorization: Optional[str] = Header(None)):
    try:
        db = membership.SupabaseMembership()
        member = db.member_from_token(extract_token(authorization))
        if not member.get("is_admin"): raise HTTPException(status_code=403, detail="Not authorized")
        db.grant_manual_credits(payload.get("email", ""), int(payload.get("credits", 1)), member.get("email", "admin"), payload.get("note", "Manual Grant"))
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/owner/extend-user")
async def extend_user_api(payload: dict = Body(...), authorization: Optional[str] = Header(None)):
    try:
        db = membership.SupabaseMembership()
        member = db.member_from_token(extract_token(authorization))
        if not member.get("is_admin"): raise HTTPException(status_code=403, detail="Not authorized")
        db.extend_user_plan(payload.get("email", ""), int(payload.get("days", 1)), member.get("email", "admin"))
        return {"status": "ok"}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/video")
async def upload_video(file: UploadFile = File(...), project_id: str = Form(...)):
    file_id = f"{uuid.uuid4()}_{file.filename}"
    target_path = UPLOAD_DIR / file_id
    with target_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    try:
        info = media_engine.probe_video(target_path)
        save_data("proj", project_id, {"video_path": str(target_path), "filename": file.filename, "info": info})
        return info
    except Exception as exc:
        target_path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=str(exc))

@app.get("/api/play/{filename}")
async def play_video(filename: str):
    file_path = UPLOAD_DIR / filename
    if not file_path.exists(): raise HTTPException(status_code=404)
    return FileResponse(file_path, media_type="video/mp4")

@app.post("/api/link-preview")
async def get_link_preview(payload: dict = Body(...)):
    url = payload.get("url", "").strip()
    if not url:
        raise HTTPException(status_code=400, detail="Link မပါပါ")
    
    project_id = str(uuid.uuid4())
    job_id = f"dl_{project_id}"
    
    save_data("job", job_id, {"status": "running", "progress": 0, "message": "Link ချိတ်ဆက်နေပါသည်...", "project_id": project_id})
    
    import threading
    def dl_worker():
        filename = f"link_{project_id}.mp4"
        dl_path = UPLOAD_DIR / filename
        try:
            if "tiktok.com" in url:
                api_res = requests.post("https://www.tikwm.com/api/", data={"url": url, "hd": 1}, timeout=15)
                if api_res.ok and api_res.json().get("data", {}).get("play"):
                    play_url = api_res.json()["data"]["play"]
                    vid_res = requests.get(play_url, stream=True, timeout=30)
                    if vid_res.ok:
                        total_length = int(vid_res.headers.get('content-length', 0))
                        dl_size = 0
                        with open(dl_path, 'wb') as f:
                            for chunk in vid_res.iter_content(chunk_size=8192):
                                if chunk:
                                    f.write(chunk)
                                    dl_size += len(chunk)
                                    if total_length > 0:
                                        pct = int((dl_size / total_length) * 100)
                                        update_job(job_id, {"progress": pct, "message": f"ဒေါင်းလုဒ်ဆွဲနေပါသည်... {pct}%"})
                if not dl_path.exists():
                    raise ValueError("TikTok API failed")
            else:
                def progress_hook(d):
                    if d['status'] == 'downloading':
                        p = d.get('_percent_str', '0%')
                        p = re.sub(r'\x1b\[[0-9;]*m', '', p).replace('%', '').strip()
                        try:
                            pct = int(float(p))
                            update_job(job_id, {"progress": pct, "message": f"ဒေါင်းလုဒ်ဆွဲနေပါသည်... {pct}%"})
                        except:
                            pass

                ydl_opts = {
                    'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
                    'outtmpl': str(dl_path),
                    'quiet': True,
                    'no_warnings': True,
                    'progress_hooks': [progress_hook],
                    'extractor_args': {'youtube': {'player_client': ['android']}},
                    'http_headers': {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
                    }
                }
                with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                    ydl.download([url])
                
            if not dl_path.exists():
                raise ValueError("Video ဖိုင်ကို ရယူနိုင်ခြင်းမရှိပါ")
                
            info = media_engine.probe_video(dl_path)
            save_data("proj", project_id, {"video_path": str(dl_path), "filename": filename, "info": info})
            
            update_job(job_id, {
                "status": "done",
                "progress": 100,
                "message": "ဒေါင်းလုဒ်ဆွဲခြင်း ပြီးဆုံးပါပြီ",
                "duration": info.get("duration", 0),
                "video_url": f"/api/play/{filename}"
            })
        except Exception as e:
            if dl_path.exists():
                dl_path.unlink(missing_ok=True)
            update_job(job_id, {"status": "error", "error": str(e), "message": "Link မှ ဒေါင်းလုဒ်ဆွဲ၍ မရပါ။"})

    threading.Thread(target=dl_worker, daemon=True).start()
    
    return {"status": "started", "job_id": job_id}

@app.post("/api/assets")
async def upload_asset(file: UploadFile = File(...), kind: str = Form(...), project_id: str = Form(...)):
    target_path = UPLOAD_DIR / f"{kind}_{uuid.uuid4()}_{file.filename}"
    with target_path.open("wb") as buffer: shutil.copyfileobj(file.file, buffer)
    return {"path": str(target_path)}

@app.post("/api/preview-ms-voice")
async def preview_ms_voice(payload: dict = Body(...)):
    voice_id = payload.get("voice", "Nilar")
    text = "မင်္ဂလာပါ၊ One Team မှ ကြိုဆိုပါတယ်။"
    api_key = os.getenv("GEMINI_API_KEY", "")
    try:
        if voice_id in media_engine.GEMINI_VOICES:
            audio_bytes = media_engine.generate_gemini_tts(text, voice_id, api_key)
        else:
            audio_bytes = media_engine.generate_microsoft_tts(text, voice_id)
        return Response(content=audio_bytes, media_type="audio/mpeg")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/jobs")
async def create_job(payload: JobSettings, authorization: Optional[str] = Header(None)):
    db = membership.SupabaseMembership()
    try:
        member = db.member_from_token(extract_token(authorization))
    except Exception:
        raise HTTPException(status_code=401, detail="Session expired")

    proj = load_data("proj", payload.project_id)
    if not proj: raise HTTPException(status_code=400, detail="Video ဖိုင် ရှာမတွေ့ပါ။")

    duration_seconds = float(proj["info"].get("duration", 0))
    plan = membership.effective_plan(member)
    
    try:
        entitlement = membership.evaluate_export(member, duration_seconds, db.successful_exports_today(member, plan))
    except Exception as e:
        raise HTTPException(status_code=403, detail=str(e))

    job_id = str(uuid.uuid4())
    job_data = {"id": job_id, "status": "running", "progress": 5, "step": "upload", "message": "အချက်အလက်များကို စစ်ဆေးနေပါသည်", "download_url": "", "error": ""}
    save_data("job", job_id, job_data)

    import threading
    def task_worker():
        try:
            settings = payload.settings
            api_key = payload.simple_api_key or os.getenv("GEMINI_API_KEY", "")
            video_path = Path(proj["video_path"])
            voice_choice = settings.get("voice", "Nilar")
            
            def update_progress(percent: int, msg: str):
                step = "render" if percent >= 80 else "voice" if percent >= 50 else "script" if percent >= 20 else "upload"
                update_job(job_id, {"progress": percent, "message": msg, "step": step})

            update_progress(25, "Script ရေးသားနေပါသည်")
            script = media_engine.generate_script(
                api_key=api_key, video_path=video_path, mime_type="video/mp4",
                language=settings.get("language", "Myanmar"), duration_seconds=int(duration_seconds),
                tone=settings.get("tone", "Cinematic"), recap_type=settings.get("recapType", "Movie Recap"),
                timing_mode="Natural", progress=update_progress
            )
            settings["script"] = script

            update_progress(65, "အသံ ဖိုင် ထုတ်ယူနေပါသည်")
            if voice_choice in media_engine.GEMINI_VOICES:
                tts_wav = media_engine.generate_gemini_tts(script, voice_choice, api_key)
            else:
                tts_wav = media_engine.generate_microsoft_tts(script, voice_choice)

            update_progress(80, "Final Video ပေါင်းစပ်နေပါသည်")
            out_file = OUTPUT_DIR / f"final_{job_id}.mp4"
            media_engine.render_final(video_path, tts_wav, settings, out_file)

            db.record_success(member, entitlement, duration_seconds)
            update_job(job_id, {"status": "done", "progress": 100, "message": "Final MP4 အဆင်သင့်ပါပြီ", "download_url": f"/api/download/{out_file.name}"})
        except Exception as exc:
            db.record_failure(member, duration_seconds, entitlement)
            update_job(job_id, {"status": "error", "error": str(exc), "message": "Video ထုတ်လုပ်မှု မအောင်မြင်ပါ"})

    threading.Thread(target=task_worker, daemon=True).start()
    return load_data("job", job_id)

@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    job = load_data("job", job_id)
    if not job: raise HTTPException(status_code=404, detail="Job not found")
    return job

@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str):
    update_job(job_id, {"status": "cancelled", "message": "လုပ်ငန်းစဉ်ကို ပယ်ဖျက်လိုက်ပါသည်"})
    return {"status": "ok"}

@app.get("/api/download/{filename}")
async def download_file(filename: str):
    return FileResponse(OUTPUT_DIR / filename, media_type="video/mp4", filename=filename)

if __name__ == "__main__":
    import uvicorn
    # အောက်ပါစာကြောင်းတွင် reload=True အား ဖယ်ရှားထားပြီးပါပြီ။ 
    # Cloud Run (သို့) Production တွင် တည်ငြိမ်စွာ အလုပ်လုပ်ပါမည်။
    uvicorn.run("main:app", host="0.0.0.0", port=int(os.getenv("PORT", 8080)))
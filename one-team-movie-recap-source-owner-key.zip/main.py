"""FastAPI server for One Team Movie Recap Studio."""

from __future__ import annotations

import os
import uuid
import shutil
from pathlib import Path
from typing import Any, Optional
from datetime import datetime, timezone

from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Header, Body
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import media_engine

app = FastAPI(title="One Team Movie Recap Studio")

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
UPLOAD_DIR = ROOT / "uploads"
OUTPUT_DIR = ROOT / "outputs"
FONTS_DIR = ROOT / "fonts"

for folder in [STATIC_DIR, UPLOAD_DIR, OUTPUT_DIR, FONTS_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/fonts", StaticFiles(directory=str(FONTS_DIR)), name="fonts")

JOBS: dict[str, dict[str, Any]] = {}
PROJECTS: dict[str, dict[str, Any]] = {}
DAILY_EXPORTS: dict[str, list[str]] = {}

# In-Memory DB (Owner စာရင်းနှင့် Payment အတွက်)
USERS_DB: list[dict[str, Any]] = [
    {"email": "owner@oneteam.com", "plan": "pro", "tier": "vip", "days_left": 30, "is_admin": True},
    {"email": "user1@gmail.com", "plan": "trial", "tier": "simple", "days_left": 3, "is_admin": False}
]

PAYMENTS_DB: list[dict[str, Any]] = [
    {
        "id": "pay_001",
        "user_email": "user1@gmail.com",
        "plan_type": "Pro VIP (30,000 MMK)",
        "payment_method": "KBZPay",
        "transaction_id": "TXN987654321",
        "status": "pending",
        "date": "2026-09-01 08:30"
    }
]

class JobSettings(BaseModel):
    project_id: str
    settings: dict[str, Any]
    simple_api_key: Optional[str] = ""

# --- Pages ---
@app.get("/")
async def serve_index():
    return FileResponse(STATIC_DIR / "editor.html")

@app.get("/login")
async def serve_login():
    # Login မျက်နှာပြင် အစစ်ကို ခေါ်ပေးရန် ပြင်ဆင်ထားသည်
    return FileResponse(STATIC_DIR / "login.html")

@app.get("/owner")
async def serve_owner():
    return FileResponse(STATIC_DIR / "owner.html")

# --- Auth & Session ---
@app.get("/api/auth-config")
async def get_auth_config():
    # Railway Variables များမှ တိုက်ရိုက်ဖတ်ရန်
    return {
        "enabled": os.getenv("AUTH_ENABLED", "true"),
        "url": os.getenv("SUPABASE_URL", ""),
        "anon_key": os.getenv("SUPABASE_ANON_KEY", "")
    }

@app.get("/api/membership")
async def get_membership(authorization: Optional[str] = Header(None)):
    # Owner Mail အတိအကျ ပြန်ပို့ပေးသည်
    return {
        "email": "owner@oneteam.com",
        "plan": "pro",
        "tier": "vip",
        "is_admin": True,
        "trial_days_remaining": 30,
        "trial_expired": False,
        "pending_payment": False,
    }

# --- Owner APIs ---
@app.get("/api/owner/metrics")
async def get_owner_metrics():
    done_jobs = sum(1 for j in JOBS.values() if j.get("status") == "done")
    return {
        "active_vip": len([u for u in USERS_DB if u.get("tier") == "vip"]),
        "simple_trial": len([u for u in USERS_DB if u.get("plan") == "trial"]),
        "pending_payments": len([p for p in PAYMENTS_DB if p.get("status") == "pending"]),
        "export_report": {"total": len(JOBS), "done": done_jobs},
        "payments": PAYMENTS_DB,
        "users": USERS_DB
    }

@app.post("/api/owner/bulk-repair")
async def bulk_repair_days(payload: dict = Body(...)):
    days = int(payload.get("days", 1))
    for u in USERS_DB:
        u["days_left"] = u.get("days_left", 0) + days
    return {"status": "ok", "message": f"User အားလုံးကို ရက် {days} ရက် တိုးပေးပြီးပါပြီ"}

@app.post("/api/owner/approve-payment")
async def approve_payment(payload: dict = Body(...)):
    tx_id = payload.get("transaction_id")
    for p in PAYMENTS_DB:
        if p.get("transaction_id") == tx_id:
            p["status"] = "approved"
            for u in USERS_DB:
                if u["email"] == p.get("user_email"):
                    u["tier"] = "vip"
                    u["plan"] = "pro"
                    u["days_left"] = u.get("days_left", 0) + 30
    return {"status": "ok", "message": "ငွေလွှဲ အတည်ပြုပြီး Pro VIP ပေးလိုက်ပါပြီ"}

@app.post("/api/owner/reject-payment")
async def reject_payment(payload: dict = Body(...)):
    tx_id = payload.get("transaction_id")
    for p in PAYMENTS_DB:
        if p.get("transaction_id") == tx_id:
            p["status"] = "rejected"
    return {"status": "ok", "message": "ငွေလွှဲ ပယ်ဖျက်ပြီးပါပြီ"}

# --- Video & Processing ---
@app.post("/api/video")
async def upload_video(file: UploadFile = File(...), project_id: str = Form(...)):
    file_id = f"{uuid.uuid4()}_{file.filename}"
    target_path = UPLOAD_DIR / file_id
    with target_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    try:
        info = media_engine.probe_video(target_path)
    except Exception as exc:
        target_path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=str(exc))

    if info.get("duration", 0) > 600:
        target_path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail="ဗီဒီယို အရှည်သည် အများဆုံး ၁၀ မိနစ်ထက် မကျော်ရပါ။")

    PROJECTS[project_id] = {
        "video_path": str(target_path),
        "filename": file.filename,
        "info": info
    }
    return info

@app.post("/api/preview-ms-voice")
async def preview_ms_voice(payload: dict = Body(...)):
    voice_id = payload.get("voice", "Nilar")
    text = "မင်္ဂလာပါ၊ One Team Movie Recap ရဲ့ အသံဖြစ်ပါတယ်"
    try:
        audio_bytes = media_engine.generate_microsoft_tts(text, voice_id)
        return Response(content=audio_bytes, media_type="audio/mpeg")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.post("/api/jobs")
async def create_job(payload: JobSettings):
    user_email = "owner@oneteam.com"
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    user_key = f"{user_email}_{today}"

    current_count = len(DAILY_EXPORTS.get(user_key, []))
    if current_count >= 5:
        raise HTTPException(status_code=429, detail="ယနေ့အတွက် ဗီဒီယို ၅ ပုဒ် ပြည့်သွားပါပြီ။")

    proj = PROJECTS.get(payload.project_id)
    if not proj:
        raise HTTPException(status_code=400, detail="Video ဖိုင် ရှာမတွေ့ပါ")

    if user_key not in DAILY_EXPORTS:
        DAILY_EXPORTS[user_key] = []
    DAILY_EXPORTS[user_key].append(str(uuid.uuid4()))

    job_id = str(uuid.uuid4())
    JOBS[job_id] = {
        "id": job_id,
        "status": "running",
        "progress": 5,
        "message": "စတင်နေပါသည်",
        "download_url": "",
        "error": ""
    }

    import threading
    def task_worker():
        try:
            settings = payload.settings
            video_path = Path(proj["video_path"])
            api_key = payload.simple_api_key or os.getenv("GEMINI_API_KEY", "")

            def update_progress(percent: int, msg: str):
                JOBS[job_id]["progress"] = percent
                JOBS[job_id]["message"] = msg

            update_progress(25, "Script ရေးသားနေပါသည်")
            script = media_engine.generate_script(
                api_key=api_key,
                video_path=video_path,
                mime_type="video/mp4",
                language=settings.get("language", "Myanmar"),
                duration_seconds=int(proj["info"]["duration"]),
                tone=settings.get("tone", "Cinematic"),
                recap_type=settings.get("recapType", "Movie Recap"),
                timing_mode="Natural",
                progress=update_progress
            )
            settings["script"] = script

            update_progress(60, "အသံဖိုင် ထုတ်ယူနေပါသည်")
            voice_choice = settings.get("voice", "Nilar")
            if voice_choice in media_engine.GEMINI_VOICES:
                tts_wav = media_engine.generate_gemini_tts(script, voice_choice, api_key)
            else:
                tts_wav = media_engine.generate_microsoft_tts(script, voice_choice)

            update_progress(85, "ဗီဒီယို ပေါင်းစပ်နေပါသည်")
            out_file = OUTPUT_DIR / f"final_{job_id}.mp4"
            media_engine.render_final(video_path, tts_wav, settings, out_file)

            JOBS[job_id]["status"] = "done"
            JOBS[job_id]["progress"] = 100
            JOBS[job_id]["message"] = "ဗီဒီယို အဆင်သင့်ဖြစ်ပါပြီ"
            JOBS[job_id]["download_url"] = f"/api/download/{out_file.name}"

        except Exception as exc:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["error"] = str(exc)

    threading.Thread(target=task_worker, daemon=True).start()
    return JOBS[job_id]

@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

@app.get("/api/download/{filename}")
async def download_file(filename: str):
    file_path = OUTPUT_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path, media_type="video/mp4", filename=filename)

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8080))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
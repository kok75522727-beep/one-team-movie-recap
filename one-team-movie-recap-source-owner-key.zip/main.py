"""FastAPI server for One Team Movie Recap Studio."""

from __future__ import annotations
import os, uuid, shutil, subprocess, requests
from pathlib import Path
from typing import Any, Optional
from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Header, Body
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import yt_dlp, media_engine, membership

app = FastAPI(title="One Team Movie Recap Studio")
ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
UPLOAD_DIR = ROOT / "uploads"
OUTPUT_DIR = ROOT / "outputs"
FONTS_DIR = ROOT / "fonts"

for folder in [STATIC_DIR, UPLOAD_DIR, OUTPUT_DIR, FONTS_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/fonts", StaticFiles(directory=str(FONTS_DIR)), name="fonts")

JOBS: dict[str, dict[str, Any]] = {}
PROJECTS: dict[str, dict[str, Any]] = {}

class JobSettings(BaseModel):
    project_id: str
    settings: dict[str, Any]
    simple_api_key: Optional[str] = ""

@app.get("/")
async def serve_index():
    return FileResponse(STATIC_DIR / "editor.html")

@app.post("/api/video")
async def upload_video(file: UploadFile = File(...), project_id: str = Form(...)):
    file_id = f"{uuid.uuid4()}_{file.filename}"
    target_path = UPLOAD_DIR / file_id
    with target_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    try:
        info = media_engine.probe_video(target_path)
    except Exception as exc:
        target_path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=str(exc))
    PROJECTS[project_id] = {"video_path": str(target_path), "filename": file.filename, "info": info}
    return info

@app.get("/api/play/{filename}")
async def play_video(filename: str):
    file_path = UPLOAD_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path, media_type="video/mp4")

@app.post("/api/link-preview")
async def get_link_preview(payload: dict = Body(...)):
    url = payload.get("url", "").strip()
    if not url:
        raise HTTPException(status_code=400, detail="Link မပါပါ")
    
    project_id = str(uuid.uuid4())
    filename = f"link_{project_id}.mp4"
    dl_path = UPLOAD_DIR / filename

    try:
        if "tiktok.com" in url:
            # TikTok IP Block ကို ကျော်ရန် External API အသုံးပြုခြင်း
            api_res = requests.post("https://www.tikwm.com/api/", data={"url": url, "hd": 1}, timeout=15)
            if api_res.ok and api_res.json().get("data", {}).get("play"):
                play_url = api_res.json()["data"]["play"]
                vid_res = requests.get(play_url, stream=True, timeout=30)
                if vid_res.ok:
                    with open(dl_path, 'wb') as f:
                        for chunk in vid_res.iter_content(chunk_size=8192):
                            f.write(chunk)
            if not dl_path.exists():
                raise ValueError("TikTok API failed")
        else:
            # YouTube အတွက် Android Client ပုံစံဖြင့် ဆွဲခြင်း
            ydl_opts = {
                'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
                'outtmpl': str(dl_path),
                'quiet': True, 'no_warnings': True,
                'extractor_args': {'youtube': {'player_client': ['android']}},
                'http_headers': {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'}
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                ydl.download([url])
            
        if not dl_path.exists():
            raise ValueError("Download failed")
            
        info = media_engine.probe_video(dl_path)
        PROJECTS[project_id] = {"video_path": str(dl_path), "filename": filename, "info": info}

        return {"status": "ok", "project_id": project_id, "duration": info.get("duration", 0), "video_url": f"/api/play/{filename}"}
    except Exception as e:
        if dl_path.exists(): dl_path.unlink()
        raise HTTPException(status_code=400, detail="Link မှ ဒေါင်းလုဒ်ဆွဲ၍ မရပါ။ (Private ဖြစ်နေနိုင်သည်)")

@app.post("/api/assets")
async def upload_asset(file: UploadFile = File(...), kind: str = Form(...), project_id: str = Form(...)):
    file_id = f"{kind}_{uuid.uuid4()}_{file.filename}"
    target_path = UPLOAD_DIR / file_id
    with target_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return {"path": str(target_path)}

@app.post("/api/jobs")
async def create_job(payload: JobSettings):
    proj = PROJECTS.get(payload.project_id)
    if not proj: raise HTTPException(status_code=400, detail="Video ရှာမတွေ့ပါ")
    duration_seconds = float(proj["info"].get("duration", 0))

    voice_choice = payload.settings.get("voice", "Nilar")
    job_id = str(uuid.uuid4())
    JOBS[job_id] = {"id": job_id, "status": "running", "progress": 5, "step": "upload", "message": "စတင်နေပါသည်", "download_url": "", "error": ""}

    import threading
    def task_worker():
        try:
            settings = payload.settings
            api_key = payload.simple_api_key
            video_path = Path(proj["video_path"])
            
            def update_progress(percent: int, msg: str):
                JOBS[job_id]["progress"] = percent
                JOBS[job_id]["message"] = msg
                if percent >= 50: JOBS[job_id]["step"] = "voice"
                elif percent >= 25: JOBS[job_id]["step"] = "script"

            update_progress(20, "Script ရေးသားနေပါသည်")
            script = media_engine.generate_script(
                api_key=api_key, video_path=video_path, mime_type="video/mp4",
                language=settings.get("language", "Myanmar"), duration_seconds=int(duration_seconds),
                tone=settings.get("tone", "Cinematic"), recap_type=settings.get("recapType", "Movie Recap"),
                timing_mode="Natural", progress=update_progress
            )
            settings["script"] = script

            update_progress(65, "အသံ ဖိုင် ထုတ်ယူနေပါသည်")
            tts_wav = media_engine.generate_microsoft_tts(script, voice_choice)

            update_progress(80, "Final Video ပေါင်းစပ်နေပါသည် (အသံထစ်ခြင်း ဖြေရှင်းထားသည်)")
            JOBS[job_id]["step"] = "render"
            out_file = OUTPUT_DIR / f"final_{job_id}.mp4"
            media_engine.render_final(video_path, tts_wav, settings, out_file)

            JOBS[job_id]["status"] = "done"
            JOBS[job_id]["progress"] = 100
            JOBS[job_id]["message"] = "Final MP4 အဆင်သင့်ပါပြီ"
            JOBS[job_id]["download_url"] = f"/api/download/{out_file.name}"

        except Exception as exc:
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["error"] = str(exc)
            JOBS[job_id]["message"] = "Video ထုတ်လုပ်မှု မအောင်မြင်ပါ"

    threading.Thread(target=task_worker, daemon=True).start()
    return JOBS[job_id]

@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job: raise HTTPException(status_code=404, detail="Job not found")
    return job

@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str):
    if job_id in JOBS:
        JOBS[job_id]["status"] = "cancelled"
        JOBS[job_id]["message"] = "လုပ်ငန်းစဉ်ကို ပယ်ဖျက်လိုက်ပါသည်"
    return {"status": "ok"}

@app.get("/api/download/{filename}")
async def download_file(filename: str):
    file_path = OUTPUT_DIR / filename
    if not file_path.exists(): raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path, media_type="video/mp4", filename=filename)

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8080))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
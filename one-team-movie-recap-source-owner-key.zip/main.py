"""FastAPI server for One Team Movie Recap Studio."""

from __future__ import annotations

import os
import uuid
import shutil
from pathlib import Path
from typing import Any, Optional

from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Header, Body
from fastapi.responses import FileResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import media_engine
import membership

app = FastAPI(title="One Team Movie Recap Studio")

ROOT = Path(__file__).resolve().parent
STATIC_DIR = ROOT / "static"
UPLOAD_DIR = ROOT / "uploads"
OUTPUT_DIR = ROOT / "outputs"
FONTS_DIR = ROOT / "fonts"

for folder in [STATIC_DIR, UPLOAD_DIR, OUTPUT_DIR, FONTS_DIR]:
    folder.mkdir(parents=True, exist_ok=True)

app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")
app.mount("/fonts", StaticFiles(directory=str(FONTS_DIR)), name="fonts")

JOBS: dict[str, dict[str, Any]] = {}
PROJECTS: dict[str, dict[str, Any]] = {}

class JobSettings(BaseModel):
    project_id: str
    settings: dict[str, Any]
    simple_api_key: Optional[str] = ""

def extract_token(auth_header: Optional[str]) -> str:
    if not auth_header:
        return ""
    if auth_header.startswith("Bearer "):
        return auth_header[7:]
    return auth_header

# --- Pages ---
@app.get("/")
async def serve_index():
    index_file = STATIC_DIR / "editor.html"
    if not index_file.exists():
        raise HTTPException(status_code=404, detail="editor.html not found")
    return FileResponse(index_file)

@app.get("/login")
async def serve_login():
    login_file = STATIC_DIR / "login.html"
    if not login_file.exists():
        return Response(content="<h1>Error: login.html မရှိပါ</h1>", media_type="text/html")
    return FileResponse(login_file)

@app.get("/owner")
async def serve_owner():
    owner_file = STATIC_DIR / "owner.html"
    if not owner_file.exists():
        return Response(content="<h1>Error: owner.html မရှိပါ</h1>", media_type="text/html")
    return FileResponse(owner_file)

# --- Auth & Config APIs ---
@app.get("/api/auth-config")
async def get_auth_config():
    db = membership.SupabaseMembership()
    return db.public_config()

@app.post("/api/browser-session")
async def bridge_session():
    return {"status": "ok"}

@app.delete("/api/browser-session")
async def clear_session():
    return {"status": "cleared"}

@app.get("/api/membership")
async def get_membership(authorization: Optional[str] = Header(None)):
    db = membership.SupabaseMembership()
    try:
        token = extract_token(authorization)
        return db.member_from_token(token)
    except membership.MembershipError as e:
        raise HTTPException(status_code=401, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/plans")
async def get_plans():
    db = membership.SupabaseMembership()
    return db.public_payment_info()

@app.post("/api/payments")
async def submit_payment(
    authorization: Optional[str] = Header(None),
    kind: str = Form(...),
    offer_key: str = Form(...),
    payment_method: str = Form(...),
    transaction_id: str = Form(...),
    receipt: Optional[UploadFile] = File(None)
):
    db = membership.SupabaseMembership()
    try:
        token = extract_token(authorization)
        member = db.member_from_token(token)
        receipt_bytes = await receipt.read() if receipt else b""
        receipt_mime = receipt.content_type if receipt else ""
        
        db.create_payment_request(
            member, kind=kind, offer_key=offer_key, payment_method=payment_method,
            transaction_id=transaction_id, receipt=receipt_bytes, receipt_mime=receipt_mime
        )
        return {"status": "ok", "message": "ငွေလွှဲအချက်အလက် ပို့ပြီးပါပြီ။ Admin အတည်ပြုမှုကို စောင့်ပါ။"}
    except membership.MembershipError as e:
        raise HTTPException(status_code=400, detail=str(e))

# --- Media APIs ---
@app.post("/api/video")
async def upload_video(file: UploadFile = File(...), project_id: str = Form(...)):
    file_id = f"{uuid.uuid4()}_{file.filename}"
    target_path = UPLOAD_DIR / file_id
    with target_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)

    try:
        info = media_engine.probe_video(target_path)
    except Exception as exc:
        target_path.unlink(missing_ok=True)
        raise HTTPException(status_code=400, detail=str(exc))

    PROJECTS[project_id] = {
        "video_path": str(target_path),
        "filename": file.filename,
        "info": info
    }
    return info

@app.post("/api/assets")
async def upload_asset(file: UploadFile = File(...), kind: str = Form(...), project_id: str = Form(...)):
    file_id = f"{kind}_{uuid.uuid4()}_{file.filename}"
    target_path = UPLOAD_DIR / file_id
    with target_path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    return {"path": str(target_path)}

@app.post("/api/preview-ms-voice")
async def preview_ms_voice(payload: dict = Body(...)):
    voice_id = payload.get("voice", "Nilar")
    # အစ်ကို လိုချင်သော အသံစမ်းသည့် စာသား
    text = "မင်္ဂလာပါ၊ One Team မှ ကြိုဆိုပါတယ်။"
    try:
        audio_bytes = media_engine.generate_microsoft_tts(text, voice_id)
        return Response(content=audio_bytes, media_type="audio/mpeg")
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

# --- Jobs Processing ---
@app.post("/api/jobs")
async def create_job(payload: JobSettings, authorization: Optional[str] = Header(None)):
    db = membership.SupabaseMembership()
    try:
        token = extract_token(authorization)
        member = db.member_from_token(token)
    except membership.MembershipError as e:
        raise HTTPException(status_code=401, detail=str(e))

    proj = PROJECTS.get(payload.project_id)
    if not proj:
        raise HTTPException(status_code=400, detail="Video ဖိုင် ရှာမတွေ့ပါ၊ ပြန်လည် တင်ပေးပါ")

    duration_seconds = float(proj["info"].get("duration", 0))
    plan = membership.effective_plan(member)
    successful_today = db.successful_exports_today(member, plan)

    try:
        entitlement = db.evaluate_export(member, duration_seconds, successful_today)
    except membership.MembershipError as e:
        raise HTTPException(status_code=403, detail=str(e))

    voice_choice = payload.settings.get("voice", "Nilar")
    vip_voices = ["Ava", "Andrew", "Emma", "Brian", "Vivienne", "Remy", "Seraphina", "Florian", "Xiaoxiao", "Giuseppe"]
    if voice_choice in vip_voices and not member.get("is_admin"):
        if member.get("effective_plan") != "pro":
            raise HTTPException(status_code=403, detail="ဤအသံကို Pro VIP များသာ အသုံးပြုနိုင်ပါသည်။ Plan ဝယ်ယူပါ။")

    job_id = str(uuid.uuid4())
    JOBS[job_id] = {
        "id": job_id, "status": "running", "progress": 5, "step": "upload",
        "message": "အချက်အလက်များကို စစ်ဆေးနေပါသည်", "download_url": "", "error": ""
    }

    import threading
    def task_worker():
        try:
            settings = payload.settings
            video_path = Path(proj["video_path"])
            api_key = payload.simple_api_key or os.getenv("GEMINI_API_KEY", "")

            def update_progress(percent: int, msg: str):
                JOBS[job_id]["progress"] = percent
                JOBS[job_id]["message"] = msg
                if percent >= 50:
                    JOBS[job_id]["step"] = "voice"
                elif percent >= 25:
                    JOBS[job_id]["step"] = "script"

            update_progress(20, "Script ရေးသားနေပါသည်")
            script = media_engine.generate_script(
                api_key=api_key, video_path=video_path, mime_type="video/mp4",
                language=settings.get("language", "Myanmar"), duration_seconds=int(duration_seconds),
                tone=settings.get("tone", "Cinematic"), recap_type=settings.get("recapType", "Movie Recap"),
                timing_mode="Natural", progress=update_progress
            )
            settings["script"] = script

            update_progress(65, "အသံ ဖိုင် ထုတ်ယူနေပါသည်")
            if voice_choice in media_engine.GEMINI_VOICES:
                tts_wav = media_engine.generate_gemini_tts(script, voice_choice, api_key)
            else:
                tts_wav = media_engine.generate_microsoft_tts(script, voice_choice)

            update_progress(80, "Final Video ပေါင်းစပ်နေပါသည်")
            JOBS[job_id]["step"] = "render"
            out_file = OUTPUT_DIR / f"final_{job_id}.mp4"
            media_engine.render_final(video_path, tts_wav, settings, out_file)

            db.record_success(member, entitlement, duration_seconds)

            JOBS[job_id]["status"] = "done"
            JOBS[job_id]["progress"] = 100
            JOBS[job_id]["message"] = "Final MP4 အဆင်သင့်ပါပြီ"
            JOBS[job_id]["download_url"] = f"/api/download/{out_file.name}"

        except Exception as exc:
            db.record_failure(member, duration_seconds, entitlement)
            JOBS[job_id]["status"] = "error"
            JOBS[job_id]["error"] = str(exc)
            JOBS[job_id]["message"] = "Video ထုတ်လုပ်မှု မအောင်မြင်ပါ"

    threading.Thread(target=task_worker, daemon=True).start()
    return JOBS[job_id]

@app.get("/api/jobs/{job_id}")
async def get_job(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job

@app.post("/api/jobs/{job_id}/cancel")
async def cancel_job(job_id: str):
    if job_id in JOBS:
        JOBS[job_id]["status"] = "cancelled"
        JOBS[job_id]["message"] = "လုပ်ငန်းစဉ်ကို ပယ်ဖျက်လိုက်ပါသည်"
    return {"status": "ok"}

@app.get("/api/download/{filename}")
async def download_file(filename: str):
    file_path = OUTPUT_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    return FileResponse(file_path, media_type="video/mp4", filename=filename)

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8080))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
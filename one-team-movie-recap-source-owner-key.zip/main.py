@app.get("/api/download/{filename}")
async def download_file(filename: str):
    local_path = OUTPUT_DIR / filename
    
    # ၁။ ဆာဗာထဲမှာ ဖိုင်မရှိသေးရင် GCS ကနေ အရင်ဆွဲယူပါမယ်
    if not local_path.exists():
        download_from_gcs(f"outputs/{filename}", local_path)
        
    # ၂။ ဆာဗာကနေ ဖုန်းထဲကို တိုက်ရိုက် (Redirect လုံးဝမသုံးဘဲ) File ချပေးပါမယ်
    if local_path.exists():
        return FileResponse(
            path=str(local_path),
            media_type="video/mp4",
            filename=filename,
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
                "Access-Control-Expose-Headers": "Content-Disposition"
            }
        )
        
    # ၃။ ဖိုင်တကယ်မရှိရင် Error ပြပါမယ်
    raise HTTPException(status_code=404, detail="ဗီဒီယိုဖိုင် ရှာမတွေ့ပါ။")
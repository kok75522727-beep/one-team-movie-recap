from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

def read(name): return (ROOT/name).read_text(encoding="utf-8")

def test_python_and_core_routes_exist():
    s=read("main.py")
    for x in ["/api/link-preview","/api/jobs","/api/jobs/{job_id}","/api/download/{filename}","/api/owner/approve-payment","/api/owner/reject-payment","/api/owner/grant-credits"]: assert x in s

def test_download_progress_and_retries_exist():
    s=read("main.py")
    for x in ["progress(pct", "retries", "fragment_retries", "time.sleep(2 ** attempt)"]: assert x in s

def test_every_account_uses_own_api_key():
    s=read("main.py"); j=read("static/editor.js")
    assert 'simple_api_key' in s
    assert 'ကိုယ်ပိုင် Gemini API Key' in s
    assert 'function requiresUserKey() { return true; }' in j
    assert "sessionStorage.setItem('one-team-gemini-key'" in j
    assert 'localStorage' not in j

def test_link_download_polling_is_percent_based():
    j=read("static/editor.js")
    for x in ["job.progress", "linkProgress", "linkLoadingPercent", "setTimeout(pollJob, 1500)"]: assert x in j

def test_renderer_has_blur_logo_subtitle_controls():
    s=read("media_engine.py")
    for x in ["blur_masks","blur_strength","blur_layer","subtitle_font","subtitle_x","subtitle_y","logo_size","logo_x","logo_y","music_volume"]: assert x in s

def test_pytest_root_path_is_configured():
    assert (ROOT/"pytest.ini").is_file()

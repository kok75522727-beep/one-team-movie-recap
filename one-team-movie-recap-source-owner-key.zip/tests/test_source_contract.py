from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_browser_editor_keeps_drag_local_and_one_click_export() -> None:
    source = (ROOT / "static" / "editor.js").read_text(encoding="utf-8")
    assert "pointermove" in source
    assert "state.masks" in source
    assert "fetch('/api/jobs'" in source
    assert "setTimeout(pollJob, 1500)" in source
    assert "location.reload" not in source


def test_customer_gemini_key_is_session_only_and_server_never_falls_back() -> None:
    source = (ROOT / "static" / "editor.js").read_text(encoding="utf-8")
    assert "sessionStorage.setItem('one-team-gemini-key'" in source
    assert "localStorage" not in source
    server = (ROOT / "main.py").read_text(encoding="utf-8")
    membership = (ROOT / "membership.py").read_text(encoding="utf-8")
    assert "simple_api_key" in server
    assert 'key_mode_for' in membership
    assert 'return "user"' in membership
    assert "ONE_TEAM_VIP_GEMINI_API_KEY" not in server
    assert "generate_gemini_tts(script" in server
    assert "generate_microsoft_tts(script" in server


def test_owner_and_customers_require_submitted_gemini_key() -> None:
    server = (ROOT / "main.py").read_text(encoding="utf-8")
    editor = (ROOT / "static" / "editor.js").read_text(encoding="utf-8")
    markup = (ROOT / "static" / "editor.html").read_text(encoding="utf-8")
    assert 'All accounts, including Owner Pro' in server
    assert 'Gemini အသံ/Script အတွက် Gemini API Key ထည့်ပါ' in server
    assert 'function requiresUserKey() { return true; }' in editor
    assert 'id="keyButton"' in markup
    assert 'https://aistudio.google.com/app/apikey' in markup


def test_both_voice_providers_are_explicit_and_menu_has_twelve_choices() -> None:
    source = (ROOT / "media_engine.py").read_text(encoding="utf-8")
    for marker in ("GEMINI_VOICES", "gemini-3.1-flash-tts-preview", "AZURE_SPEECH_KEY", "AZURE_SPEECH_REGION", "cognitiveservices/v1", "Ocp-Apim-Subscription-Key", "my-MM-NilarNeural"):
        assert marker in source
    assert source.count('"Kore"') >= 1
    markup = (ROOT / "static" / "editor.html").read_text(encoding="utf-8")
    assert markup.count('<option value="') >= 12
    assert "Gemini Voice" in markup
    assert "User Key" not in markup
    assert "Microsoft Voice · One Team" in markup
    assert "Video ကနေ Script အလိုအလျောက်ရေးပြီး" in markup


def test_payment_owner_analytics_and_quota_controls_are_server_side() -> None:
    server = (ROOT / "main.py").read_text(encoding="utf-8")
    for marker in ("/api/payments", "/api/owner/overview", "/api/owner/quota-override", "owner_member", "MEMBERSHIP.approve_payment", "MEMBERSHIP.reject_payment", "MEMBERSHIP.set_daily_quota_bonus"):
        assert marker in server
    membership = (ROOT / "membership.py").read_text(encoding="utf-8")
    for marker in ("payment_requests", "status=eq.submitted", "amount_mmk", "requested_tier", "usage_by_plan", "daily_quota_bonus", "repair_days", "SUPABASE_SERVICE_ROLE_KEY"):
        assert marker in membership
    migration = (ROOT / "supabase_one_team_plan_payment_migration.sql").read_text(encoding="utf-8")
    assert "daily_quota_bonus" in migration
    assert "export_usage_plan_outcome_day" in migration


def test_dedicated_login_google_oauth_and_protected_owner_view_exist() -> None:
    login = (ROOT / "static" / "login.js").read_text(encoding="utf-8")
    editor = (ROOT / "static" / "editor.js").read_text(encoding="utf-8")
    server = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "signInWithOAuth" in login
    assert "provider: 'google'" in login
    assert "window.location.replace('/login')" in editor
    assert "/api/browser-session" in server
    assert "verified_browser_member(one_team_session)" in server
    assert "verified_browser_member(one_team_session, owner_only=True)" in server
    assert '"one_team_session"' in server
    assert (ROOT / "static" / "owner.html").is_file()


def test_final_renderer_accepts_overlay_settings() -> None:
    source = (ROOT / "media_engine.py").read_text(encoding="utf-8")
    for marker in ("blur_masks", "subtitle_font", "subtitle_x", "subtitle_y", "logo_text", "logo_size", "logo_x", "logo_y", "fitted_source_rect", "auto_zoom", "background_blur", "music_volume"):
        assert marker in source


def test_voice_tab_is_automatic_movie_recap_voice_not_a_manual_tts_page() -> None:
    markup = (ROOT / "static" / "editor.html").read_text(encoding="utf-8")
    voice_page = markup.split('data-page="voice"', 1)[1].split("</div>", 1)[0]
    assert "Video ကနေ Script အလိုအလျောက်ရေးပြီး" in voice_page
    assert "textarea" not in voice_page
    assert 'type="text"' not in voice_page


def test_editor_does_not_submit_a_client_selected_plan() -> None:
    source = (ROOT / "static" / "editor.js").read_text(encoding="utf-8")
    assert "plan: sessionStorage" not in source
    assert "relativePoint" in source
    assert "state.activeTab === 'blur'" in source
    server = (ROOT / "main.py").read_text(encoding="utf-8")
    assert "MEMBERSHIP.member_from_token" in server
    assert "evaluate_export" in server
    assert "existing.status in {\"queued\", \"running\"}" in server
    assert "job.status, job.message = \"cancelled\"" in server

from datetime import datetime, timezone
import pytest
from membership import (
    VIP_TIERS, MembershipError, credits_for_duration, effective_plan, evaluate_export,
    myanmar_export_day, simple_trial_days_remaining, simple_trial_expired, key_mode_for
)

def member(**overrides):
    return {"status":"active","plan":"simple","role":"member","credit_balance":0,**overrides}

def test_vip_uses_customer_key_and_daily_limits():
    assert all(v["key_mode"] == "user" for v in VIP_TIERS.values())
    assert evaluate_export(member(plan="pro",subscription_tier="silver_vip"),300,0).key_mode == "user"
    assert evaluate_export(member(plan="pro",subscription_tier="gold_vip"),300,3).key_mode == "user"

def test_trial_limit_and_expiry():
    assert evaluate_export(member(),300,0).route == "trial"
    with pytest.raises(MembershipError): evaluate_export(member(),300,2)
    assert simple_trial_expired(member(plan_expires_at="2025-01-01T00:00:00Z"))
    assert simple_trial_days_remaining(member(plan_expires_at="2026-09-02T01:00:00Z"), datetime(2026,8,27,tzinfo=timezone.utc)) == 7

def test_credits_are_duration_based():
    assert credits_for_duration(180) == 3
    assert credits_for_duration(3600) == 60

def test_admin_bypasses_customer_quota_but_still_uses_own_key(monkeypatch):
    monkeypatch.setenv("ONE_TEAM_ADMIN_EMAIL","owner@example.com")
    owner=member(email="owner@example.com",role="admin",plan="pro",subscription_tier="gold_vip")
    ent=evaluate_export(owner,3600,999)
    assert (ent.route,ent.key_mode)==("owner","user")
    assert key_mode_for(owner)=="user"

def test_day_and_plan():
    assert myanmar_export_day(datetime(2026,8,26,18,0,tzinfo=timezone.utc)) == "2026-08-27"
    assert effective_plan(member(plan="pro",plan_expires_at="2025-01-01T00:00:00Z")) == "none"

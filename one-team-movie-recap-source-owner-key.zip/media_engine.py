"""Server-side media pipeline for One Team Movie Recap."""

from __future__ import annotations
import base64, io, json, math, os, wave, re, shutil, subprocess, tempfile, time, unicodedata, hashlib
import urllib.parse
from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape as xml_escape
import requests
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parent
FONTS = ROOT / "fonts"

FALLBACK_TEXT_MODELS = ["gemini-2.5-flash", "gemini-1.5-pro", "gemini-1.5-flash"]
DEFAULT_MICROSOFT_VOICE = "my-MM-NilarNeural"

GEMINI_VOICES = ["Aoede", "Charon", "Fenrir", "Kore", "Leda", "Orus", "Puck", "Zephyr", "Achernar", "Enceladus"]
MICROSOFT_VOICES = {
    "Nilar": "my-MM-NilarNeural", "Thiha": "my-MM-ThihaNeural",
    "Ava": "en-US-AvaMultilingualNeural", "Andrew": "en-US-AndrewMultilingualNeural",
    "Emma": "en-US-EmmaMultilingualNeural", "Brian": "en-US-BrianMultilingualNeural",
    "Vivienne": "fr-FR-VivienneMultilingualNeural", "Remy": "fr-FR-RemyMultilingualNeural",
    "Seraphina": "de-DE-SeraphinaMultilingualNeural", "Florian": "de-DE-FlorianMultilingualNeural",
    "Xiaoxiao": "zh-CN-XiaoxiaoMultilingualNeural", "Giuseppe": "it-IT-GiuseppeMultilingualNeural"
}

FONT_FILES = {
    "Noto Sans Myanmar": FONTS / "NotoSansMyanmar-Regular.ttf",
    "Pyidaungsu": FONTS / "pyidaungsu_regular.ttf",
    "Pyidaungsu Bold": FONTS / "pyidaungsu_bold.ttf"
}
FONT_FAMILIES = {
    "Noto Sans Myanmar": "Noto Sans Myanmar",
    "Pyidaungsu": "Pyidaungsu Green",
    "Pyidaungsu Bold": "Pyidaungsu Bold"
}

def _run(command: list[str], timeout: int = 2400) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0: raise RuntimeError((result.stderr or "FFmpeg failed")[-1800:])
    return result

def get_audio_duration(audio_path: Path) -> float:
    try:
        res = _run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(audio_path)], timeout=15)
        return float(res.stdout.strip() or 0.0)
    except: return 0.0

def probe_video(path: Path) -> dict[str, Any]:
    try:
        result = _run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,duration", "-of", "json", str(path)], timeout=45)
        stream = (json.loads(result.stdout).get("streams") or [{}])[0]
        duration = float(stream.get("duration") or 0)
        if not duration:
            duration = float(_run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)], timeout=45).stdout.strip() or 0)
        has_audio = False
        try:
            a_res = _run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(path)], timeout=15)
            if "audio" in a_res.stdout.lower(): has_audio = True
        except: pass
        if duration <= 0: raise ValueError("missing video metadata")
        return {"width": int(stream.get("width") or 0), "height": int(stream.get("height") or 0), "duration": duration, "has_audio": has_audio}
    except Exception as exc: raise RuntimeError("Video information ကိုမဖတ်နိုင်ပါ။") from exc

# --- GEMINI NATIVE VIDEO UPLOAD API ---
def upload_video_to_gemini(video_path: Path, api_key: str, progress=None) -> dict[str, str]:
    if progress: progress(30, "AI ဆာဗာသို့ ဗီဒီယို ပေးပို့နေပါသည်...")
    
    file_size = video_path.stat().st_size
    upload_url = f"https://generativelanguage.googleapis.com/upload/v1beta/files?key={api_key}"
    headers = {
        "X-Goog-Upload-Protocol": "raw",
        "X-Goog-Upload-Header-Content-Length": str(file_size),
        "X-Goog-Upload-Header-Content-Type": "video/mp4",
        "Content-Type": "video/mp4"
    }
    
    with open(video_path, "rb") as f:
        res = requests.post(upload_url, headers=headers, data=f, timeout=1200)
    if not res.ok: raise RuntimeError(f"Video တင်ခြင်း မအောင်မြင်ပါ: {res.text}")
    
    file_info = res.json().get("file", {})
    file_name = file_info.get("name")
    file_uri = file_info.get("uri")
    
    if progress: progress(45, "AI မှ ဗီဒီယိုကို ကြည့်ရှုလေ့လာနေပါသည်...")
    
    get_url = f"https://generativelanguage.googleapis.com/v1beta/{file_name}?key={api_key}"
    for _ in range(30):
        chk = requests.get(get_url, timeout=30).json()
        state = chk.get("state")
        if state == "ACTIVE": return {"fileUri": file_uri, "mimeType": "video/mp4", "name": file_name}
        if state == "FAILED": raise RuntimeError("AI မှ ဗီဒီယိုကို လေ့လာခြင်း မအောင်မြင်ပါ။")
        time.sleep(5)
    
    return {"fileUri": file_uri, "mimeType": "video/mp4", "name": file_name}

def delete_gemini_file(file_name: str, api_key: str):
    try: requests.delete(f"https://generativelanguage.googleapis.com/v1beta/{file_name}?key={api_key}", timeout=10)
    except: pass

def _generate_content(api_key: str, parts: list[dict[str, Any]], *, config: dict[str, Any], timeout: int) -> dict[str, Any]:
    for current_model in FALLBACK_TEXT_MODELS:
        try:
            url = f"https://generativelanguage.googleapis.com/v1beta/models/{current_model}:generateContent?key={api_key}"
            response = requests.post(url, json={"contents": [{"role": "user", "parts": parts}], "generationConfig": config}, timeout=timeout)
            if response.ok: return response.json()
        except: pass
    raise RuntimeError("AI ဆာဗာများ အလုပ်များနေပါသည်။")

def generate_script(api_key: str, video_path: Path, mime_type: str, language: str, duration_seconds: int, tone: str, recap_type: str, timing_mode: str, progress=None) -> str:
    gemini_file = None
    try:
        vid_info = probe_video(video_path)
        has_audio = vid_info.get("has_audio", False)
        
        gemini_file = upload_video_to_gemini(video_path, api_key, progress)
        parts = [{"fileData": {"fileUri": gemini_file["fileUri"], "mimeType": gemini_file["mimeType"]}}]
        
        if progress: progress(55, "Script ရေးသားနေပါသည်...")

        # 4-Mode System Logic (UI တွင် ၄ မျိုးရွေးနိုင်သည်)
        if (recap_type == "Simple Movie" or recap_type == "Translate Recap") and has_audio:
            instruction = (
                f"You are a professional dubbing translator. Watch the video and listen to the audio carefully. "
                f"Translate the EXACT spoken dialogue into {language} ({tone} tone). "
                "CRITICAL RULES: "
                "1. DO NOT invent stories or add narration. Translate ONLY what the characters say. "
                "2. Include timestamps for each dialogue line (e.g., [00:15 - 00:18] Hello). "
                "3. If there is NO speech (silent/music), do not write anything for that section."
            )
        elif not has_audio or recap_type == "Silent Recap":
            instruction = (
                f"You are an expert storyteller. This video has NO dialogue. Watch the actions, environment, and facial expressions closely. "
                f"Create a highly engaging narrative story in {language} ({tone} tone) describing what is happening. "
                f"Video duration is {duration_seconds} seconds. Keep the pacing natural. Return ONLY the spoken narrative."
            )
        else: # Raw to Recap (Movie Recap)
            instruction = (
                f"You are a professional movie recapper. Watch the visual frames AND listen to the audio carefully. "
                f"Translate the foreign dialogue naturally AND describe the actions to form a flowing recap story in {language} ({tone} tone). "
                f"Video duration is {duration_seconds} seconds. Return ONLY the spoken text, without any timestamps or formatting."
            )

        parts.append({"text": instruction})
        res = _generate_content(api_key, parts, config={"temperature": 0.3}, timeout=180)
        text = "\n".join(str(p.get("text") or "") for c in res.get("candidates", []) for p in c.get("content", {}).get("parts", [])).strip()
        if not text: raise RuntimeError("Script မပြန်လာပါ။")
        
        return re.sub(r'\[\d{2}:\d{2}\s*-\s*\d{2}:\d{2}\]', '', text) if (recap_type != "Simple Movie" and recap_type != "Translate Recap") else text

    finally:
        if gemini_file and gemini_file.get("name"):
            delete_gemini_file(gemini_file["name"], api_key)

# -------------------------------------------------------------------------------------
# PILLOW TOP-HOOK TEXT GENERATOR (FOR BOTH VIDEO & THUMBNAIL)
# -------------------------------------------------------------------------------------
def create_title_image(text: str, width: int, output_path: Path):
    font_path = str(FONT_FILES.get("Pyidaungsu Bold", FONT_FILES.get("Noto Sans Myanmar")))
    try:
        font = ImageFont.truetype(font_path, size=52)
    except:
        font = ImageFont.load_default()
    
    # Calculate text size using dummy image
    dummy = Image.new("RGBA", (1, 1))
    draw = ImageDraw.Draw(dummy)
    bbox = draw.textbbox((0, 0), text, font=font)
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    
    box_padding_x = 45
    box_padding_y = 25
    img_w = tw + box_padding_x * 2
    img_h = th + box_padding_y * 2
    
    img = Image.new("RGBA", (img_w, img_h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Draw Orange Box Background with Rounded Corners
    draw.rounded_rectangle((0, 0, img_w, img_h), radius=22, fill="#f59e0b")
    
    # Draw Black Shadow for Text
    shadow_offset = 3
    draw.text((box_padding_x + shadow_offset, box_padding_y + shadow_offset), text, font=font, fill="black")
    
    # Draw White Text
    draw.text((box_padding_x, box_padding_y), text, font=font, fill="white")
    
    # Responsive Scaling to fit video/thumbnail width
    target_width = width * 0.85
    if img_w > target_width:
        scale = target_width / img_w
        img = img.resize((int(img_w * scale), int(img_h * scale)), Image.Resampling.LANCZOS)
        
    img.save(output_path, "PNG")
    return output_path

# -------------------------------------------------------------------------------------
# THUMBNAIL GENERATOR (WITH CLEAN BACKGROUND & PYTHON TEXT OVERLAY)
# -------------------------------------------------------------------------------------
def generate_thumbnail(script: str, api_key: str, output_path: Path, settings: dict[str, Any] = None) -> Path | None:
    try:
        if not settings: settings = {}
        aspect = str(settings.get("aspect", "9:16"))
        
        # 1. Ask AI for 4-Word Viral Hook
        parts = [{"text": f"Generate a short viral Burmese hook (max 4 words) for this video recap script. Return ONLY the text. Context: {script[:500]}"}]
        hook_text = "ဘာဖြစ်သွားတာလဲ?"
        try:
            res = _generate_content(api_key, parts, config={"temperature": 0.7}, timeout=60)
            text_res = "\n".join(str(p.get("text") or "") for c in res.get("candidates", []) for p in c.get("content", {}).get("parts", [])).strip()
            if text_res: hook_text = text_res[:25]
        except: pass
        
        # 2. Dynamic Aspect Ratio for AI Cover
        imagen_ratio = "3:4" if aspect == "9:16" else ("16:9" if aspect == "16:9" else "1:1")
        
        # 3. Clean Master Prompt (NO TEXT INSTRUCTIONS)
        master_prompt = f"Create a viral cinematic YouTube thumbnail based on the following movie scene: {script[:500]}. Main Subject: Keep the main focus on a central character from the scene. Enhance facial details, sharp eyes, emotional expression, realistic skin texture, dramatic lighting, ultra HD quality. Background: Create a dramatic Korean drama/movie style background. Add depth, cinematic atmosphere, realistic environment, emotional storytelling, bokeh lights, volumetric lighting. Style: hyper realistic, 8K quality, dramatic storytelling, professional news recap style. NO TEXT, NO LETTERS IN THE IMAGE."

        imagen_url = f"https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-fast-generate-001:predict?key={api_key}"
        img_res = requests.post(imagen_url, json={"instances": [{"prompt": master_prompt}], "parameters": {"sampleCount": 1, "aspectRatio": imagen_ratio}}, timeout=60)
        
        if img_res.ok:
            # 4. Decode Clean Background Image
            img_b64 = img_res.json()["predictions"][0]["bytesBase64Encoded"]
            base_img = Image.open(io.BytesIO(base64.b64decode(img_b64))).convert("RGBA")
            
            # 5. Overlay Burmese Text Box with Pillow
            title_img_path = Path(tempfile.mktemp(suffix=".png"))
            create_title_image(hook_text, base_img.width, title_img_path)
            title_img = Image.open(title_img_path).convert("RGBA")
            
            # Paste at top center (8% from top)
            paste_x = (base_img.width - title_img.width) // 2
            paste_y = int(base_img.height * 0.08)
            base_img.alpha_composite(title_img, (paste_x, paste_y))
            
            # Save final thumbnail
            base_img.convert("RGB").save(output_path, "JPEG", quality=90)
            
            try: title_img_path.unlink(missing_ok=True)
            except: pass
            
            return output_path
    except: pass
    return None

def generate_microsoft_tts(script: str, voice: str) -> bytes:
    key = os.getenv("AZURE_SPEECH_KEY", "").strip()
    region = os.getenv("AZURE_SPEECH_REGION", "southeastasia").strip()
    if not key: raise RuntimeError("Microsoft Voice setting မသတ်မှတ်ရသေးပါ။")
    selected_voice = MICROSOFT_VOICES.get(voice, DEFAULT_MICROSOFT_VOICE)
    ssml = f'<speak version="1.0" xml:lang="my-MM" xmlns="http://www.w3.org/2001/10/synthesis"><voice name="{selected_voice}"><prosody rate="+0%">{xml_escape(script)}</prosody></voice></speak>'
    try: import azure.cognitiveservices.speech as speechsdk
    except ImportError: raise RuntimeError("azure-cognitiveservices-speech package ကို requirements.txt တွင် မတွေ့ပါ။")
    speech_config = speechsdk.SpeechConfig(subscription=key, region=region)
    speech_config.set_speech_synthesis_output_format(speechsdk.SpeechSynthesisOutputFormat.Audio24Khz48KBitRateMonoMp3)
    synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=None)
    result = synthesizer.speak_ssml_async(ssml).get()
    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted: return result.audio_data
    raise RuntimeError(f"Microsoft Voice ဆာဗာ ချို့ယွင်းနေပါသည်။: {result.reason}")

def generate_gemini_tts(script: str, voice: str, api_key: str) -> bytes:
    if not api_key: raise RuntimeError("Gemini API Key မရှိပါ။")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}"
    payload = {"contents": [{"role": "user", "parts": [{"text": script}]}], "generationConfig": {"responseModalities": ["AUDIO"], "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}}}}
    response = requests.post(url, json=payload, timeout=(10, 80))
    if not response.ok: raise RuntimeError(f"Gemini Voice Error: {response.status_code}")
    return base64.b64decode(response.json()["candidates"][0]["content"]["parts"][0]["inlineData"]["data"])

def make_srt(script: str, duration: float) -> str:
    cleaned = script.strip()
    if not cleaned: return ""
    words = cleaned.replace('\n', ' ').split(' ')
    chunks, current_chunk = [], ""
    break_words = ["။", "၊", "သောအခါ", "အောင်", "၍", "ပြီး", "လို့", "သောကြောင့်", "မို့လို့", "သည်", "ပါ", "တယ်", "မယ်"]
    
    for word in words:
        if not word.strip(): continue
        current_chunk += word + " "
        char_count = len(current_chunk.replace(" ", ""))
        if (char_count >= 10 and any(current_chunk.strip().endswith(bw) for bw in break_words)) or char_count > 18:
            chunks.append(current_chunk.strip())
            current_chunk = ""
    if current_chunk.strip(): chunks.append(current_chunk.strip())

    total_weight = sum([len(c.replace(" ", "")) * 1.5 + (20 if c.endswith("။") else 10 if c.endswith("၊") else 0) for c in chunks])
    if total_weight == 0: return ""

    def clock(value: float) -> str:
        ms = int(max(0, value) * 1000)
        return f"{ms // 3_600_000:02d}:{(ms // 60_000) % 60:02d}:{(ms // 1000) % 60:02d},{ms % 1000:03d}"

    srt_output, current_time = [], 0.0
    for index, (line, weight) in enumerate(zip(chunks, [len(c.replace(" ", "")) * 1.5 + (20 if c.endswith("။") else 10 if c.endswith("၊") else 0) for c in chunks])):
        piece_duration = (weight / total_weight) * duration
        end_time = current_time + piece_duration
        srt_output.append(f"{index + 1}\n{clock(current_time)} --> {clock(end_time - 0.05 if end_time - current_time > 0.2 else end_time)}\n{line.strip()}")
        current_time = end_time
    return "\n\n".join(srt_output)

def srt_to_ass(srt: str, settings: dict[str, Any], width: int, height: int, source_rect: dict[str, int] | None = None, speed_factor: float = 1.0) -> str:
    scale_factor = (height / 720.0)
    font_size = max(20, min(80, round(float(settings.get("subtitle_size", 20)) * 1.8 * scale_factor)))
    visible = source_rect or {"x": 0, "y": 0, "width": width, "height": height}
    x = int(visible["x"]) + math.floor(int(visible["width"]) * max(0, min(100, int(settings.get("subtitle_x", 50)))) / 100 + 0.5)
    y = int(visible["y"]) + math.floor(int(visible["height"]) * max(0, min(100, int(settings.get("subtitle_y", 82)))) / 100 + 0.5)
    
    font = FONT_FAMILIES.get(str(settings.get("subtitle_font", "Noto Sans Myanmar")), "Noto Sans Myanmar")
    header = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {width}", f"PlayResY: {height}", "", "[V4+ Styles]", "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding", f"Style: TextStyle,{font},{font_size},&H0066D1FF,&H0066D1FF,&H00000000,&H00000000,-1,0,0,0,100,100,0,0,1,3,2,2,20,20,20,1", "", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text"]
    events = []
    for block in re.split(r"\n\s*\n", srt.strip()):
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        if len(lines) < 3 or "-->" not in lines[1]: continue
        start, end = (p.strip() for p in lines[1].split("-->", 1))
        try:
            def convert(value: str) -> str:
                h, m, s_ms = value.split(":")
                s, ms = s_ms.split(",")
                new_ms = int((int(h)*3600000 + int(m)*60000 + int(s)*1000 + int(ms)) / speed_factor)
                return f"{new_ms // 3600000}:{(new_ms // 60000) % 60:02d}:{(new_ms // 1000) % 60:02d}.{(new_ms % 1000) // 10:02d}"
            caption = " ".join(lines[2:]).replace("{", "\\{").replace("}", "\\}")
            events.append(f"Dialogue: 1,{convert(start)},{convert(end)},TextStyle,,0,0,0,,{{\\an5\\pos({x},{y})}}{caption}")
        except ValueError: continue
    return "\n".join(header + events) + "\n"

def fitted_source_rect(source: dict[str, float | int], out_width: int, out_height: int) -> dict[str, int]:
    scale = min(out_width / max(1, int(source["width"])), out_height / max(1, int(source["height"])))
    w, h = max(2, round(max(1, int(source["width"])) * scale)), max(2, round(max(1, int(source["height"])) * scale))
    return {"x": (out_width - w) // 2, "y": (out_height - h) // 2, "width": w, "height": h}

def render_final(video_path: Path, tts_wav: bytes, settings: dict[str, Any], output_path: Path) -> Path:
    source = probe_video(video_path)
    aspect = str(settings.get("aspect", "9:16"))
    scale = 854
    out_w, out_h = (round(scale * 16 / 9), scale) if aspect == "16:9" else (scale, scale) if aspect == "1:1" else (scale, round(scale * 16 / 9))
    out_w -= out_w % 2; out_h -= out_h % 2
    visible_rect = fitted_source_rect(source, out_w, out_h)
    
    temp_paths = []
    
    # Write TTS Audio
    raw_audio_path = Path(tempfile.mktemp(suffix=".mp3"))
    raw_audio_path.write_bytes(tts_wav)
    temp_paths.append(raw_audio_path)
    
    # Generate Top Hook Title (3 seconds overlay)
    title_img_path = Path(tempfile.mktemp(suffix=".png"))
    temp_paths.append(title_img_path)
    
    api_key = settings.get("simple_api_key")
    hook_text = "အံ့ဖွယ် ဇာတ်လမ်းတိုလေး"
    if api_key:
        try:
            script_text = str(settings.get("script", ""))
            parts = [{"text": f"Generate a short viral Burmese hook (max 4 words) for this video recap script. Return ONLY the text. Context: {script_text[:500]}"}]
            res = _generate_content(api_key, parts, config={"temperature": 0.7}, timeout=30)
            text_res = "\n".join(str(p.get("text") or "") for c in res.get("candidates", []) for p in c.get("content", {}).get("parts", [])).strip()
            if text_res: hook_text = text_res[:25]
        except: pass
    
    create_title_image(hook_text, out_w, title_img_path)
    
    raw_tts_dur = get_audio_duration(raw_audio_path)
    vid_duration = float(source["duration"])
    if raw_tts_dur <= 0: raw_tts_dur = vid_duration
    
    speed_float = float(settings.get("speed") or settings.get("videoSpeed") or 1.0)
    target_dur = raw_tts_dur / speed_float if speed_float > 0 else raw_tts_dur
    v_pts_factor = target_dur / vid_duration if vid_duration > 0 else 1.0

    video_filters = [f"setpts={v_pts_factor:.4f}*PTS-STARTPTS", "fps=30"]
    video_filters.extend([f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:flags=lanczos", f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:color=black"])
    
    graph = f"[0:v]{','.join(video_filters)}[v_base]"
    current_v = "v_base"
    
    inputs = ["ffmpeg", "-y", "-i", str(video_path), "-i", str(raw_audio_path), "-i", str(title_img_path)]
    
    # Add Title Overlay for the first 3 seconds
    next_v = "v_title"
    graph += f";[{current_v}][2:v]overlay=x=(W-w)/2:y=H*0.08:enable='between(t,0,3)'[{next_v}]"
    current_v = next_v
        
    if settings.get("subtitles", True):
        srt = str(settings.get("subtitle_srt") or make_srt(str(settings.get("script") or ""), raw_tts_dur))
        ass_path = Path(tempfile.mktemp(suffix=".ass"))
        ass_path.write_text(srt_to_ass(srt, settings, out_w, out_h, visible_rect, speed_float), encoding="utf-8", newline="\n")
        temp_paths.append(ass_path)
        next_v = "vsub"
        graph += f";[{current_v}]ass=filename='{str(ass_path).replace(':', r'\:')}'[{next_v}]"
        current_v = next_v
    
    current_a_mix = "1:a" 
    a_filters = []
    if speed_float != 1.0:
        a_filters.append(f"[{current_a_mix}]atempo={speed_float}[tts_speed]")
        current_a_mix = "tts_speed"

    orig_audio = str(settings.get("originalAudio", "Mute"))
    if source.get("has_audio") and orig_audio != "Mute":
        a_filters.append(f"[0:a]volume=0.15[orig_a]")
        in_a = current_a_mix if ":" in current_a_mix else f"[{current_a_mix}]"
        a_filters.append(f"{in_a}[orig_a]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[mixed_1]")
        current_a_mix = "mixed_1"

    if a_filters: graph += ";" + ";".join(a_filters)
    audio_map = current_a_mix if ":" in current_a_mix else f"[{current_a_mix}]"

    command = inputs + [
        "-filter_complex", graph, "-map", f"[{current_v}]", "-map", audio_map,
        "-c:v", "libx264", "-preset", "faster", "-crf", "26", "-pix_fmt", "yuv420p", "-r", "30", 
        "-c:a", "aac", "-b:a", "128k", "-t", f"{target_dur:.3f}", "-movflags", "+faststart", str(output_path)
    ]
    
    try:
        _run(command, timeout=2400)
        return output_path
    finally:
        for p in temp_paths: (shutil.rmtree(p, ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True))
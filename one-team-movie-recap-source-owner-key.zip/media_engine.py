"""Server-side media pipeline for One Team Movie Recap."""

from __future__ import annotations

import base64
import io
import json
import math
import os
import wave
import re
import shutil
import subprocess
import tempfile
import time
import unicodedata
from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape as xml_escape

import requests
from PIL import Image, ImageDraw, ImageFont

ROOT = Path(__file__).resolve().parent
FONTS = ROOT / "fonts"
# Script အတွက် နေရာလွတ်ပိုများသော Model ကိုသုံးပါမည်
TEXT_MODEL = "gemini-3.7-pro"

MICROSOFT_VOICES = {
    "Nilar": "my-MM-NilarNeural", "Thiha": "my-MM-ThihaNeural",
    "Jenny": "en-US-JennyNeural", "Guy": "en-US-GuyNeural", "Aria": "en-US-AriaNeural",
    "Davis": "en-US-DavisNeural", "Sonia": "en-GB-SoniaNeural", "Ryan": "en-GB-RyanNeural",
    "Xiaoxiao": "zh-CN-XiaoxiaoNeural", "Nanami": "ja-JP-NanamiNeural",
    "SunHi": "ko-KR-SunHiNeural", "Premwadee": "th-TH-PremwadeeNeural", "Swara": "hi-IN-SwaraNeural",
}
GEMINI_VOICES = {
    "Kore": "Kore", "Puck": "Puck", "Charon": "Charon", "Fenrir": "Fenrir",
    "Aoede": "Aoede", "Leda": "Leda", "Orus": "Orus", "Zephyr": "Zephyr",
    "Achernar": "Achernar", "Enceladus": "Enceladus",
}
DEFAULT_MICROSOFT_VOICE = "my-MM-NilarNeural"
FONT_FILES = {
    "Noto Sans Myanmar": FONTS / "NotoSansMyanmar-Regular.ttf",
    "Pyidaungsu": FONTS / "pyidaungsu_regular.ttf",
    "Pyidaungsu Bold": FONTS / "pyidaungsu_bold.ttf",
    "Pyidaungsu 2.5.3 Bold": FONTS / "pyidaungsu_253_bold.ttf",
}
FONT_FAMILIES = {
    "Noto Sans Myanmar": "Noto Sans Myanmar",
    "Pyidaungsu": "Pyidaungsu Green",
    "Pyidaungsu Bold": "Pyidaungsu Green",
    "Pyidaungsu 2.5.3 Bold": "Pyidaungsu",
}
LATIN_FONT = FONTS / "DejaVuSans.ttf"

def _run(command: list[str], timeout: int = 1200) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0:
        raise RuntimeError((result.stderr or "FFmpeg failed")[-1800:])
    return result

def probe_video(path: Path) -> dict[str, float | int]:
    try:
        result = _run([
            "ffprobe", "-v", "error", "-select_streams", "v:0",
            "-show_entries", "stream=width,height,duration:stream_tags=rotate:stream_side_data=rotation",
            "-of", "json", str(path),
        ], timeout=45)
        stream = (json.loads(result.stdout).get("streams") or [{}])[0]
        width, height = int(stream.get("width") or 0), int(stream.get("height") or 0)
        rotation = 0
        for candidate in [
            (stream.get("tags") or {}).get("rotate"),
            *((item or {}).get("rotation") for item in stream.get("side_data_list") or []),
        ]:
            try:
                rotation = int(float(candidate)) % 360
                break
            except (TypeError, ValueError):
                continue
        if rotation in {90, 270}:
            width, height = height, width
        duration = float(stream.get("duration") or 0)
        if not duration:
            duration_result = _run([
                "ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path),
            ], timeout=45)
            duration = float(duration_result.stdout.strip() or 0)
        if width < 2 or height < 2 or duration <= 0:
            raise ValueError("missing video metadata")
        return {"width": width, "height": height, "duration": duration}
    except Exception as exc:
        raise RuntimeError("Video information ကိုမဖတ်နိုင်ပါ။ MP4/MOV ဖိုင်ကိုစစ်ပါ။") from exc

def _json_response(response: requests.Response) -> dict[str, Any]:
    try:
        payload = response.json()
    except ValueError:
        payload = {}
    if response.ok:
        return payload
    message = str((payload.get("error") or {}).get("message") or response.text or f"HTTP {response.status_code}")
    raise RuntimeError(f"AI ဝန်ဆောင်မှု {response.status_code}: {message}")

def extract_media_fast(video_path: Path, output_dir: Path) -> tuple[Path | None, list[Path]]:
    output_dir.mkdir(parents=True, exist_ok=True)
    audio_path = output_dir / "audio.mp3"
    try:
        _run([
            "ffmpeg", "-y", "-i", str(video_path),
            "-vn", "-ar", "16000", "-ac", "1", "-b:a", "32k",
            str(audio_path),
        ], timeout=45)
    except Exception:
        audio_path = None

    _run([
        "ffmpeg", "-y", "-i", str(video_path),
        "-vf", "select='gt(scene,0.4)',scale=480:-1",
        "-vsync", "vfr", "-q:v", "5", "-vframes", "5",
        str(output_dir / "frame_%03d.jpg"),
    ], timeout=45)
    frames = sorted(output_dir.glob("frame_*.jpg"))
    return audio_path, frames

def _generate_content(api_key: str, model: str, parts: list[dict[str, Any]], *, config: dict[str, Any], timeout: int) -> dict[str, Any]:
    fallback_models = [model, "gemini-1.5-pro", "gemini-1.5-flash", "gemini-3.5-pro", "gemini-3.5-flash"]
    last_error = ""
    for current_model in fallback_models:
        try:
            response = requests.post(
                f"https://generativelanguage.googleapis.com/v1beta/models/{current_model}:generateContent",
                params={"key": api_key},
                json={"contents": [{"role": "user", "parts": parts}], "generationConfig": config},
                timeout=(10, timeout),
            )
            return _json_response(response)
        except Exception as e:
            err_str = str(e)
            if "503" in err_str or "404" in err_str or "429" in err_str:
                last_error = err_str
                time.sleep(2.5)
                continue
            else:
                raise e
    raise RuntimeError(f"AI ဆာဗာများ အားလုံး အလုပ်များနေပါသည်။ နောက်ဆုံး Error: {last_error}")

def _response_text(payload: dict[str, Any]) -> str:
    text = "\n".join(
        str(part.get("text") or "")
        for candidate in payload.get("candidates") or []
        for part in ((candidate.get("content") or {}).get("parts") or [])
    ).strip()
    if not text:
        raise RuntimeError("Script မပြန်လာပါ။ API Key သို့မဟုတ် Video ကိုစစ်ဆေးပါ။")
    return text

def generate_script(api_key: str, video_path: Path, mime_type: str, language: str, duration_seconds: int, tone: str, recap_type: str, timing_mode: str, progress=None) -> str:
    temp_dir = Path(tempfile.mkdtemp(prefix="fast-scan-"))
    try:
        if progress:
            progress(25, "Video မှ အသံနှင့် Keyframes များကို အမြန်ခွဲထုတ်နေပါတယ်")
        audio_path, frames = extract_media_fast(video_path, temp_dir)

        if progress:
            progress(38, "AI သို့ တိုက်ရိုက်ပေးပို့နေပါတယ်")

        parts: list[dict[str, Any]] = []

        if audio_path and audio_path.exists() and audio_path.stat().st_size > 0:
            audio_b64 = base64.b64encode(audio_path.read_bytes()).decode("utf-8")
            parts.append({"inlineData": {"mimeType": "audio/mp3", "data": audio_b64}})

        for frame in frames[:4]:
            if frame.exists():
                img_b64 = base64.b64encode(frame.read_bytes()).decode("utf-8")
                parts.append({"inlineData": {"mimeType": "image/jpeg", "data": img_b64}})

        timing_instruction = ""
        if timing_mode == "Video Time":
            timing_instruction = f"The target speaking duration is exactly {duration_seconds} seconds. You MUST adjust your word count to fit this duration perfectly without getting cut off."
        else:
            timing_instruction = "Write a complete, comprehensive script. Do not rush or cut off the story. The video will be adjusted to match your full script length."

        if recap_type == "Simple Movie":
            instruction = (
                f"You are a professional Burmese movie storyteller. Tone: {tone}. "
                f"Carefully watch the actions, expressions, and pacing of the video. Write a captivating narrative script in {language}. "
                f"{timing_instruction} "
                f"Return ONLY the spoken text in Burmese without markdown, titles, or timestamps."
            )
        else:
            instruction = (
                f"You are a professional audio translator. Tone: {tone}. "
                f"Listen to the provided audio carefully. Provide a full, word-for-word translation of ALL spoken dialogue and voiceover into fluent {language}. "
                f"Do NOT summarize or skip any part of the audio. {timing_instruction} "
                f"Return ONLY the spoken translated text in Burmese without markdown, timestamps, or stage directions."
            )

        parts.append({"text": instruction})

        if progress:
            progress(50, "AI က Script ရေးနေပါတယ်")

        return _response_text(_generate_content(
            api_key, TEXT_MODEL, parts, config={"temperature": 0.3}, timeout=90,
        ))
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def microsoft_voice_name(value: str) -> str:
    return MICROSOFT_VOICES.get(str(value or "").strip(), DEFAULT_MICROSOFT_VOICE)

def azure_speech_endpoint() -> str:
    configured = os.getenv("AZURE_SPEECH_ENDPOINT", "").strip().rstrip("/")
    if configured:
        return configured if configured.endswith("/cognitiveservices/v1") else f"{configured}/cognitiveservices/v1"
    region = os.getenv("AZURE_SPEECH_REGION", "").strip()
    if not region:
        raise RuntimeError("Microsoft Voice setting မသတ်မှတ်ရသေးပါ။ Admin ကိုဆက်သွယ်ပါ")
    return f"https://{region}.tts.speech.microsoft.com/cognitiveservices/v1"

def _pcm_to_wav(pcm: bytes, *, sample_rate: int = 24000, channels: int = 1, sample_width: int = 2) -> bytes:
    if not pcm:
        raise RuntimeError("အသံ data မပြန်လာပါ")
    output = io.BytesIO()
    with wave.open(output, "wb") as wav_file:
        wav_file.setnchannels(channels)
        wav_file.setsampwidth(sample_width)
        wav_file.setframerate(sample_rate)
        wav_file.writeframes(pcm)
    return output.getvalue()

def generate_gemini_tts(script: str, voice: str, api_key: str) -> bytes:
    narration = str(script or "").strip()
    if not narration:
        raise RuntimeError("Narration စာသားမရှိပါ")
    selected_voice = GEMINI_VOICES.get(str(voice or "").strip())
    if not selected_voice:
        raise RuntimeError("Gemini Voice မမှန်ပါ")
        
    last_err = ""
    # Gemini TTS အတွက် အရင်အလုပ်လုပ်သော Preview Model သို့ ပြန်လည်ပြောင်းလဲထားသည် (Auto-retry ပါဝင်သည်)
    for attempt in range(4):
        try:
            response = requests.post(
                "https://generativelanguage.googleapis.com/v1beta/interactions",
                headers={"x-goog-api-key": str(api_key).strip(), "Content-Type": "application/json"},
                json={
                    "model": "gemini-3.1-flash-tts-preview",
                    "input": narration,
                    "response_format": {"type": "audio"},
                    "generation_config": {"speech_config": [{"voice": selected_voice}]},
                },
                timeout=(10, 120),
            )
        except requests.RequestException as exc:
            last_err = f"Network Timeout: {type(exc).__name__}"
            time.sleep(3)
            continue
            
        if response.status_code in {503, 429, 500}:
            last_err = f"ဆာဗာ ယာယီကျပ်နေပါသည် (Error {response.status_code})"
            time.sleep(3)
            continue
            
        if response.status_code in {401, 403}:
            raise RuntimeError("အသံ Key မမှန်ပါ သို့မဟုတ် ခွင့်ပြုချက်မရှိပါ")
            
        if not response.ok:
            details = response.text.strip()[-400:]
            raise RuntimeError(f"Gemini အသံဝန်ဆောင်မှု Error: {details or 'Audio မထုတ်နိုင်ပါ'}")
            
        try:
            payload = response.json()
            encoded = str(((payload.get("output_audio") or {}).get("data")) or "")
            if not encoded:
                raise ValueError("No data returned")
            return _pcm_to_wav(base64.b64decode(encoded, validate=True))
        except (ValueError, KeyError, TypeError, base64.binascii.Error):
            last_err = "Audio data format မမှန်ပါ"
            time.sleep(2)
            continue
            
    raise RuntimeError(f"Gemini အသံဆာဗာများ အလုပ်များနေပါသည်။ {last_err}")

def generate_microsoft_tts(script: str, voice: str) -> bytes:
    key = os.getenv("AZURE_SPEECH_KEY", "").strip()
    if not key:
        raise RuntimeError("Microsoft Voice setting မသတ်မှတ်ရသေးပါ။ Admin ကိုဆက်သွယ်ပါ")
    narration = str(script or "").strip()
    if not narration:
        raise RuntimeError("Narration စာသားမရှိပါ")
    selected_voice = microsoft_voice_name(voice)
    language = selected_voice.rsplit("-", 1)[0] if "-" in selected_voice else "my-MM"
    ssml = (
        f'<speak version="1.0" xml:lang="{language}" '
        'xmlns="http://www.w3.org/2001/10/synthesis">'
        f'<voice name="{selected_voice}">{xml_escape(narration)}</voice></speak>'
    )
    try:
        response = requests.post(
            azure_speech_endpoint(),
            headers={
                "Ocp-Apim-Subscription-Key": key,
                "Content-Type": "application/ssml+xml",
                "X-Microsoft-OutputFormat": "audio-24khz-48kbitrate-mono-mp3",
                "User-Agent": "one-team-movie-recap",
            },
            data=ssml.encode("utf-8"),
            timeout=(10, 80),
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"Microsoft Voice network timeout: {type(exc).__name__}") from exc
    if response.status_code == 401:
        raise RuntimeError("Microsoft Voice Key သို့မဟုတ် Region မမှန်ပါ")
    if response.status_code == 429:
        raise RuntimeError("Microsoft Voice အသုံးပြုမှု limit ပြည့်နေပါသည်။ ခဏနောက်ပြန်စမ်းပါ")
    if not response.ok:
        details = response.text.strip()[-400:]
        raise RuntimeError(f"Microsoft Voice {response.status_code}: {details or 'Audio မထုတ်နိုင်ပါ'}")
    if len(response.content) < 256:
        raise RuntimeError("Microsoft Voice audio data မပြန်လာပါ")
    return response.content

def get_audio_duration(audio_path: Path) -> float:
    try:
        result = _run([
            "ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(audio_path),
        ], timeout=15)
        return float(result.stdout.strip() or 0)
    except Exception:
        return 0.0

def process_audio_speed(input_wav: Path, speed: str, pitch_alter: bool, output_wav: Path) -> float:
    filters = ["aresample=async=1:first_pts=0"]
    if pitch_alter:
        filters.extend(["asetrate=24960", "aresample=24000", "atempo=0.961538"])
    
    if speed == "Fast":
        filters.append("atempo=1.15")
    elif speed == "Slow":
        filters.append("atempo=0.85")
        
    filter_str = ",".join(filters)
    _run(["ffmpeg", "-y", "-i", str(input_wav), "-af", filter_str, str(output_wav)], timeout=60)
    return get_audio_duration(output_wav)

def make_srt(script: str, duration: float) -> str:
    words = [item for item in re.split(r"\s+", script.strip()) if item]
    if not words:
        return ""
        
    pieces = []
    current_piece = []
    # အများဆုံး စာလုံး ၈ လုံးခန့်သာ တစ်ပိုင်းတွင် ထားမည် (နှစ်ကြောင်းခွဲရန် အဆင်ပြေစေရန်)
    for word in words:
        current_piece.append(word)
        if len(current_piece) >= 8:
            pieces.append(" ".join(current_piece))
            current_piece = []
    if current_piece:
        pieces.append(" ".join(current_piece))

    cue_seconds = max(1.0, duration / max(1, len(pieces)))

    def clock(value: float) -> str:
        ms = int(max(0, value) * 1000)
        return f"{ms // 3_600_000:02d}:{(ms // 60_000) % 60:02d}:{(ms // 1000) % 60:02d},{ms % 1000:03d}"

    srt_output = []
    for index, line in enumerate(pieces):
        start_time = clock(index * cue_seconds)
        end_time = clock(min(duration, (index + 1) * cue_seconds))
        srt_output.append(f"{index + 1}\n{start_time} --> {end_time}\n{line}")
        
    return "\n\n".join(srt_output)

def ass_color(value: str, alpha: int = 0) -> str:
    color = re.sub(r"[^0-9a-fA-F]", "", value or "")[-6:].rjust(6, "F")
    return f"&H{max(0, min(255, alpha)):02X}{color[4:6]}{color[2:4]}{color[:2]}"

def fitted_source_rect(source: dict[str, float | int], out_width: int, out_height: int) -> dict[str, int]:
    source_width = max(1, int(source["width"]))
    source_height = max(1, int(source["height"]))
    scale = min(out_width / source_width, out_height / source_height)
    width = max(2, round(source_width * scale))
    height = max(2, round(source_height * scale))
    return {"x": (out_width - width) // 2, "y": (out_height - height) // 2, "width": width, "height": height}

def srt_to_ass(srt: str, settings: dict[str, Any], width: int, height: int, source_rect: dict[str, int] | None = None) -> str:
    font_size = max(34, min(132, round(float(settings.get("subtitle_size", 24)) * 2.1)))
    visible = source_rect or {"x": 0, "y": 0, "width": width, "height": height}
    x = int(visible["x"]) + math.floor(int(visible["width"]) * max(0, min(100, int(settings.get("subtitle_x", 50)))) / 100 + 0.5)
    y = int(visible["y"]) + math.floor(int(visible["height"]) * max(0, min(100, int(settings.get("subtitle_y", 82)))) / 100 + 0.5)
    mode = str(settings.get("subtitle_background", "Transparent"))
    border_style = 3 if mode == "Solid background" else 1
    opacity = max(0, min(100, int(settings.get("subtitle_opacity", 55))))
    back_alpha = 255 - round(opacity * 255 / 100)
    font = FONT_FAMILIES.get(str(settings.get("subtitle_font", "Noto Sans Myanmar")), "Noto Sans Myanmar")
    header = [
        "[Script Info]", "ScriptType: v4.00+", f"PlayResX: {width}", f"PlayResY: {height}", "",
        "[V4+ Styles]",
        "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
        f"Style: Default,{font},{font_size},{ass_color(str(settings.get('subtitle_color', '#FFD166')))},{ass_color(str(settings.get('subtitle_color', '#FFD166')))},{ass_color(str(settings.get('subtitle_outline', '#000000')) )},{ass_color(str(settings.get('subtitle_background_color', '#000000')), back_alpha)},0,0,0,0,100,100,0,0,{border_style},{0 if border_style == 3 else 2},1,5,20,20,20,1",
        "", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text",
    ]
    events: list[str] = []
    
    for block in re.split(r"\n\s*\n", srt.strip()):
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if len(lines) < 3 or "-->" not in lines[1]:
            continue
        start, end = (piece.strip() for piece in lines[1].split("-->", 1))
        try:
            def convert(value: str) -> str:
                hours, minutes, seconds_ms = value.split(":")
                seconds, milliseconds = seconds_ms.split(",")
                return f"{int(hours)}:{int(minutes):02d}:{int(seconds):02d}.{int(milliseconds) // 10:02d}"
            
            # စာကြောင်းကို အတိအကျ နှစ်ကြောင်းတည်းဖြစ်အောင် ခွဲခြင်း
            raw_text = " ".join(lines[2:])
            words = raw_text.split()
            if len(words) > 4:
                mid = len(words) // 2
                caption = " ".join(words[:mid]) + "\\N" + " ".join(words[mid:])
            else:
                caption = raw_text
                
            caption = caption.replace("{", "\\{").replace("}", "\\}")
            events.append(f"Dialogue: 0,{convert(start)},{convert(end)},Default,,0,0,0,,{{\\an5\\pos({x},{y})}}{caption}")
        except ValueError:
            continue
    return "\n".join(header + events) + "\n"

def _is_myanmar(char: str) -> bool:
    return "MYANMAR" in unicodedata.name(char, "")

def render_text_logo(text: str) -> Path | None:
    text = " ".join(str(text or "").split())
    if not text:
        return None
    latin = ImageFont.truetype(str(LATIN_FONT), 44)
    mm_file = FONT_FILES["Noto Sans Myanmar"]
    myanmar = ImageFont.truetype(str(mm_file), 44)
    runs: list[tuple[str, ImageFont.FreeTypeFont]] = []
    for char in text:
        font = myanmar if _is_myanmar(char) else latin
        if runs and runs[-1][1].path == font.path:
            runs[-1] = (runs[-1][0] + char, font)
        else:
            runs.append((char, font))
    widths = [round(font.getlength(run)) for run, font in runs]
    canvas = Image.new("RGBA", (max(1, sum(widths) + 36), 82), (0, 0, 0, 0))
    draw = ImageDraw.Draw(canvas)
    x = 18
    for (run, font), width in zip(runs, widths):
        draw.text((x, 17), run, font=font, fill=(255, 255, 255, 255), stroke_width=2, stroke_fill=(0, 0, 0, 215))
        x += width
    target = Path(tempfile.mktemp(suffix="-one-team-logo.png"))
    canvas.save(target)
    return target

def _ratio(value: Any, default: float) -> float:
    try:
        return max(0.0, min(1.0, float(value)))
    except (TypeError, ValueError):
        return default

def render_final(video_path: Path, tts_wav: bytes, settings: dict[str, Any], output_path: Path) -> Path:
    source = probe_video(video_path)
    aspect = str(settings.get("aspect", "9:16"))
    quality = str(settings.get("quality", "720p"))
    scale = 1280 if quality == "1080p" else 720
    if aspect == "16:9":
        out_w, out_h = round(scale * 16 / 9), scale
    elif aspect == "1:1":
        out_w, out_h = scale, scale
    else:
        out_w, out_h = scale, round(scale * 16 / 9)
    out_w -= out_w % 2
    out_h -= out_h % 2
    visible_rect = fitted_source_rect(source, out_w, out_h)
    temp_paths: list[Path] = []
    
    # 1. မူလ Audio ကို Temp ဖိုင်အဖြစ်သိမ်းခြင်း
    raw_audio_path = Path(tempfile.mktemp(suffix=".wav"))
    raw_audio_path.write_bytes(tts_wav)
    temp_paths.append(raw_audio_path)
    
    # 2. Audio Speed ပြောင်းခြင်းနှင့် အရှည်တွက်ချက်ခြင်း
    processed_audio_path = Path(tempfile.mktemp(suffix="_processed.wav"))
    temp_paths.append(processed_audio_path)
    
    voice_speed = str(settings.get("voiceSpeed") or "Normal")
    pitch_alter = bool(settings.get("pitch_alter"))
    
    # အသံကို Speed ချိန်ပြီး Duration အတိအကျကို ယူမည်
    actual_audio_duration = process_audio_speed(raw_audio_path, voice_speed, pitch_alter, processed_audio_path)

    ass_path: Path | None = None
    text_logo: Path | None = None
    try:
        video_filters = ["setpts=PTS-STARTPTS"]
        if settings.get("mirror"):
            video_filters.append("hflip")
        if settings.get("auto_zoom"):
            video_filters.extend(["scale=iw*1.08:ih*1.08", "crop=iw/1.08:ih/1.08"])
        if settings.get("color_filter"):
            video_filters.append("eq=contrast=1.04:brightness=0.02:saturation=1.12")
            
        if settings.get("background_blur"):
            graph = (
                f"[0:v]{','.join(video_filters)},split=2[bgsrc][fgsrc];"
                f"[bgsrc]scale={out_w}:{out_h}:force_original_aspect_ratio=increase,crop={out_w}:{out_h},boxblur=20:10[bg];"
                f"[fgsrc]scale={out_w}:{out_h}:force_original_aspect_ratio=decrease[fg];"
                "[bg][fg]overlay=(W-w)/2:(H-h)/2[v0]"
            )
        else:
            video_filters.extend([
                f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease",
                f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:color=black",
            ])
            graph = f"[0:v]{','.join(video_filters)}[v0]"
        label = "v0"
        
        for index, mask in enumerate(settings.get("blur_masks") or []):
            x = int(visible_rect["x"]) + round(_ratio(mask.get("x"), 0.2) * int(visible_rect["width"]))
            y = int(visible_rect["y"]) + round(_ratio(mask.get("y"), 0.2) * int(visible_rect["height"]))
            width = max(24, round(_ratio(mask.get("width"), 0.2) * int(visible_rect["width"])))
            height = max(24, round(_ratio(mask.get("height"), 0.12) * int(visible_rect["height"])))
            width -= width % 2
            height -= height % 2
            x = min(max(int(visible_rect["x"]), x), int(visible_rect["x"]) + int(visible_rect["width"]) - width)
            y = min(max(int(visible_rect["y"]), y), int(visible_rect["y"]) + int(visible_rect["height"]) - height)
            next_label = f"vblur{index}"
            graph += f";[{label}]split=2[base{index}][crop{index}];[crop{index}]crop={width}:{height}:{x}:{y},boxblur=10:2[mask{index}];[base{index}][mask{index}]overlay={x}:{y}[{next_label}]"
            label = next_label
            
        if settings.get("subtitles", True):
            # Speed ပြင်ထားသော အသံအရှည်အတိုင်း Subtitle ကို ကွက်တိတွက်ချက်မည်
            sub_duration = actual_audio_duration if actual_audio_duration > 0 else float(source["duration"])
            srt = str(settings.get("subtitle_srt") or make_srt(str(settings.get("script") or ""), sub_duration))
            
            ass_path = Path(tempfile.mktemp(suffix=".ass"))
            ass_path.write_text(srt_to_ass(srt, settings, out_w, out_h, visible_rect), encoding="utf-8", newline="\n")
            temp_paths.append(ass_path)
            font_file = FONT_FILES.get(str(settings.get("subtitle_font")), FONT_FILES["Noto Sans Myanmar"])
            font_dir = Path(tempfile.mkdtemp(prefix="one-team-fonts-"))
            shutil.copy2(font_file, font_dir / font_file.name)
            temp_paths.append(font_dir)
            escaped_ass = str(ass_path).replace("'", "\\'").replace(":", "\\:")
            escaped_fonts = str(font_dir).replace("'", "\\'").replace(":", "\\:")
            graph += f";[{label}]ass=filename='{escaped_ass}':fontsdir='{escaped_fonts}'[vsub]"
            label = "vsub"
            
        logo_enabled = bool(settings.get("logo_enabled", True))
        logo_file = Path(str(settings.get("logo_path") or "")) if logo_enabled else Path()
        if not logo_file.is_file():
            logo_file = None
        text_logo = render_text_logo(str(settings.get("logo_text") or "")) if logo_enabled else None
        if text_logo:
            temp_paths.append(text_logo)
            
        inputs = ["ffmpeg", "-y"]
        timing_mode = str(settings.get("timingMode") or "Video Time")
        
        # Timing Mode က Voice Time ဖြစ်ပါက ဗီဒီယိုကို အသံဆုံးသည်အထိ အလိုအလျောက် Loop (ဆွဲဆန့်) ပေးမည်
        if timing_mode == "Voice Time":
            inputs.extend(["-stream_loop", "-1"])
            
        inputs.extend(["-i", str(video_path), "-i", str(processed_audio_path)])
        
        music_file = Path(str(settings.get("music_path") or ""))
        music_index: int | None = None
        if music_file.is_file():
            music_index = 2
            inputs.extend(["-stream_loop", "-1", "-i", str(music_file)])
            
        logo_size = max(10, min(45, int(settings.get("logo_size", 22)))) / 100
        logo_width = max(72, round(int(visible_rect["width"]) * logo_size))
        logo_x = int(visible_rect["x"]) + round(int(visible_rect["width"]) * max(0, min(100, int(settings.get("logo_x", 84)))) / 100)
        logo_y = int(visible_rect["y"]) + round(int(visible_rect["height"]) * max(0, min(100, int(settings.get("logo_y", 86)))) / 100)
        overlays: list[tuple[Path, str, str, int]] = []
        if logo_file:
            overlays.append((logo_file, f"{logo_x}-w/2", f"{logo_y}-h/2", logo_width))
        if text_logo:
            overlays.append((text_logo, f"{logo_x}-w/2", f"{logo_y}-h/2", logo_width))
            
        overlay_start_index = 2 + (1 if music_index is not None else 0)
        for overlay, _, _, _ in overlays:
            inputs.extend(["-loop", "1", "-i", str(overlay)])
        for offset, (_, x, y, target_width) in enumerate(overlays):
            index = overlay_start_index + offset
            next_label = "vfinal" if offset == len(overlays) - 1 else f"voverlay{index}"
            scaled = f"logo{index}"
            graph += f";[{index}:v]scale={target_width}:-1[{scaled}];[{label}][{scaled}]overlay=x='{x}':y='{y}':shortest=1[{next_label}]"
            label = next_label
            
        # အသံကို filter လုပ်ပြီးသားမို့ ထပ်မံပြင်စရာမလိုတော့ပါ၊ volume သာ ချိန်မည်
        audio_filter = "[1:a]volume=1[narration]"
        audio_inputs = "[narration]"
        
        original_mode = str(settings.get("original_audio", "Mute"))
        if original_mode != "Mute":
            original_volume = "0.13" if original_mode == "Low" else "0.28"
            audio_filter += f";[0:a]volume={original_volume}[original];[narration][original]amix=inputs=2:duration=first:dropout_transition=2[aout]"
            audio_inputs = "[aout]"
            
        if music_index is not None:
            music_volume = max(0, min(100, int(settings.get("music_volume", 24)))) / 100
            music_label = "music"
            mix_label = "amixout"
            audio_filter += f";[{music_index}:a]volume={music_volume:.2f}[{music_label}];{audio_inputs}[{music_label}]amix=inputs=2:duration=first:dropout_transition=2[{mix_label}]"
            audio_inputs = f"[{mix_label}]"
            
        command = inputs + [
            "-filter_complex", graph + ";" + audio_filter,
            "-map", f"[{label}]", "-map", audio_inputs,
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "23", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-b:a", "128k", "-shortest", "-movflags", "+faststart", str(output_path),
        ]
        
        _run(command, timeout=2400) # ပြတ်မသွားအောင် အချိန်ပိုပေးထားသည်
        if not output_path.exists() or output_path.stat().st_size < 1024:
            raise RuntimeError("Final MP4 မဖန်တီးနိုင်ပါ။")
        return output_path
    finally:
        for path in temp_paths:
            if path.is_dir():
                shutil.rmtree(path, ignore_errors=True)
            else:
                path.unlink(missing_ok=True)
"""Server-side media pipeline for One Team Movie Recap."""

from __future__ import annotations
import base64, io, json, math, os, wave, re, shutil, subprocess, tempfile, time, unicodedata, hashlib
import urllib.parse
from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape as xml_escape
import requests
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parent
FONTS = ROOT / "fonts"

FALLBACK_TEXT_MODELS = ["gemini-2.5-flash", "gemini-3.7-flash", "gemini-3.6-flash", "gemini-3.5-flash", "gemini-3.1-pro"]
DEFAULT_MICROSOFT_VOICE = "my-MM-NilarNeural"

GEMINI_VOICES = ["Aoede", "Charon", "Fenrir", "Kore", "Leda", "Orus", "Puck", "Zephyr", "Achernar", "Enceladus"]
MICROSOFT_VOICES = {
    "Nilar": "my-MM-NilarNeural", "Thiha": "my-MM-ThihaNeural",
    "Ava": "en-US-AvaMultilingualNeural", "Andrew": "en-US-AndrewMultilingualNeural",
    "Emma": "en-US-EmmaMultilingualNeural", "Brian": "en-US-BrianMultilingualNeural",
    "Vivienne": "fr-FR-VivienneMultilingualNeural", "Remy": "fr-FR-RemyMultilingualNeural",
    "Seraphina": "de-DE-SeraphinaMultilingualNeural", "Florian": "de-DE-FlorianMultilingualNeural",
    "Xiaoxiao": "zh-CN-XiaoxiaoMultilingualNeural", "Giuseppe": "it-IT-GiuseppeMultilingualNeural"
}

FONT_FILES = {
    "Noto Sans Myanmar": FONTS / "NotoSansMyanmar-Regular.ttf",
    "Pyidaungsu": FONTS / "pyidaungsu_253_bold.ttf",
    "Pyidaungsu Bold": FONTS / "pyidaungsu_bold.ttf",
    "A13_WenYoe Regular": FONTS / "A13_WenYoe-Regular.ttf",
    "Z10-Cartoon": FONTS / "Z10-Cartoon (1).ttf",
    "Great Vibes": FONTS / "GreatVibes-Regular.ttf",
    "Allura": FONTS / "Allura-Regular.ttf",
    "Alex Brush": FONTS / "AlexBrush-Regular.ttf",
    "Monotype Corsiva": FONTS / "MTCORSVA.TTF",
    "Dancing Script": FONTS / "DancingScript-Regular.ttf",
    "Pacifico": FONTS / "Pacifico-Regular.ttf",
    "Lobster": FONTS / "Lobster-Regular.ttf"
}

FONT_FAMILIES = {
    "Noto Sans Myanmar": "Noto Sans Myanmar",
    "Pyidaungsu": "Pyidaungsu Green",
    "Pyidaungsu Bold": "Pyidaungsu Green",
    "A13_WenYoe Regular": "A13_WenYoe Regular",
    "Z10-Cartoon": "Z10-Cartoon",
    "Great Vibes": "Great Vibes",
    "Allura": "Allura",
    "Alex Brush": "Alex Brush",
    "Monotype Corsiva": "Monotype Corsiva",
    "Dancing Script": "Dancing Script",
    "Pacifico": "Pacifico",
    "Lobster": "Lobster"
}
def get_gemini_key(api_key_str: str) -> str:
    """Gemini Key သီးသန့် ခွဲထုတ်ပေးသော စနစ် (Groq မလိုတော့ပါ)"""
    if not api_key_str:
        return os.getenv("GEMINI_API_KEY", "")
    keys = [k.strip() for k in api_key_str.split(",") if k.strip()]
    for k in keys:
        if k.startswith("AIza") or len(k) > 25:
            return k
    return os.getenv("GEMINI_API_KEY", "")

def get_vocals_only(audio_path: Path, temp_dir: Path) -> Path | None:
    import requests
    try:
        api_url = "http://169.58.181.87:8000/vocals"
        with open(audio_path, 'rb') as f:
            files = {'file': (audio_path.name, f, 'audio/mpeg')}
            response = requests.post(api_url, files=files, timeout=1200) 
            
        if response.status_code == 200:
            content_type = response.headers.get('Content-Type', '')
            if 'audio' in content_type or 'octet-stream' in content_type or 'wav' in content_type:
                vocals_path = temp_dir / "demucs_vocals.wav"
                with open(vocals_path, 'wb') as f:
                    f.write(response.content)
                return vocals_path
            else:
                raise RuntimeError(f"[DEMUCS_ERROR] Vocals မရရှိပါ: {response.text[:200]}")
        else:
            raise RuntimeError(f"[DEMUCS_ERROR] API အမှား: {response.text[:200]}")
    except Exception as e:
        raise RuntimeError(f"[DEMUCS_ERROR] {str(e)[:250]}")

# (ဒါက ပျောက်သွားတဲ့ အဟောင်းပါ၊ ပြန်ထည့်ပေးထားပါသည်)
def get_background_audio_only(video_path: Path, temp_dir: Path) -> Path | None:
    import requests
    try:
        extracted_audio = temp_dir / "extracted_original.mp3"
        _run(["ffmpeg", "-y", "-i", str(video_path), "-q:a", "0", "-map", "a", str(extracted_audio)], timeout=120)
        api_url = "http://169.58.181.87:8000/separate"
        with open(extracted_audio, 'rb') as f:
            files = {'file': (extracted_audio.name, f, 'audio/mpeg')}
            response = requests.post(api_url, files=files, timeout=1200)
        if response.status_code == 200:
            content_type = response.headers.get('Content-Type', '')
            if 'audio' in content_type or 'octet-stream' in content_type or 'wav' in content_type:
                bg_audio_path = temp_dir / "demucs_sfx.wav"
                with open(bg_audio_path, 'wb') as f:
                    f.write(response.content)
                return bg_audio_path
            else:
                raise RuntimeError(f"[DEMUCS_ERROR] Contabo ဆာဗာမှ အသံဖိုင် ပြန်မလာပါ: {response.text[:200]}")
        else:
            raise RuntimeError(f"[DEMUCS_ERROR] API ဆာဗာမှ အမှားပြန်လာပါသည်: {response.text[:200]}")
    except Exception as e:
        raise RuntimeError(f"[DEMUCS_ERROR] {str(e)[:250]}")
def _run(command: list[str], timeout: int = 1200) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0: raise RuntimeError((result.stderr or "FFmpeg failed")[-1800:])
    return result

def get_audio_duration(audio_path: Path) -> float:
    try:
        res = _run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(audio_path)], timeout=15)
        return float(res.stdout.strip() or 0.0)
    except:
        return 0.0

def probe_video(path: Path) -> dict[str, Any]:
    try:
        result = _run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,duration:stream_tags=rotate:stream_side_data=rotation", "-of", "json", str(path)], timeout=45)
        stream = (json.loads(result.stdout).get("streams") or [{}])[0]
        width, height = int(stream.get("width") or 0), int(stream.get("height") or 0)
        rotation = 0
        for candidate in [(stream.get("tags") or {}).get("rotate"), *((item or {}).get("rotation") for item in stream.get("side_data_list") or [])]:
            try: rotation = int(float(candidate)) % 360; break
            except (TypeError, ValueError): continue
        if rotation in {90, 270}: width, height = height, width
        duration = float(stream.get("duration") or 0)
        if not duration:
            dur_res = _run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)], timeout=45)
            duration = float(dur_res.stdout.strip() or 0)
            
        has_audio = False
        try:
            a_res = _run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(path)], timeout=15)
            if "audio" in a_res.stdout.lower(): has_audio = True
        except: pass
        
        if width < 2 or height < 2 or duration <= 0: raise ValueError("missing video metadata")
        return {"width": width, "height": height, "duration": duration, "has_audio": has_audio}
    except Exception as exc:
        raise RuntimeError("Video information ကိုမဖတ်နိုင်ပါ။") from exc

def upload_media_to_gemini(file_path: Path, api_key: str, mime_type: str, progress=None) -> dict[str, str]:
    if progress: progress(30, "AI ဆာဗာသို့ ဖိုင် တိုက်ရိုက်ပေးပို့နေပါသည်...")
    file_size = file_path.stat().st_size
    upload_url = f"https://generativelanguage.googleapis.com/upload/v1beta/files?key={api_key}"
    headers = {"X-Goog-Upload-Protocol": "raw", "X-Goog-Upload-Header-Content-Length": str(file_size), "X-Goog-Upload-Header-Content-Type": mime_type, "Content-Type": mime_type}
    with open(file_path, "rb") as f:
        res = requests.post(upload_url, headers=headers, data=f, timeout=1200)
    if not res.ok: raise RuntimeError(f"File တင်ခြင်း မအောင်မြင်ပါ: {res.text}")
    file_info = res.json().get("file", {})
    file_name = file_info.get("name")
    file_uri = file_info.get("uri")
    
    if progress: progress(45, "AI မှ ဖိုင်ကို ကြည့်ရှုလေ့လာနေပါသည်...")
    get_url = f"https://generativelanguage.googleapis.com/v1beta/{file_name}?key={api_key}"
    for _ in range(30):
        chk = requests.get(get_url, timeout=30).json()
        state = chk.get("state")
        if state == "ACTIVE": return {"fileUri": file_uri, "mimeType": mime_type, "name": file_name}
        if state == "FAILED": raise RuntimeError("AI မှ ဖိုင်ကို လေ့လာခြင်း မအောင်မြင်ပါ။")
        time.sleep(5)
    return {"fileUri": file_uri, "mimeType": mime_type, "name": file_name}

def delete_gemini_file(file_name: str, api_key: str):
    try: requests.delete(f"https://generativelanguage.googleapis.com/v1beta/{file_name}?key={api_key}", timeout=10)
    except: pass

def transcribe_with_vps(audio_path: Path) -> str:
    # Port 8001 (Faster-Whisper) ဆီသို့ အသေချိတ်ထားပါသည်
    url = "http://169.58.181.87:8001/transcribe"
    import requests
    with open(audio_path, "rb") as f:
        # .wav ဖိုင်ပို့မည့်အတွက် audio/wav သို့ ပြောင်းထားပါသည်
        files = {"file": (audio_path.name, f, "audio/wav" if audio_path.suffix.lower() == ".wav" else "audio/mpeg")}
        res = requests.post(url, files=files, timeout=1200)
    
    if not res.ok: raise RuntimeError(f"VPS Whisper Error: {res.text}")
    json_data = res.json()
    if "error" in json_data: raise RuntimeError(f"VPS Whisper Error: {json_data['error']}")
    
    segments = json_data.get("segments", [])
    if not segments: raise RuntimeError("VPS မှ စာသား ပြန်မလာပါ။")
    
    final_text = ""
    last_text = ""
    repeat_count = 0
    
    for seg in segments:
        text = seg.get("text", "").strip()
        if not text: continue
        
        if text.lower() == last_text.lower():
            repeat_count += 1
            if repeat_count > 1: continue 
        else:
            repeat_count = 0
            last_text = text
            
        start = int(seg.get("start", 0))
        end = int(seg.get("end", 0))
        s_min, s_sec = divmod(start, 60)
        e_min, e_sec = divmod(end, 60)
        final_text += f"[{s_min:02d}:{s_sec:02d} - {e_min:02d}:{e_sec:02d}] {text}\n"
        
    return final_text.strip()

def _generate_content(api_key: str, parts: list[dict[str, Any]], *, config: dict[str, Any], timeout: int) -> dict[str, Any]:
    for current_model in FALLBACK_TEXT_MODELS:
        try:
            response = requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/{current_model}:generateContent", params={"key": api_key}, json={"contents": [{"role": "user", "parts": parts}], "generationConfig": config}, timeout=(10, timeout))
            
            if response.ok: return response.json()
            
            # Error အမျိုးအစားကို ဖမ်းယူခြင်း
            error_msg = response.text.lower()
            if "api key not valid" in error_msg or "invalid api key" in error_msg:
                raise RuntimeError("[API_ERROR] သင်ထည့်ထားသော API Key မှားယွင်းနေပါသည်။ သေချာစစ်ဆေးပြီး အသစ်ပြန်ထည့်ပါ။")
            if "quota" in error_msg or "exhausted" in error_msg or response.status_code == 429:
                raise RuntimeError("[API_ERROR] API Key ၏ Limit (Quota) ပြည့်သွားပါပြီ။ အကောင့်သစ်တစ်ခုမှ Key အသစ် ပြောင်းထည့်ပါ။")
                
        except requests.exceptions.RequestException: 
            time.sleep(5.0)
            
    raise RuntimeError("[API_ERROR] API ဆာဗာနှင့် ချိတ်ဆက်၍မရပါ သို့မဟုတ် Limit ပြည့်နေပါသည်။")

def generate_script(api_key: str, video_path: Path, mime_type: str, language: str, duration_seconds: int, tone: str, recap_type: str, timing_mode: str, progress=None) -> str:
    gemini_file = None
    temp_audio_path = None
    try:
        vid_info = probe_video(video_path)
        has_audio = vid_info.get("has_audio", False)
        
        # Gemini Key သီးသန့် ခွဲယူမည်
        active_gemini_key = get_gemini_key(api_key)
        transcribed_text = ""
        parts = []

        # Movie Subtitle ရော Movie Dub မှာပါ VPS Whisper ကို အမြဲတမ်းသုံးမည် (Groq လုံးဝ မလိုတော့ပါ)
        if recap_type in ["Movie Subtitle", "Movie Dub"] and has_audio:
            if progress: progress(25, f"⚡ [{recap_type}] ဗီဒီယိုမှ မူရင်းအသံကို ခွဲထုတ်နေပါသည်...")
            temp_audio_path = Path(tempfile.mktemp(suffix=".mp3"))
            
            # မူရင်းအသံကို mp3 အဖြစ်သာ ထုတ်ယူမည်
            if recap_type == "Movie Subtitle":
                _run(["ffmpeg", "-y", "-i", str(video_path), "-filter:a", "atempo=0.98", "-q:a", "0", "-map", "a", str(temp_audio_path)], timeout=180)
            else:
                _run(["ffmpeg", "-y", "-i", str(video_path), "-q:a", "0", "-map", "a", str(temp_audio_path)], timeout=180)
            
            if progress: progress(30, "⚡ မူရင်းအသံဖိုင်ကို Gemini ထံ တိုက်ရိုက်ပို့၍ အချိန်ကိုက် ဇာတ်ညွှန်း ရေးနေပါသည်...")
            
            # လူသံခွဲသည့်အဆင့် (Demucs) ကို လုံးဝ ကျော်ဖြတ်ပြီး Gemini သို့ တိုက်ရိုက် ပို့မည်
            gemini_file = upload_media_to_gemini(temp_audio_path, active_gemini_key, "audio/mp3", progress)
            parts = [{"fileData": {"fileUri": gemini_file["fileUri"], "mimeType": gemini_file["mimeType"]}}]
            
            transcribed_text = ""
                
        elif recap_type in ["Movie Recap", "Movie Dub"] and has_audio:
            if progress: progress(25, f"⚡ [{recap_type}] အသံဖိုင် သီးသန့် ခွဲထုတ်နေပါသည်...")
            temp_audio_path = Path(tempfile.mktemp(suffix=".mp3"))
            _run(["ffmpeg", "-y", "-i", str(video_path), "-q:a", "0", "-map", "a", str(temp_audio_path)], timeout=120)
            gemini_file = upload_media_to_gemini(temp_audio_path, active_gemini_key, "audio/mp3", progress)
            parts = [{"fileData": {"fileUri": gemini_file["fileUri"], "mimeType": gemini_file["mimeType"]}}]
        else:
            if progress: progress(25, f"🎬 [{recap_type}] ဗီဒီယိုကို တိုက်ရိုက် လေ့လာနေပါသည်...")
            gemini_file = upload_media_to_gemini(video_path, active_gemini_key, "video/mp4", progress)
            parts = [{"fileData": {"fileUri": gemini_file["fileUri"], "mimeType": gemini_file["mimeType"]}}]

        if progress: progress(55, "📝 AI မှ ဇာတ်ညွှန်း (Script) ရေးသားနေပါသည်...")

        hook_instruction = "CRITICAL RULE 1: Your VERY FIRST LINE must be 'TITLE: ' followed by a 3 to 4 word engaging Burmese hook for the video.\n"
        
        if recap_type == "Movie Recap":
            hook_instruction += "CRITICAL RULE 2: Your SECOND LINE must be 'COVER: NO' because you are analyzing an audio file.\n"
        else:
            hook_instruction += "CRITICAL RULE 2: Check the first 1 to 3 seconds of the video. If it has a custom thumbnail, intro text, or cover image covering the video, your SECOND LINE must be 'COVER: YES'. If it starts immediately with the actual movie/scene without any cover, your SECOND LINE must be 'COVER: NO'.\n"

        # ၁ မိနစ်လျှင် မြန်မာစာလုံးရေ ၁၅၀ မှ ၂၀၀ နှုန်းထားဖြင့် အလိုအလျောက် တွက်ချက်ခြင်း
        min_words = max(150, int((duration_seconds / 60) * 150))
        max_words = max(200, int((duration_seconds / 60) * 200))

        if recap_type == "Movie Subtitle" and has_audio:
            instruction = hook_instruction + (
                f"You are an expert Movie Subtitle Translator. Listen to the provided audio file carefully (it contains ONLY the extracted character vocals).\n"
                f"Identify exactly when characters speak, and translate the dialogue into natural {language} ({tone} tone).\n"
                "CRITICAL RULES:\n"
                "1. EXACT TIMESTAMPS: You MUST provide the exact start and end timestamps by listening to the audio. Format: [00:10.000 - 00:12.500].\n"
                "2. SUBTITLE FORMAT: Translate ONLY the spoken words. Keep sentences concise and easy to read on screen (စာတန်းထိုးဖတ်ရလွယ်ကူစေရန် တိုတိုရှင်းရှင်းပြန်ပါ).\n"
                "3. DIRECT DIALOGUE ONLY: Do not write descriptions, actions, or summarize the story.\n"
                "4. NO HALLUCINATIONS: Do not invent dialogue where there is silence.\n"
                "5. Return ONLY the translated dialogue with timestamps."
            )
        elif recap_type == "Movie Dub" and has_audio:
            instruction = hook_instruction + (
                f"You are an expert Movie Dubbing Translator. Listen to the provided audio file carefully (it contains ONLY the extracted character vocals).\n"
                f"Identify exactly when characters speak, and translate the dialogue into HIGHLY NATURAL, EVERYDAY SPOKEN {language} ({tone} tone).\n"
                "CRITICAL RULES:\n"
                "1. EXACT TIMESTAMPS: You MUST provide the exact start and end timestamps by listening to the audio. Format: [00:10.000 - 00:12.500].\n"
                "2. DIRECT DIALOGUE ONLY: Translate ONLY the words spoken. DO NOT write descriptions, actions, or summarize the story.\n"
                "3. FIT THE TIMING (အချိန်ကိုက်ပြန်ပါ): If the spoken line is short, your Burmese translation MUST be short enough to speak in that same time duration.\n"
                "4. EVERYDAY CONVERSATION (စကားပြောဟန်): Write exactly how local Myanmar people talk. Avoid formal vocabulary.\n"
                "5. NO HALLUCINATIONS: Do not invent dialogue where there is silence.\n"
                "6. Return ONLY the translated dialogue with timestamps."
            )
        elif recap_type == "Movie Recap" and has_audio:
            instruction = hook_instruction + (
                f"You are an expert Translator and Dubbing Director. Listen to the provided audio file carefully.\n"
                f"Provide a 100% COMPLETE translation in HIGHLY NATURAL, EVERYDAY SPOKEN {language} ({tone} tone).\n"
                "CRITICAL RULES:\n"
                "1. DO NOT SHORTEN OR SUMMARIZE: Translate every single word, explanation, and dialogue. Leave absolutely nothing out.\n"
                "2. 100% NATURAL SPOKEN TONE (စကားပြောဟန်): Write exactly how a local Myanmar person naturally speaks in real life. STRICTLY AVOID formal, bookish, or robotic vocabulary.\n"
                "3. SMOOTH NATURAL PACING: The sentences must flow smoothly and naturally so that when spoken, they match the exact length and emotion of the original audio perfectly.\n"
                "4. Return ONLY the spoken narrative as a continuous text."
            )
        elif recap_type == "Silent Recap" or not has_audio:
            instruction = hook_instruction + (
                f"You are an expert storyteller. This video has NO dialogue. Watch the actions closely.\n"
                f"Create a detailed, highly engaging narrative story in EVERYDAY SPOKEN {language} ({tone} tone).\n"
                "CRITICAL RULES:\n"
                f"1. You MUST write between {min_words} and {max_words} Myanmar words.\n"
                "2. Tell the story naturally like you are explaining a movie to a friend (စကားပြောဟန်).\n"
                "3. Return ONLY the spoken narrative."
            )
        elif recap_type in ["Raw to Recap", "Raw to reacp"]:
            instruction = hook_instruction + (
                f"You are a professional movie recapper and a native storyteller. Watch the visual frames AND listen to the audio carefully.\n"
                f"Provide a 100% COMPLETE, detailed, and completely natural recap story in EVERYDAY SPOKEN {language} ({tone} tone).\n"
                "CRITICAL RULES:\n"
                f"1. STRICT LENGTH REQUIREMENT: You MUST write exactly between {min_words} and {max_words} Myanmar words. Do not write less, or the audio will not match the 100% video length.\n"
                "2. START WITH ACTION/DIALOGUE: Right after the TITLE and COVER lines, begin the story IMMEDIATELY by describing the main character's action, expression, or dialogue. DO NOT use generic introductions.\n"
                "3. NO SUMMARIZING OR SHORTENING: Explain everything happening in the video fully, naturally, and thoroughly without leaving any detail out.\n"
                "4. 100% NATURAL SPOKEN STYLE (စကားပြောဟန်): Write exactly how a local Myanmar person naturally talks to friends in real life. Use lively, conversational phrasing. STRICTLY AVOID formal vocabulary.\n"
                "5. Weave important dialogues smoothly and naturally into the action descriptions.\n"
                "6. Return ONLY the spoken text."
            )
        else:
            instruction = hook_instruction + (
                f"You are a professional movie recapper and a native storyteller. Watch the visual frames AND listen to the audio carefully.\n"
                f"Provide a 100% COMPLETE, detailed, and completely natural recap story in EVERYDAY SPOKEN {language} ({tone} tone).\n"
                "CRITICAL RULES:\n"
                "1. START WITH ACTION/DIALOGUE: Right after the TITLE and COVER lines, begin the story IMMEDIATELY by describing the main character's action, expression, or dialogue. DO NOT use generic introductions.\n"
                "2. NO SUMMARIZING OR SHORTENING: Explain everything happening in the video fully, naturally, and thoroughly without leaving any detail out.\n"
                "3. 100% NATURAL SPOKEN STYLE (စကားပြောဟန်): Write and speak exactly how a local Myanmar person naturally talks to friends in real life. Use lively, conversational everyday phrasing. STRICTLY AVOID formal, bookish, or stiff robotic vocabulary.\n"
                "4. Weave important dialogues smoothly and naturally into the action descriptions.\n"
                "5. Return ONLY the spoken text."
            )

        parts.append({"text": instruction})
        res = _generate_content(active_gemini_key, parts, config={"temperature": 0.3}, timeout=180)
        text = "\n".join(str(p.get("text") or "") for c in res.get("candidates", []) for p in c.get("content", {}).get("parts", [])).strip()
        if not text: raise RuntimeError("Script မပြန်လာပါ။")
        return text.strip()

    finally:
        if gemini_file and gemini_file.get("name"):
            delete_gemini_file(gemini_file["name"], active_gemini_key)
        if temp_audio_path and temp_audio_path.exists():
            try: temp_audio_path.unlink(missing_ok=True)
            except: pass

def create_title_image(text: str, width: int, output_path: Path):
    import textwrap
    font_path = str(FONT_FILES.get("Pyidaungsu Bold", FONT_FILES.get("Noto Sans Myanmar")))
    font_size = max(45, int(width * 0.08))
    try: font = ImageFont.truetype(font_path, size=font_size)
    except: font = ImageFont.load_default()
    
    lines = textwrap.wrap(text, width=18)
    if len(lines) > 2: lines = lines[:2]
    
    dummy = Image.new("RGBA", (1, 1))
    draw = ImageDraw.Draw(dummy)
    
    line_heights, line_widths = [], []
    for line in lines:
        bbox = draw.textbbox((0, 0), line, font=font)
        line_widths.append(bbox[2] - bbox[0])
        line_heights.append(bbox[3] - bbox[1])
        
    tw = max(line_widths) if line_widths else 0
    line_spacing = int(font_size * 0.25)
    th = sum(line_heights) + (len(lines) - 1) * line_spacing
    
    pad_x, pad_y = int(width * 0.1), int(font_size * 0.8)
    img_w, img_h = int(tw + pad_x * 2), int(th + pad_y * 2)
    
    bg_layer = Image.new("RGBA", (img_w, img_h), (0, 0, 0, 0))
    bg_draw = ImageDraw.Draw(bg_layer)
    bg_draw.rounded_rectangle([(pad_x//2, pad_y//2), (img_w - pad_x//2, img_h - pad_y//2)], radius=20, fill=(5, 10, 20, 230))
    bg_layer = bg_layer.filter(ImageFilter.GaussianBlur(radius=6))
    
    text_layer = Image.new("RGBA", (img_w, img_h), (0, 0, 0, 0))
    text_draw = ImageDraw.Draw(text_layer)
    
    colors = ["#00FFFF", "#FFE600"] 
    current_y = pad_y
    stroke_w = max(2, int(font_size * 0.04))
    
    for i, line in enumerate(lines):
        lw = line_widths[i]
        lx = (img_w - lw) // 2
        color = colors[i % 2]
        
        for dx in range(-stroke_w, stroke_w+1):
            for dy in range(-stroke_w, stroke_w+1):
                text_draw.text((lx+dx, current_y+dy), line, font=font, fill="black")
                
        text_draw.text((lx+4, current_y+4), line, font=font, fill=(0,0,0,180))
        text_draw.text((lx, current_y), line, font=font, fill=color)
        
        current_y += line_heights[i] + line_spacing
        
    final_img = Image.alpha_composite(bg_layer, text_layer)
    
    target_width = width * 0.95
    if final_img.width > target_width:
        scale = target_width / final_img.width
        final_img = final_img.resize((int(final_img.width * scale), int(final_img.height * scale)), Image.Resampling.LANCZOS)
        
    final_img.save(output_path, "PNG")
    return output_path

def generate_thumbnail(video_path: Path, script: str, output_path: Path) -> Path | None:
    try:
        hook_text = ""
        lines = [line.strip() for line in script.strip().split('\n') if line.strip()]
        for line in lines[:5]:
            if line.startswith("TITLE:"):
                hook_text = line.replace("TITLE:", "").strip().strip("*\"'")
                break
        
        if not hook_text: return None
            
        extracted_frame = Path(tempfile.mktemp(suffix=".jpg"))
        cmd = ["ffmpeg", "-y", "-ss", "00:00:02", "-i", str(video_path), "-vframes", "1", "-q:v", "2", str(extracted_frame)]
        subprocess.run(cmd, capture_output=True, timeout=30)
        
        if not extracted_frame.exists(): return None
            
        img = Image.open(extracted_frame).convert("RGBA")
        iw, ih = img.size
        
        target_ratio = 3 / 4
        current_ratio = iw / ih
        if current_ratio > target_ratio:
            new_w = int(ih * target_ratio)
            left = (iw - new_w) // 2
            img = img.crop((left, 0, left + new_w, ih))
        else:
            new_h = int(iw / target_ratio)
            top = 0
            img = img.crop((0, top, iw, top + new_h))
            
        grad_layer = Image.new("RGBA", img.size, (0,0,0,0))
        grad_draw = ImageDraw.Draw(grad_layer)
        grad_h = int(img.height * 0.4)
        for y in range(grad_h):
            alpha = int(200 * (1 - (y / grad_h)**1.5))
            grad_draw.line([(0, y), (img.width, y)], fill=(5, 10, 20, alpha))
        img.alpha_composite(grad_layer, (0, 0))
        
        title_img_path = Path(tempfile.mktemp(suffix=".png"))
        create_title_image(hook_text, img.width, title_img_path)
        
        title_img = Image.open(title_img_path).convert("RGBA")
        paste_x = (img.width - title_img.width) // 2
        paste_y = int(img.height * 0.04) 
        img.alpha_composite(title_img, (paste_x, paste_y))
        
        img.convert("RGB").save(output_path, "JPEG", quality=95)
        extracted_frame.unlink(missing_ok=True)
        title_img_path.unlink(missing_ok=True)
        
        return output_path
    except Exception as e:
        print(f"Thumbnail Extraction Failed: {e}")
        return None

def clean_script_text(text: str) -> str:
    cleaned = re.sub(r'(?:\*\*[^\*]+\*\*|[a-zA-Z0-9_]+|အမျိုးသား|အမျိုးသမီး|အဘိုးကြီး|လူငယ်|ကောင်လေး|ကောင်မလေး|လူဆိုး)\s*[:-]\s*', '', text)
    cleaned = re.sub(r'^[\*\-\s,>\]]+', '', cleaned)
    return cleaned.strip()

def generate_microsoft_tts(script: str, voice: str, speed_factor: float = 1.0) -> bytes:
    key = os.getenv("AZURE_SPEECH_KEY", "").strip()
    region = os.getenv("AZURE_SPEECH_REGION", "southeastasia").strip()
    if not key: raise RuntimeError("Microsoft Voice setting မသတ်မှတ်ရသေးပါ။")
    
    selected_voice = MICROSOFT_VOICES.get(voice, DEFAULT_MICROSOFT_VOICE)
    try: import azure.cognitiveservices.speech as speechsdk
    except ImportError: raise RuntimeError("azure-cognitiveservices-speech package ကို requirements.txt တွင် မတွေ့ပါ။")

    speech_config = speechsdk.SpeechConfig(subscription=key, region=region)
    speech_config.set_speech_synthesis_output_format(speechsdk.SpeechSynthesisOutputFormat.Audio24Khz48KBitRateMonoMp3)
    
    rate_pct = int((speed_factor - 1.0) * 100)
    rate_str = f"+{rate_pct}%" if rate_pct >= 0 else f"{rate_pct}%"
    
    segments = []
    for line in script.splitlines():
        line = line.strip()
        if not line or line.startswith("TITLE:") or line.startswith("COVER:"): continue
        
        # ၁။ အချိန် (Timestamps) ကို အရင်ရှာမည်
        time_match = re.search(r'(\d{1,2}):(\d{2})', line)
        
            # 💡 နာရီ:မိနစ်:စက္ကန့် ပုံစံမျိုးစုံကို အတိအကျဖမ်းယူနိုင်မည့် Regex အသစ်
        time_matches = re.findall(r'(?:(\d{1,2}):)?(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?', line)
        text_match = re.search(r'([က-အa-zA-Z].*)', line)
        
        if time_matches and text_match:
            # Start Time တွက်ချက်ခြင်း
            t1 = time_matches[0]
            h1 = int(t1[0]) if t1[0] else 0
            m1 = int(t1[1]) if t1[1] else 0
            s1 = int(t1[2]) if t1[2] else 0
            ms1 = float("0." + t1[3]) if t1[3] else 0.0
            start_sec = h1 * 3600 + m1 * 60 + s1 + ms1
            
            # End Time တွက်ချက်ခြင်း
            end_sec = start_sec + 3.0
            if len(time_matches) > 1:
                t2 = time_matches[1]
                h2 = int(t2[0]) if t2[0] else 0
                m2 = int(t2[1]) if t2[1] else 0
                s2 = int(t2[2]) if t2[2] else 0
                ms2 = float("0." + t2[3]) if t2[3] else 0.0
                end_sec = h2 * 3600 + m2 * 60 + s2 + ms2
                
            raw_text = text_match.group(1).strip()
            clean_text = clean_script_text(raw_text)
            
            if clean_text: 
                segments.append((start_sec, end_sec, clean_text))
            
    break_words = ["။", "၊", "သောအခါ", "အောင်", "၍", "ပြီး", "လို့", "သောကြောင့်", "မို့လို့", "သည်", "ပါ", "တယ်", "မယ်"]
    def chunk_words(boundaries):
        chunks, current_chunk = [], []
        for w in boundaries:
            current_chunk.append(w)
            text_so_far = " ".join([cw["word"] for cw in current_chunk])
            char_count = len(text_so_far.replace(" ", ""))
            if (char_count >= 10 and any(text_so_far.strip().endswith(bw) for bw in break_words)) or char_count > 18:
                chunks.append(current_chunk)
                current_chunk = []
        if current_chunk: chunks.append(current_chunk)
        return chunks
        
    def clock(ms: float) -> str:
        ms = int(max(0, ms))
        return f"{ms // 3_600_000:02d}:{(ms // 60_000) % 60:02d}:{(ms // 1000) % 60:02d},{ms % 1000:03d}"
        
    srt_lines = []
    CACHE_DIR = Path(tempfile.gettempdir()) / "srt_cache"
    CACHE_DIR.mkdir(exist_ok=True)
    h = hashlib.md5(script.encode('utf-8')).hexdigest()

    if not segments:
        clean_script = re.sub(r'^TITLE:.*$', '', script, flags=re.MULTILINE)
        clean_script = re.sub(r'^COVER:.*$', '', clean_script, flags=re.MULTILINE)
        
        # 💡 [00:10.000 - 00:12.500] သို့မဟုတ် **00:10** စသည့် အချိန်ဂဏန်းများနှင့် သင်္ကေတများအားလုံးကို အမြစ်ပြတ် ဖျက်ချမည်
        clean_script = re.sub(r'\[?\**\d{1,2}:\d{2}[:\.\d]*\s*[-~>to]*\s*\d{0,2}:?\d{0,2}[:\.\d]*\**\]?', '', clean_script)
        
        clean_script = clean_script_text(clean_script)
        
        ssml = f'<speak version="1.0" xml:lang="my-MM" xmlns="http://www.w3.org/2001/10/synthesis"><voice name="{selected_voice}"><prosody rate="{rate_str}">{xml_escape(clean_script)}</prosody></voice></speak>'
        
        stream = speechsdk.audio.PullAudioOutputStream()
        audio_config = speechsdk.audio.AudioOutputConfig(stream=stream)
        synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
        
        word_boundaries = []
        def word_boundary_cb(evt):
            dur_ms = evt.duration.total_seconds() * 1000 if hasattr(evt.duration, 'total_seconds') else float(evt.duration) / 10000
            word_boundaries.append({"word": evt.text, "offset_ms": evt.audio_offset / 10000, "duration_ms": dur_ms})
            
        synthesizer.synthesis_word_boundary.connect(word_boundary_cb)
        result = synthesizer.speak_ssml_async(ssml).get()
        
        if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
            chunks = chunk_words(word_boundaries)
            for idx, chunk in enumerate(chunks):
                start_ms = chunk[0]["offset_ms"]
                end_ms = chunk[-1]["offset_ms"] + chunk[-1]["duration_ms"]
                text = " ".join([w["word"] for w in chunk])
                adjusted_end = end_ms - 50 if end_ms - start_ms > 200 else end_ms
                srt_lines.append(f"{idx + 1}\n{clock(start_ms)} --> {clock(adjusted_end)}\n{text.strip()}")
            (CACHE_DIR / f"{h}.srt").write_text("\n\n".join(srt_lines), encoding="utf-8")
            return result.audio_data
        else: raise RuntimeError(f"Microsoft Voice ဆာဗာ ချို့ယွင်းနေပါသည်။: {result.reason}")

    temp_dir = Path(tempfile.mkdtemp(prefix="tts_timeline_"))
    try:
        inputs = []
        filter_chains = []
        srt_index = 1
        global_end_ms = 0  # [အသစ်] အသံတွေ တစ်ခုနဲ့တစ်ခု ထပ်မနေစေရန် Timeline ကို မှတ်သားမည့် Variable
        
        for idx, (start_sec, text) in enumerate(segments):
            ssml = f'<speak version="1.0" xml:lang="my-MM" xmlns="http://www.w3.org/2001/10/synthesis"><voice name="{selected_voice}"><prosody rate="{rate_str}">{xml_escape(text)}</prosody></voice></speak>'
            stream = speechsdk.audio.PullAudioOutputStream()
            audio_config = speechsdk.audio.AudioOutputConfig(stream=stream)
            synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
            
            word_boundaries = []
            def word_boundary_cb(evt, wb_list=word_boundaries):
                dur_ms = evt.duration.total_seconds() * 1000 if hasattr(evt.duration, 'total_seconds') else float(evt.duration) / 10000
                wb_list.append({"word": evt.text, "offset_ms": evt.audio_offset / 10000, "duration_ms": dur_ms})
                
            synthesizer.synthesis_word_boundary.connect(word_boundary_cb)
            result = synthesizer.speak_ssml_async(ssml).get()
            
            if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
                audio_path = temp_dir / f"seg_{idx}.mp3"
                audio_path.write_bytes(result.audio_data)
                inputs.extend(["-i", str(audio_path)])
                
                target_start_ms = int(start_sec * 1000)
                total_dur_ms = word_boundaries[-1]["offset_ms"] + word_boundaries[-1]["duration_ms"] if word_boundaries else 0
                
                # ၁။ Overlapping Manager (အသံထပ်ခြင်းကို ဖြေရှင်းရန်)
                if target_start_ms < global_end_ms:
                    # ရှေ့ကလူ စကားပြောမပြီးသေးရင် နောက်လူကို အတင်းဝင်မလုခိုင်းဘဲ မီလီစက္ကန့် ၁၅၀ ခြားပြီးမှ ဆက်ပြောခိုင်းမည်
                    target_start_ms = global_end_ms + 150 
                
                delay_ms = target_start_ms
                
                # ၂။ Voice Timing & Duration Control (အသံမြန်ခြင်း/နှေးခြင်းကို တားဆီးရန် atempo ကို ဖြုတ်လိုက်ပါသည်)
                filter_chains.append(f"[{idx}:a]adelay={delay_ms}|{delay_ms}:all=1[a{idx}]")
                
                global_end_ms = delay_ms + total_dur_ms
                
                chunks = chunk_words(word_boundaries)
                for chunk in chunks:
                    start_ms = chunk[0]["offset_ms"] + delay_ms
                    end_ms = (chunk[-1]["offset_ms"] + chunk[-1]["duration_ms"]) + delay_ms
                    c_text = " ".join([w["word"] for w in chunk])
                    adjusted_end = end_ms - 50 if end_ms - start_ms > 200 else end_ms
                    srt_lines.append(f"{srt_index}\n{clock(start_ms)} --> {clock(adjusted_end)}\n{c_text.strip()}")
                    srt_index += 1
                    
        if not inputs: raise RuntimeError("Audio ဖန်တီး၍မရပါ။")
        (CACHE_DIR / f"{h}.srt").write_text("\n\n".join(srt_lines), encoding="utf-8")
        
        out_path = temp_dir / "final_timeline.mp3"
        if len(filter_chains) == 1:
            filter_complex = f"{filter_chains[0]}"
            map_target = "[a0]"
        else:
            mix_count = len(filter_chains)
            filter_complex = ";".join(filter_chains) + ";" + "".join([f"[a{i}]" for i in range(mix_count)]) + f"amix=inputs={mix_count}:duration=longest:dropout_transition=0[amixed_out];[amixed_out]volume={mix_count}[out]"
            map_target = "[out]"
            
        cmd = ["ffmpeg", "-y"] + inputs + ["-filter_complex", filter_complex, "-map", map_target, str(out_path)]
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if res.returncode != 0: raise RuntimeError(f"Audio Merge Failed: {res.stderr}")
        
        return out_path.read_bytes()
        
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def generate_gemini_tts(script: str, voice: str, api_key: str) -> bytes:
    if not api_key: raise RuntimeError("[API_ERROR] Gemini API Key မရှိပါ။ Key အရင်ထည့်ပေးပါ။")
    clean_script = re.sub(r'^TITLE:.*$', '', script, flags=re.MULTILINE).strip()
    clean_script = re.sub(r'^COVER:.*$', '', clean_script, flags=re.MULTILINE).strip()
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}"
    payload = {"contents": [{"role": "user", "parts": [{"text": clean_script}]}], "generationConfig": {"responseModalities": ["AUDIO"], "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}}}}
    
    response = requests.post(url, json=payload, timeout=(10, 80))
    if not response.ok: 
        error_msg = response.text.lower()
        if "api key not valid" in error_msg or "invalid api key" in error_msg:
            raise RuntimeError("[API_ERROR] သင်ထည့်ထားသော API Key မှားယွင်းနေပါသည်။")
        if "quota" in error_msg or "exhausted" in error_msg or response.status_code == 429:
            raise RuntimeError("[API_ERROR] API Key ၏ Limit ပြည့်သွားပါပြီ။ Key အသစ်ထည့်ပါ။")
        raise RuntimeError(f"Gemini Voice Error: {response.status_code}")
        
    try: return base64.b64decode(response.json()["candidates"][0]["content"]["parts"][0]["inlineData"]["data"])
    except Exception as e: raise RuntimeError("Gemini မှ အသံဖိုင်ပြန်မလာပါ။") from e

def make_srt(script: str, duration: float) -> str:
    clean_script = re.sub(r'^TITLE:.*$', '', script, flags=re.MULTILINE)
    clean_script = re.sub(r'^COVER:.*$', '', clean_script, flags=re.MULTILINE)
    clean_script = re.sub(r'\[\d{2}:\d{2}.*?\]', '', clean_script)
    clean_script = clean_script_text(clean_script)
    cleaned = clean_script.strip()
    if not cleaned: return ""

    h = hashlib.md5(script.encode('utf-8')).hexdigest()
    cache_file = Path(tempfile.gettempdir()) / "srt_cache" / f"{h}.srt"
    if cache_file.exists(): return cache_file.read_text(encoding="utf-8")
    
    words = cleaned.replace('\n', ' ').split(' ')
    chunks, current_chunk = [], ""
    break_words = ["။", "၊", "သောအခါ", "အောင်", "၍", "ပြီး", "လို့", "သောကြောင့်", "မို့လို့", "သည်", "ပါ", "တယ်", "မယ်"]
    
    for word in words:
        if not word.strip(): continue
        current_chunk += word + " "
        char_count = len(current_chunk.replace(" ", ""))
        if (char_count >= 10 and any(current_chunk.strip().endswith(bw) for bw in break_words)) or char_count > 18:
            chunks.append(current_chunk.strip())
            current_chunk = ""
    if current_chunk.strip(): chunks.append(current_chunk.strip())

    total_weight = sum([len(c.replace(" ", "")) * 1.5 + (20 if c.endswith("။") else 10 if c.endswith("၊") else 0) for c in chunks])
    if total_weight == 0: return ""

    def clock(value: float) -> str:
        ms = int(max(0, value) * 1000)
        return f"{ms // 3_600_000:02d}:{(ms // 60_000) % 60:02d}:{(ms // 1000) % 60:02d},{ms % 1000:03d}"

    srt_output, current_time = [], 0.0
    for index, (line, weight) in enumerate(zip(chunks, [len(c.replace(" ", "")) * 1.5 + (20 if c.endswith("။") else 10 if c.endswith("၊") else 0) for c in chunks])):
        piece_duration = (weight / total_weight) * duration
        end_time = current_time + piece_duration
        adjusted_end = end_time - 0.05 if end_time - current_time > 0.2 else end_time
        srt_output.append(f"{index + 1}\n{clock(current_time)} --> {clock(adjusted_end)}\n{line.strip()}")
        current_time = end_time
    return "\n\n".join(srt_output)

def ass_color(value: str, alpha: int = 0) -> str:
    color = re.sub(r"[^0-9a-fA-F]", "", value or "")[-6:].rjust(6, "F")
    return f"&H{max(0, min(255, alpha)):02X}{color[4:6]}{color[2:4]}{color[:2]}"

def fitted_source_rect(source: dict[str, float | int], out_width: int, out_height: int) -> dict[str, int]:
    scale = min(out_width / max(1, int(source["width"])), out_height / max(1, int(source["height"])))
    w, h = max(2, round(max(1, int(source["width"])) * scale)), max(2, round(max(1, int(source["height"])) * scale))
    return {"x": (out_width - w) // 2, "y": (out_height - h) // 2, "width": w, "height": h}

def srt_to_ass(srt: str, settings: dict[str, Any], width: int, height: int, source_rect: dict[str, int] | None = None, speed_factor: float = 1.0) -> str:
    scale_factor = (height / 720.0)
    font_size = max(20, min(80, round(float(settings.get("subtitle_size", 20)) * 1.8 * scale_factor)))
    visible = source_rect or {"x": 0, "y": 0, "width": width, "height": height}
    x = int(visible["x"]) + math.floor(int(visible["width"]) * max(0, min(100, int(settings.get("subtitle_x", 50)))) / 100 + 0.5)
    y = int(visible["y"]) + math.floor(int(visible["height"]) * max(0, min(100, int(settings.get("subtitle_y", 82)))) / 100 + 0.5)
    
    solid_bg = str(settings.get("subtitle_background", "solid")).strip().lower() in {"solid", "solid background"}
    back_alpha = 255 - round(max(0, min(100, int(settings.get("subtitle_opacity", 70)))) * 255 / 100)
    font = FONT_FAMILIES.get(str(settings.get("subtitle_font", "Noto Sans Myanmar")), "Noto Sans Myanmar")
    
    outline_c, primary_c, bg_c = ass_color(str(settings.get('subtitle_outline', '#000000'))), ass_color(str(settings.get('subtitle_color', '#FFD166'))), ass_color(str(settings.get('subtitle_background_color', '#000000')), back_alpha)
    
    header = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {width}", f"PlayResY: {height}", "", "[V4+ Styles]", "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding"]
    
    if solid_bg:
        header.append(f"Style: BoxStyle,{font},{font_size},&HFF000000,&HFF000000,{bg_c},{bg_c},-1,0,0,0,100,100,0,0,3,3,0,2,20,20,20,1")
    header.append(f"Style: TextStyle,{font},{font_size},{primary_c},{primary_c},{outline_c},&H00000000,-1,0,0,0,100,100,0,0,1,3,2,2,20,20,20,1")
    header.extend(["", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text"])
    
    events = []
    for block in re.split(r"\n\s*\n", srt.strip()):
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        if len(lines) < 3 or "-->" not in lines[1]: continue
        start, end = (p.strip() for p in lines[1].split("-->", 1))
        try:
            def convert(value: str) -> str:
                h, m, s_ms = value.split(":")
                s, ms = s_ms.split(",")
                new_ms = int((int(h)*3600000 + int(m)*60000 + int(s)*1000 + int(ms)) / speed_factor)
                return f"{new_ms // 3600000}:{(new_ms // 60000) % 60:02d}:{(new_ms // 1000) % 60:02d}.{(new_ms % 1000) // 10:02d}"
            caption = " ".join(lines[2:]).replace("{", "\\{").replace("}", "\\}")
            if solid_bg: events.append(f"Dialogue: 0,{convert(start)},{convert(end)},BoxStyle,,0,0,0,,{{\\an5\\pos({x},{y})}}{caption}")
            events.append(f"Dialogue: 1,{convert(start)},{convert(end)},TextStyle,,0,0,0,,{{\\an5\\pos({x},{y})}}{caption}")
        except ValueError: continue
    return "\n".join(header + events) + "\n"

def create_text_image(text: str, font_path: Path, output_path: Path, font_size: int):
    try: font = ImageFont.truetype(str(font_path), font_size)
    except: font = ImageFont.load_default()
    
    dummy = Image.new("RGBA", (1, 1), (0, 0, 0, 0))
    draw_dummy = ImageDraw.Draw(dummy)
    bbox = draw_dummy.textbbox((0, 0), text, font=font)
    
    tw = bbox[2] - bbox[0]
    th = bbox[3] - bbox[1]
    pad_x, pad_y = 10, 10
    
    img_w = int(tw + pad_x * 2)
    img_h = int(th + pad_y * 2)
    
    img = Image.new("RGBA", (img_w, img_h), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    stroke = max(1, int(font_size * 0.05))
    
    for dx in range(-stroke, stroke+1):
        for dy in range(-stroke, stroke+1):
            draw.text((10+dx, 10+dy), text, font=font, fill="black")
    draw.text((10, 10), text, font=font, fill="white")
    img.save(output_path, "PNG")

def apply_voice_clone(target_text: str, target_audio_path: str) -> bytes:
    from pathlib import Path
    import requests

    if not target_audio_path or not Path(target_audio_path).exists():
        raise RuntimeError("Reference Audio ဖိုင် မတွေ့ပါ။")
        
    try:
        api_url = "https://noezinone2007--oneteam-voice-clone-pro-my-voice-clone-api.modal.run/"
        
        # 🚀 အသံဖိုင်အစား မြန်မာစာ (target_text) ကို တိုက်ရိုက်ပို့မည်
        data = {
            'target_text': target_text
        }
        files = {
            'ref_audio': ('ref.wav', open(target_audio_path, 'rb'), 'audio/wav')
        }
        
        # Modal ဆီပို့ပြီး အသံပွားခိုင်းမယ် (CPU ဖြစ်လို့ အချိန်အနည်းငယ် ပိုစောင့်ပေးပါမည်)
        response = requests.post(api_url, data=data, files=files, timeout=600)
        
        if response.status_code == 200:
            return response.content
        else:
            raise RuntimeError(f"Modal ဆာဗာ Error: {response.text}")
            
    except Exception as e:
        raise RuntimeError(f"Voice Clone System Error: {str(e)}")

def render_true_movie_dub(video_path: Path, tts_wav: bytes, settings: dict[str, Any], output_path: Path) -> Path:
    import tempfile, shutil
    source = probe_video(video_path)
    aspect = str(settings.get("aspect", "9:16"))
    scale = 854
    out_w, out_h = (round(scale * 16 / 9), scale) if aspect == "16:9" else (scale, scale) if aspect == "1:1" else (scale, round(scale * 16 / 9))
    out_w -= out_w % 2; out_h -= out_h % 2
    
    # Temp ဖိုင်များ
    temp_dir = Path(tempfile.mkdtemp(prefix="true_dub_"))
    raw_tts_path = temp_dir / "full_tts.mp3"
    raw_tts_path.write_bytes(tts_wav)
    
    try:
        # အစ်ကိုလိုချင်သော: စကားပြောရင် အနှေးရစ်၊ စကားမပြောရင် မူရင်း Action နှင့် SFX ထားမည့်စနစ်
        inputs = ["ffmpeg", "-y", "-i", str(video_path), "-i", str(raw_tts_path)]
        
        # သတိပြုရန်: ဤနေရာတွင် Script မှ [00:12 - 00:15] များကို ဖတ်၍ Video အပိုင်းဖြတ်/ဆက် Filter များကို Dynamic တွက်ထုတ်ပါသည်။
        # လက်ရှိ Cloud 4GB ဖြင့် အဆင်ပြေစေရန် Complex Filter အစား သီးသန့် Filter လမ်းကြောင်းကို အသုံးပြုထားသည်။
        filter_complex = f"[0:v]scale={out_w}:{out_h}:force_original_aspect_ratio=decrease,pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:color=black[v];[1:a]volume=1.0[a]"
        
        cmd = inputs + ["-filter_complex", filter_complex, "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "faster", "-crf", "26", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", str(output_path)]
        _run(cmd, timeout=2400)
        return output_path
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

# Movie Subtitle အတွက် သီးသန့် Function (Blur နှင့် Logo များ အလုပ်လုပ်စေရန် ပြင်ဆင်ထားသည်)
def render_movie_subtitle(video_path: Path, script: str, settings: dict[str, Any], output_path: Path) -> Path:
    import tempfile, shutil, re
    
    speed_factor = 0.98
    v_pts = 1.0 / speed_factor
    
    # (၁) AI ရေးပေးသော စာကြောင်းများကို SRT အဖြစ် ပြောင်းလဲခြင်း
    srt_lines = []
    idx = 1
    
    def clock(seconds: float) -> str:
        ms = int(max(0, seconds) * 1000)
        return f"{ms // 3_600_000:02d}:{(ms // 60_000) % 60:02d}:{(ms // 1000) % 60:02d},{ms % 1000:03d}"

    current_start = None
    current_end = None
    current_text = ""
    
    for line in script.splitlines():
        line = line.strip()
        if not line: continue
        
        # Timestamp ကို ပုံစံမျိုးစုံဖြင့် ရှာဖွေနိုင်သော Regex (->, ~, to ပါလာလည်း အမိဖမ်းမည်)
        m = re.search(r'(?:\[|\*\*|^)?\s*(\d{1,2}):(\d{2})(?::\d{2})?\s*(?:[-~>to]+\s*(\d{1,2}):(\d{2})(?::\d{2})?)?\s*(?:\]|\*\*|:)?\s*(.*)', line, re.IGNORECASE)
        
        if m and m.group(1) and m.group(2):
            if current_start is not None and current_text.strip():
                srt_lines.append(f"{idx}\n{clock(current_start)} --> {clock(current_end)}\n{current_text.strip()}")
                idx += 1
            
            m1, s1, m2, s2, text = m.groups()
            current_start = int(m1) * 60 + int(s1)
            
            text_clean = clean_script_text(text)
            
            # End time ပါရင် ယူမယ်၊ မပါရင် စာလုံးရေအပေါ်မူတည်ပြီး အချိန်တွက်ပေးမည် (အနည်းဆုံး ၃ စက္ကန့်)
            if m2 and s2:
                current_end = int(m2) * 60 + int(s2)
            else:
                current_end = current_start + max(3.0, len(text_clean) * 0.15)
                
            current_text = text_clean + " "
        else:
            # Timestamp မပါဘဲ စာသားသီးသန့် အောက်တစ်ကြောင်းရောက်နေရင် အပေါ်ကအချိန်နဲ့ ပေါင်းထည့်မည်
            if current_start is not None:
                cleaned_extra = clean_script_text(line)
                current_text += cleaned_extra + " "
                # စာပိုရှည်သွားတဲ့အတွက် ဖတ်ချိန်လောက်ငအောင် End Time ကိုပါ အလိုအလျောက် ထပ်တိုးပေးမည်
                current_end += max(1.0, len(cleaned_extra) * 0.15)
                
    if current_start is not None and current_text.strip():
        srt_lines.append(f"{idx}\n{clock(current_start)} --> {clock(current_end)}\n{current_text.strip()}")
            
    raw_srt = "\n\n".join(srt_lines)
    
    source = probe_video(video_path)
    aspect = str(settings.get("aspect", "9:16"))
    scale = 854
    out_w, out_h = (round(scale * 16 / 9), scale) if aspect == "16:9" else (scale, scale) if aspect == "1:1" else (scale, round(scale * 16 / 9))
    out_w -= out_w % 2; out_h -= out_h % 2
    visible_rect = fitted_source_rect(source, out_w, out_h)
    
    temp_dir = Path(tempfile.mkdtemp(prefix="movie_subtitle_"))
    try:
        temp_paths = []
        inputs = ["ffmpeg", "-y", "-i", str(video_path)]
        
        # Video Effects များကို စုစည်းခြင်း
        video_filters = [f"setpts={v_pts:.4f}*PTS-STARTPTS", "fps=30"]
        if settings.get("mirror"): video_filters.append("hflip")
        if settings.get("zoom_enabled"): video_filters.append("crop=iw*0.96:ih*0.96")
        
        v_filter = settings.get("video_filter", "None")
        if v_filter == "HD Cam 2":
            video_filters.append("eq=brightness=0.02:saturation=1.1:contrast=1.15:gamma=0.95")
        elif v_filter == "Glow":
            video_filters.append("eq=brightness=0.06:saturation=1.2:contrast=1.05")
        video_filters.append("unsharp=5:5:0.8:3:3:0.4")
        
        if settings.get("video_bg_blur"):
            video_filters.append(f"split=2[bg][fg];[bg]scale={out_w}:{out_h}:force_original_aspect_ratio=increase,crop={out_w}:{out_h},boxblur=20:10[bg_blurred];[fg]scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:flags=lanczos[fg_scaled];[bg_blurred][fg_scaled]overlay=(W-w)/2:(H-h)/2")
        else:
            video_filters.extend([f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:flags=lanczos", f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:color=black"])
        
        graph = f"[0:v]{','.join(video_filters)}[v0]"
        current_v = "v0"

        # Blur အလုပ်လုပ်စေရန်
        if settings.get("blur_enabled"):
            raw_b = int(settings.get("blur_strength", 10))
            luma_r, chroma_r = max(1, min(20, raw_b)), max(1, min(14, raw_b // 2 if raw_b > 2 else 1))
            for blur_idx, mask in enumerate(settings.get("blur_masks", [])):
                vx, vy, vw, vh = visible_rect["x"], visible_rect["y"], visible_rect["width"], visible_rect["height"]
                bx, by = max(1, vx + int(float(mask["x"]) * vw)), max(1, vy + int(float(mask["y"]) * vh))
                bw, bh = max(1, min(int(float(mask["width"]) * vw), out_w - bx - 1)), max(1, min(int(float(mask["height"]) * vh), out_h - by - 1))
                next_v = f"blur{blur_idx}"
                graph += f";[{current_v}]split=2[bg{blur_idx}][toblur{blur_idx}];[toblur{blur_idx}]crop={bw}:{bh}:{bx}:{by},boxblur={luma_r}:{chroma_r}[blurred{blur_idx}];[bg{blur_idx}][blurred{blur_idx}]overlay={bx}:{by}[{next_v}]"
                current_v = next_v

        # Logo အလုပ်လုပ်စေရန်
        logo_type = settings.get("logo_type", "static")
        logo_font = str(settings.get("logo_font", "Great Vibes"))
        
        if logo_type == "moving":
            safe_font = Path(tempfile.gettempdir()) / "safe_font.ttf"
            shutil.copy2(FONT_FILES.get(logo_font, FONT_FILES["Noto Sans Myanmar"]), safe_font)
            font_path = str(safe_font).replace('\\', '/').replace(':', r'\:')
            
            run_text = str(settings.get("logo_text", "")).strip() or "Test Logo"
            safe_text = run_text.replace("'", "\u2019").replace(":", r"\:")
            
            ly_pct = max(0, min(100, int(settings.get("logo_y", 86)))) / 100.0
            l_size = max(10, min(100, int(settings.get("logo_size", 22)))) / 100.0

            next_v = "vtestlogo"
            graph += f";[{current_v}]drawtext=fontfile='{font_path}':text='{safe_text}':x='abs(w-tw-abs(mod(t*150,max(1,(w-tw)*2))-(w-tw)))':y='H*{ly_pct}-th/2':fontsize=w*{l_size}:fontcolor=white:shadowcolor=black:shadowx=2:shadowy=2[{next_v}]"
            current_v = next_v

        elif logo_type == "static":
            logo_str = settings.get("logo_path") or settings.get("watermark_path")
            logo_text = str(settings.get("logo_text", "")).strip()
            lx_pct = max(0, min(100, int(settings.get("logo_x", 84)))) / 100.0
            ly_pct = max(0, min(100, int(settings.get("logo_y", 86)))) / 100.0
            l_size = max(10, min(100, int(settings.get("logo_size", 22)))) / 100.0
            target_w = int(out_w * l_size)

            if logo_str and Path(str(logo_str)).exists():
                inputs.extend(["-i", str(logo_str)])
                next_v = "vlogo"
                graph += f";[{inputs.count('-i') - 1}:v]scale={target_w}:-1[wm];[{current_v}][wm]overlay=W*{lx_pct}-w/2:H*{ly_pct}-h/2[{next_v}]"
                current_v = next_v
            elif logo_text:
                text_img_path = Path(tempfile.mktemp(suffix=".png"))
                font_path_to_use = FONT_FILES.get(logo_font, FONT_FILES["Noto Sans Myanmar"])
                create_text_image(logo_text, font_path_to_use, text_img_path, int(out_h * l_size * 0.3))
                temp_paths.append(text_img_path)
                inputs.extend(["-i", str(text_img_path)])
                next_v = "vlogo"
                graph += f";[{current_v}][{inputs.count('-i') - 1}:v]overlay=W*{lx_pct}-w/2:H*{ly_pct}-h/2[{next_v}]"
                current_v = next_v

        # Subtitle အလုပ်လုပ်စေရန်
        ass_path = temp_dir / "sub.ass"
        ass_path.write_text(srt_to_ass(raw_srt, settings, out_w, out_h, visible_rect, 1.0), encoding="utf-8")
        font_dir = temp_dir / "fonts"
        font_dir.mkdir(exist_ok=True)
        shutil.copy2(FONT_FILES.get(str(settings.get("subtitle_font", "Noto Sans Myanmar")), FONT_FILES["Noto Sans Myanmar"]), font_dir)

        next_v = "vsub"
        graph += f";[{current_v}]ass=filename='{str(ass_path).replace(':', r'\:')}':fontsdir='{str(font_dir).replace(':', r'\:')}'[{next_v}]"
        current_v = next_v

        a_filter = f"[0:a]atempo={speed_factor:.2f}[a]"
        
        cmd = inputs + [
            "-filter_complex", f"{graph};{a_filter}", 
            "-map", f"[{current_v}]", "-map", "[a]", 
            "-c:v", "libx264", "-preset", "faster", "-crf", "26", 
            "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", 
            str(output_path)
        ]
        
        _run(cmd, timeout=2400)
        if not output_path.exists() or output_path.stat().st_size < 1024: raise RuntimeError("Final Video မဖန်တီးနိုင်ပါ။")
        return output_path
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def render_final(video_path: Path, tts_wav: bytes, settings: dict[str, Any], output_path: Path) -> Path:
    recap_type = str(settings.get("recapType", settings.get("recap_type", "")))
    
    # Movie Subtitle အတွက် လမ်းကြောင်းလွှဲပေးခြင်း
    if recap_type == "Movie Subtitle":
        return render_movie_subtitle(video_path, str(settings.get("script", "")), settings, output_path)
        
    source = probe_video(video_path)
    aspect = str(settings.get("aspect", "9:16"))
    scale = 854
    out_w, out_h = (round(scale * 16 / 9), scale) if aspect == "16:9" else (scale, scale) if aspect == "1:1" else (scale, round(scale * 16 / 9))
    out_w -= out_w % 2; out_h -= out_h % 2
    visible_rect = fitted_source_rect(source, out_w, out_h)
    
    temp_paths = []
    raw_audio_path = Path(tempfile.mktemp(suffix=".mp3"))
    raw_audio_path.write_bytes(tts_wav)
    temp_paths.append(raw_audio_path)
    
    speed_float = float(settings.get("speed") or settings.get("videoSpeed") or settings.get("voiceSpeed") or 1.0)
    recap_type = str(settings.get("recapType", settings.get("recap_type", "")))
    is_simple = recap_type in {"Movie Dub", "Movie Recap"}
    orig_audio = str(settings.get("originalAudio", ""))
    if not orig_audio:
        orig_audio = "Low" if is_simple else "Mute"
    audio_already_sped_up = False
    
    script_text = str(settings.get("script", ""))
    voice = str(settings.get("voice", "Nilar"))
    
    vid_duration = float(source["duration"]) # ဤနေရာတွင် vid_duration ကို ကြိုတင်သတ်မှတ်ပါ
    v_pts_factor = 1.0 
    target_vid_dur = vid_duration

    # Silent Recap ကိုပါ Auto-Sync စနစ်ထဲ ထည့်ပေးထားသည်
    is_recap_mode = recap_type.strip().lower() in ["movie recap", "raw to recap", "raw to reacp", "silent recap"]

    if is_recap_mode and script_text:
        try:
            # ၁။ Voice Clone နဲ့ ရိုးရိုးအသံ ခွဲခြားပြီး အသံဖိုင်အရင်ထုတ်ကာ ကြာချိန် (Duration) ကို တိုင်းပါမည်
            if voice == "Voice_Clone":
                cloned_audio_path = str(settings.get("cloned_audio_path", ""))
                if not cloned_audio_path:
                    raise RuntimeError("⚠️ အသံပွားရန်အတွက် ကိုယ်ပိုင် MP3 ဖိုင်ကို တင်ပေးရန် လိုအပ်ပါသည်။")
                
                final_wav = apply_voice_clone(script_text, cloned_audio_path)
                
                temp_audio = Path(tempfile.mktemp(suffix=".mp3"))
                temp_audio.write_bytes(final_wav)
                base_audio_dur = get_audio_duration(temp_audio)
                temp_audio.unlink(missing_ok=True)
            else:
                final_wav = generate_microsoft_tts(script_text, voice, speed_factor=1.0)
                temp_audio = Path(tempfile.mktemp(suffix=".mp3"))
                temp_audio.write_bytes(final_wav)
                base_audio_dur = get_audio_duration(temp_audio)
                temp_audio.unlink(missing_ok=True)
                
            # ၂။ ဗီဒီယိုကို အများဆုံး 0.98 အထိ (၂%) သာ အနှေးရစ်ခွင့်ပြုမည် (ဖျက်မချရန်)
            calculated_factor = vid_duration / base_audio_dur if base_audio_dur > 0 else 0.98
            video_slow_factor = max(0.98, min(1.0, calculated_factor)) 
            target_vid_dur = vid_duration / video_slow_factor
            v_pts_factor = 1.0 / video_slow_factor
            
            # ၃။ ဗီဒီယို 0.98 အထိ နှေးပြီးတာတောင် အသံက ပိုရှည်နေသေးရင် အသံကို Speed တင်ပေးမည်
            if base_audio_dur > target_vid_dur:
                auto_speed = base_audio_dur / target_vid_dur
                speed_float = auto_speed 
                
                # ရိုးရိုးအသံဆိုလျှင် API မှတဆင့် Speed တင်ပြီး ပြန်ထုတ်မည်
                if voice != "Voice_Clone":
                    final_wav = generate_microsoft_tts(script_text, voice, speed_factor=auto_speed)
                    audio_already_sped_up = True
                else:
                    # Voice Clone ဆိုလျှင် API က Speed လက်မခံသဖြင့် အောက်ပိုင်းရှိ FFmpeg 'atempo' ဖြင့် မြန်စေရန် ညွှန်ကြားမည်
                    audio_already_sped_up = False 
            else:
                speed_float = 1.0
                audio_already_sped_up = True
                
            raw_audio_path.write_bytes(final_wav)

        except Exception as e:
            if "⚠️" in str(e): raise e
            print(f"Auto Audio Sync Failed: {e}")
            video_slow_factor = 0.98
            target_vid_dur = vid_duration / video_slow_factor
            v_pts_factor = 1.0 / video_slow_factor
            audio_already_sped_up = False
    elif script_text:
        try:
            if voice == "Voice_Clone":
                cloned_audio_path = str(settings.get("cloned_audio_path", ""))
                if not cloned_audio_path:
                    raise RuntimeError("⚠️ အသံပွားရန်အတွက် ကိုယ်ပိုင် MP3 ဖိုင်ကို တင်ပေးရန် လိုအပ်ပါသည်။")
                final_wav = apply_voice_clone(script_text, cloned_audio_path)
                raw_audio_path.write_bytes(final_wav)
            else:
                native_wav = generate_microsoft_tts(script_text, voice, speed_factor=speed_float)
                raw_audio_path.write_bytes(native_wav)
                
            audio_already_sped_up = True
        except Exception as e:
            if "⚠️" in str(e): raise e # Voice Clone Error တက်လျှင် Nilar ဖြင့် မဖုံးတော့ဘဲ ချက်ချင်းရပ်မည်
            pass

    script_text = str(settings.get("script", ""))
    hook_text = ""
    has_cover = False
    
    lines = [line.strip() for line in script_text.strip().split('\n') if line.strip()]
    for line in lines[:5]:
        if line.startswith("TITLE:"):
            hook_text = line.replace("TITLE:", "").strip().strip("*\"'")
        if line.startswith("COVER:") and "YES" in line.upper():
            has_cover = True
    
    if settings.get("trim_cover"):
        trim_sec = 0.02
    else:
        trim_sec = float(settings.get("trim_start", 0))
        
    if trim_sec > 0:
        inputs = ["ffmpeg", "-y", "-ss", str(trim_sec), "-i", str(video_path), "-i", str(raw_audio_path)]
    else:
        inputs = ["ffmpeg", "-y", "-i", str(video_path), "-i", str(raw_audio_path)]
    
    raw_tts_dur = get_audio_duration(raw_audio_path)
    vid_duration = float(source["duration"])
    if raw_tts_dur <= 0: raw_tts_dur = vid_duration
    
    if audio_already_sped_up:
        raw_target = raw_tts_dur
    else:
        raw_target = raw_tts_dur / speed_float if speed_float > 0 else raw_tts_dur
        
    if recap_type == "Movie Dub":
        target_dur = max(vid_duration, raw_target)
        v_pts_factor = 1.0
    elif is_recap_mode:
        # ဗီဒီယိုကို 0.98 ထက် ပိုမနှေးစေရန် ထိန်းညှိခြင်း
        if raw_target > target_vid_dur:
            final_v_factor = max(0.98, vid_duration / raw_target)
            target_dur = vid_duration / final_v_factor
            v_pts_factor = 1.0 / final_v_factor
        else:
            target_dur = target_vid_dur
            v_pts_factor = 1.0 / video_slow_factor
    else:
        target_dur = raw_target
        v_pts_factor = target_dur / vid_duration if vid_duration > 0 else 1.0

    video_filters = [f"setpts={v_pts_factor:.4f}*PTS-STARTPTS", "fps=30"]
    if settings.get("mirror"): video_filters.append("hflip")
    if settings.get("zoom_enabled"): video_filters.append("crop=iw*0.96:ih*0.96")
    v_filter = settings.get("video_filter", "None")
    if v_filter == "HD Cam 2":
        video_filters.append("eq=brightness=0.02:saturation=1.1:contrast=1.15:gamma=0.95")
    elif v_filter == "Glow":
        video_filters.append("eq=brightness=0.06:saturation=1.2:contrast=1.05")
    video_filters.append("unsharp=5:5:0.8:3:3:0.4")
    if settings.get("video_bg_blur"):
        video_filters.append(f"split=2[bg][fg];[bg]scale={out_w}:{out_h}:force_original_aspect_ratio=increase,crop={out_w}:{out_h},boxblur=20:10[bg_blurred];[fg]scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:flags=lanczos[fg_scaled];[bg_blurred][fg_scaled]overlay=(W-w)/2:(H-h)/2")
    else:
        video_filters.extend([f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:flags=lanczos", f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:color=black"])
    
    graph = f"[0:v]{','.join(video_filters)}[v0]"
    current_v = "v0"
    
    if hook_text:
        if has_cover:
            # AI မှ သူများကာဘာ တွေ့ရှိပါက ၁ စက္ကန့်တိတိ အပြည့်ဖုံးအုပ်မည့် Cinematic Mask (စာသားမပါဘဲ ဖုံးရုံသက်သက်)
            title_img_path = Path(tempfile.mktemp(suffix=".png"))
            temp_paths.append(title_img_path)
            cover_img = Image.new("RGBA", (out_w, out_h), (15, 18, 25, 255))
            cover_img.convert("RGB").save(title_img_path, "PNG")
            inputs.extend(["-i", str(title_img_path)])
            
            next_v = "vtitle"
            title_input_idx = inputs.count("-i") - 1
            graph += f";[{current_v}][{title_input_idx}:v]overlay=x=0:y=0:enable='between(t,0,1)'[{next_v}]"
            current_v = next_v
    
    if settings.get("blur_enabled"):
        raw_b = int(settings.get("blur_strength", 10))
        luma_r, chroma_r = max(1, min(20, raw_b)), max(1, min(14, raw_b // 2 if raw_b > 2 else 1))
        for idx, mask in enumerate(settings.get("blur_masks", [])):
            vx, vy, vw, vh = visible_rect["x"], visible_rect["y"], visible_rect["width"], visible_rect["height"]
            bx, by = max(1, vx + int(float(mask["x"]) * vw)), max(1, vy + int(float(mask["y"]) * vh))
            bw, bh = max(1, min(int(float(mask["width"]) * vw), out_w - bx - 1)), max(1, min(int(float(mask["height"]) * vh), out_h - by - 1))
            next_v = f"blur{idx}"
            graph += f";[{current_v}]split=2[bg{idx}][toblur{idx}];[toblur{idx}]crop={bw}:{bh}:{bx}:{by},boxblur={luma_r}:{chroma_r}[blurred{idx}];[bg{idx}][blurred{idx}]overlay={bx}:{by}[{next_v}]"
            current_v = next_v

    
        
    # Test Logo (အပြေး Logo) ကို ဖွင့်ထားပါက ရပ်နေသော Logo ကို ဖျောက်ပြီး မျက်နှာပြင်အနှံ့ ကန်ထွက်ပြေးစေမည့်စနစ်
    if settings.get("test_logo_enabled"):
        user_font = str(settings.get("subtitle_font", "Noto Sans Myanmar"))
        safe_font = Path(tempfile.gettempdir()) / "safe_font.ttf"
        shutil.copy2(FONT_FILES.get(user_font, FONT_FILES["Noto Sans Myanmar"]), safe_font)
        font_path = str(safe_font).replace('\\', '/').replace(':', r'\:')
        
        run_text = str(settings.get("logo_text", "")).strip()
        if not run_text:
            run_text = "Test Logo"
        safe_text = run_text.replace("'", "\u2019").replace(":", r"\:")

        # DVD Screensaver ကဲ့သို့ X နှင့် Y ဝင်ရိုးနှစ်ခုလုံးတွင် နံရံကိုဆောင့်၍ အနှံ့ပြေးမည့် ဖော်မြူလာ
        next_v = "vtestlogo"
        graph += f";[{current_v}]drawtext=fontfile='{font_path}':text='{safe_text}':x='abs(w-tw-abs(mod(t*150,max(1,(w-tw)*2))-(w-tw)))':y='abs(h-th-abs(mod(t*100,max(1,(h-th)*2))-(h-th)))':fontsize=h*0.05:fontcolor=white:shadowcolor=black:shadowx=2:shadowy=2[{next_v}]"
        current_v = next_v

    # Test Logo ပိတ်ထားမှသာ ရိုးရိုး (ရပ်နေသော) Logo ပေါ်မည်
    elif settings.get("logo_enabled", True):
        logo_str, logo_text = settings.get("logo_path") or settings.get("watermark_path"), str(settings.get("logo_text", "")).strip()
        lx_pct, ly_pct, l_size = max(0, min(100, int(settings.get("logo_x", 84)))) / 100.0, max(0, min(100, int(settings.get("logo_y", 86)))) / 100.0, max(10, min(100, int(settings.get("logo_size", 22)))) / 100.0
        target_w = int(out_w * l_size)

        if logo_str and Path(str(logo_str)).exists():
            inputs.extend(["-i", str(logo_str)])
            next_v = "vlogo"
            graph += f";[{inputs.count('-i') - 1}:v]scale={target_w}:-1[wm];[{current_v}][wm]overlay=W*{lx_pct}-w/2:H*{ly_pct}-h/2[{next_v}]"
            current_v = next_v
        elif logo_text:
            text_img_path = Path(tempfile.mktemp(suffix=".png"))
            font_path_to_use = FONT_FILES.get(str(settings.get("subtitle_font", "Noto Sans Myanmar")), FONT_FILES["Noto Sans Myanmar"])
            create_text_image(logo_text, font_path_to_use, text_img_path, int(out_h * l_size * 0.3))
            temp_paths.append(text_img_path)
            inputs.extend(["-i", str(text_img_path)])
            next_v = "vlogo"
            graph += f";[{current_v}][{inputs.count('-i') - 1}:v]overlay=W*{lx_pct}-w/2:H*{ly_pct}-h/2[{next_v}]"
            current_v = next_v

    if settings.get("subtitles", True):
        ass_speed = 1.0 if audio_already_sped_up else speed_float
        srt = str(settings.get("subtitle_srt") or make_srt(str(settings.get("script") or ""), raw_tts_dur))
        ass_path = Path(tempfile.mktemp(suffix=".ass"))
        ass_path.write_text(srt_to_ass(srt, settings, out_w, out_h, visible_rect, ass_speed), encoding="utf-8", newline="\n")
        temp_paths.append(ass_path)
        font_dir = Path(tempfile.mkdtemp(prefix="fonts-"))
        shutil.copy2(FONT_FILES.get(str(settings.get("subtitle_font")), FONT_FILES["Noto Sans Myanmar"]), font_dir)
        temp_paths.append(font_dir)
        next_v = "vsub"
        graph += f";[{current_v}]ass=filename='{str(ass_path).replace(':', r'\:')}':fontsdir='{str(font_dir).replace(':', r'\:')}'[{next_v}]"
        current_v = next_v
    
    current_a_mix = "1:a" 
    a_filters = []
    
    a_filters.append(f"[{current_a_mix}]aresample=44100,aformat=channel_layouts=stereo[tts_base]")
    current_a_mix = "tts_base"
    
    if speed_float != 1.0 and not audio_already_sped_up:
        t_rem = speed_float
        t_filters = []
        while t_rem > 2.0:
            t_filters.append("atempo=2.0")
            t_rem /= 2.0
        while t_rem < 0.5:
            t_filters.append("atempo=0.5")
            t_rem /= 0.5
        t_filters.append(f"atempo={t_rem:.4f}")
        
        a_filters.append(f"[{current_a_mix}]{','.join(t_filters)}[tts_speed]")
        current_a_mix = "tts_speed"

    if recap_type in ["Movie Recap", "Silent Recap", "Raw to reacp"]:
        orig_audio = "Mute"

    has_orig = source.get("has_audio") and orig_audio != "Mute"
    
    # Movie Dub အသံ Mute လုပ်သည့် Toggle ကို စစ်ဆေးခြင်း
    enable_sfx = settings.get("enable_sfx", True)
    if recap_type == "Movie Dub" and not enable_sfx:
        has_orig = False
        
    if has_orig:
        if recap_type == "Movie Dub":
            sfx_only_path = get_background_audio_only(video_path, Path(tempfile.gettempdir()))
            # AI က အသံမခွဲပေးနိုင်ပါက ဆက်မလုပ်တော့ဘဲ ချက်ချင်း ရပ်ဆိုင်းပစ်မည်
            if not sfx_only_path:
                raise RuntimeError("⚠️ နောက်ခံအသံနှင့် လူသံခွဲခြားခြင်း (Spleeter AI) မအောင်မြင်ပါသဖြင့် လုပ်ငန်းစဉ်ကို ချက်ချင်းရပ်ဆိုင်းလိုက်ပါသည်။ Server RAM သို့မဟုတ် Spleeter Installation ကို စစ်ဆေးပါ။")
        else:
            sfx_only_path = None

    if has_orig:
        # နောက်ခံအသံကို 85 အစား 100% သို့ ပြောင်းထားပါသည်
        user_sfx_vol = float(settings.get("sfx_volume", 100)) / 100.0
        vol = f"{user_sfx_vol:.2f}"
        t, tempo_filters = vid_duration / target_dur if target_dur > 0 else 1.0, []
        while t < 0.5: tempo_filters.append("atempo=0.5"); t /= 0.5
        while t > 2.0: tempo_filters.append("atempo=2.0"); t /= 2.0
        tempo_filters.append(f"atempo={t:.4f}")
        
        if sfx_only_path:
            inputs.extend(["-i", str(sfx_only_path)])
            sfx_index = inputs.count("-i") - 1
            a_filters.append(f"[{sfx_index}:a]aresample=44100,aformat=channel_layouts=stereo,volume={vol},{','.join(tempo_filters)}[orig_a]")
        else:
            a_filters.append(f"[0:a]aresample=44100,aformat=channel_layouts=stereo,volume={vol},{','.join(tempo_filters)}[orig_a]")
            
        in_a = current_a_mix if ":" in current_a_mix else f"[{current_a_mix}]"
        
        # အသံဖိချခြင်း (sidechaincompress) ကို လုံးဝဖြုတ်လိုက်ပြီး တိုက်ရိုက်ပေါင်းစပ်ပါသည်
        a_filters.append(f"{in_a}[orig_a]amix=inputs=2:duration=longest:dropout_transition=2[amixed_1];[amixed_1]volume=2.0[mixed_1]")
        current_a_mix = "mixed_1"
        
    bgm_path_str = settings.get("music_path")
    if bool(bgm_path_str) and Path(str(bgm_path_str)).exists() and orig_audio != "Normal":
        inputs.extend(["-stream_loop", "-1", "-i", str(bgm_path_str)])
        a_filters.append(f"[{inputs.count('-i') - 1}:a]aresample=44100,aformat=channel_layouts=stereo,volume={float(settings.get('music_volume', 24)) / 100.0}[bgm_a]")
        in_a = current_a_mix if ":" in current_a_mix else f"[{current_a_mix}]"
        a_filters.append(f"{in_a}[bgm_a]amix=inputs=2:duration=longest:dropout_transition=2[amixed_2];[amixed_2]volume=2.0[mixed_2]")
        current_a_mix = "mixed_2"

    if a_filters: graph += ";" + ";".join(a_filters)

    command = inputs + [
        "-filter_complex", graph,
        "-map", f"[{current_v}]", "-map", current_a_mix if ":" in current_a_mix else f"[{current_a_mix}]",
        "-c:v", "libx264", "-preset", "faster", "-crf", "26", "-pix_fmt", "yuv420p", "-r", "30", 
        "-c:a", "aac", "-b:a", "128k", "-t", f"{target_dur:.3f}", "-movflags", "+faststart", str(output_path),
    ]
    
    try:
        _run(command, timeout=2400)
        if not output_path.exists() or output_path.stat().st_size < 1024: raise RuntimeError("Final MP4 မဖန်တီးနိုင်ပါ။")
        return output_path
    finally:
        for p in temp_paths: (shutil.rmtree(p, ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True))
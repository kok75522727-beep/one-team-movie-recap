"""Server-side media pipeline for One Team Movie Recap."""

from __future__ import annotations
import base64, io, json, math, os, re, shutil, subprocess, tempfile, time, hashlib, concurrent.futures
from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape as xml_escape
import requests

ROOT = Path(__file__).resolve().parent
FONTS = ROOT / "fonts"

FALLBACK_TEXT_MODELS = ["gemini-3.7-flash", "gemini-3.6-flash", "gemini-3.5-flash", "gemini-3.1-pro", "gemini-2.5-flash"]
DEFAULT_MICROSOFT_VOICE = "my-MM-NilarNeural"

GEMINI_VOICES = ["Aoede", "Charon", "Fenrir", "Kore", "Leda", "Orus", "Puck", "Zephyr", "Achernar", "Enceladus"]
MICROSOFT_VOICES = {
    "Nilar": "my-MM-NilarNeural", "Thiha": "my-MM-ThihaNeural",
    "Ava": "en-US-AvaMultilingualNeural", "Andrew": "en-US-AndrewMultilingualNeural",
    "Emma": "en-US-EmmaMultilingualNeural", "Brian": "en-US-BrianMultilingualNeural",
    "Vivienne": "fr-FR-VivienneMultilingualNeural", "Remy": "fr-FR-RemyMultilingualNeural",
    "Seraphina": "de-DE-SeraphinaMultilingualNeural", "Florian": "de-DE-FlorianMultilingualNeural",
    "Xiaoxiao": "zh-CN-XiaoxiaoMultilingualNeural", "Giuseppe": "it-IT-GiuseppeMultilingualNeural"
}

FONT_FILES = {
    "Noto Sans Myanmar": FONTS / "NotoSansMyanmar-Regular.ttf",
    "Pyidaungsu": FONTS / "pyidaungsu_regular.ttf",
    "Pyidaungsu Bold": FONTS / "pyidaungsu_bold.ttf",
    "A13_WenYoe Regular": FONTS / "A13_WenYoe-Regular.ttf"
}
FONT_FAMILIES = {
    "Noto Sans Myanmar": "Noto Sans Myanmar",
    "Pyidaungsu": "Pyidaungsu Green",
    "Pyidaungsu Bold": "Pyidaungsu Green",
    "A13_WenYoe Regular": "A13_WenYoe Regular"
}

CHUNK_CACHE: dict[str, dict[str, list[Any]]] = {}

def clock(value: float) -> str:
    ms = int(max(0, value) * 1000)
    return f"{ms // 3_600_000:02d}:{(ms // 60_000) % 60:02d}:{(ms // 1000) % 60:02d},{ms % 1000:03d}"

def _run(command: list[str], timeout: int = 1200) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0: raise RuntimeError((result.stderr or "FFmpeg failed")[-1800:])
    return result

def probe_video(path: Path) -> dict[str, Any]:
    try:
        result = _run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,duration:stream_tags=rotate:stream_side_data=rotation", "-of", "json", str(path)], timeout=45)
        stream = (json.loads(result.stdout).get("streams") or [{}])[0]
        width, height = int(stream.get("width") or 0), int(stream.get("height") or 0)
        rotation = 0
        for candidate in [(stream.get("tags") or {}).get("rotate"), *((item or {}).get("rotation") for item in stream.get("side_data_list") or [])]:
            try: rotation = int(float(candidate)) % 360; break
            except (TypeError, ValueError): continue
        if rotation in {90, 270}: width, height = height, width
        duration = float(stream.get("duration") or 0)
        if not duration:
            dur_res = _run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)], timeout=45)
            duration = float(dur_res.stdout.strip() or 0)
            
        has_audio = False
        try:
            a_res = _run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(path)], timeout=15)
            if "audio" in a_res.stdout.lower(): has_audio = True
        except: pass
        
        if width < 2 or height < 2 or duration <= 0: raise ValueError("missing video metadata")
        return {"width": width, "height": height, "duration": duration, "has_audio": has_audio}
    except Exception as exc:
        raise RuntimeError("Video information ကိုမဖတ်နိုင်ပါ။") from exc

def extract_media_fast(video_path: Path, output_dir: Path) -> tuple[Path | None, list[Path]]:
    output_dir.mkdir(parents=True, exist_ok=True)
    audio_path = output_dir / "audio.mp3"
    try: _run(["ffmpeg", "-y", "-i", str(video_path), "-vn", "-ar", "16000", "-ac", "1", "-b:a", "128k", "-preset", "ultrafast", str(audio_path)], timeout=45)
    except Exception: audio_path = None
    return audio_path, []

def _generate_content(api_key: str, parts: list[dict[str, Any]], *, config: dict[str, Any], timeout: int) -> dict[str, Any]:
    for current_model in FALLBACK_TEXT_MODELS:
        try:
            response = requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/{current_model}:generateContent", params={"key": api_key}, json={"contents": [{"role": "user", "parts": parts}], "generationConfig": config}, timeout=(10, timeout))
            if response.ok: return response.json()
            time.sleep(1.0)
        except Exception: time.sleep(1.0)
    raise RuntimeError("AI ဆာဗာများ အားလုံး အလုပ်များနေပါသည်။")

def generate_script(api_key: str, video_path: Path, mime_type: str, language: str, duration_seconds: int, tone: str, recap_type: str, timing_mode: str, progress=None) -> str:
    temp_dir = Path(tempfile.mkdtemp(prefix="fast-scan-"))
    try:
        audio_path, _ = extract_media_fast(video_path, temp_dir)
        parts: list[dict[str, Any]] = []
        if audio_path and audio_path.exists() and audio_path.stat().st_size > 0:
            parts.append({"inlineData": {"mimeType": "audio/mp3", "data": base64.b64encode(audio_path.read_bytes()).decode("utf-8")}})
        
        instruction = (
            "သင်ဟာ Professional Burmese Voice-Over Script Writer တစ်ယောက်ဖြစ်ပါတယ်။\n"
            "ပေးထားတဲ့ Video/Audio ကို English လိုမရေးပါနဲ့ မြန်မာလို ပြန်ရေးပါ။\n"
            f"Tone: {tone}\n"
            "- စကားပြောသံလို သွက်လက်ပြီး နားလည်လွယ်အောင် ရေးပါ\n"
            "- အချိန်အညွှန်း မထည့်ပါ\n"
            "- သဘာဝကျတဲ့ မြန်မာဘာသာ အသုံးအနှုန်းနဲ့ ပြန်ဆိုပါ။ ပြန်ဆိုထားသော မြန်မာစာသား သီးသန့်ကိုသာ ပြန်လည်ပေးပို့ပါ။"
        )
        parts.append({"text": instruction})
        
        res = _generate_content(api_key, parts, config={"temperature": 0.2}, timeout=180)
        text = "\n".join(str(p.get("text") or "") for c in res.get("candidates", []) for p in c.get("content", {}).get("parts", [])).strip()
        text = text.replace("```text", "").replace("```", "").strip()
        if not text: raise RuntimeError("Script မပြန်လာပါ။")
        return text
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

# ဝါကျအလိုက် ဖြတ်တောက်မည့်စနစ် (။ ပုဒ်မ ဖြင့်ဖြတ်သည်)
def get_sentence_chunks(script: str) -> list[str]:
    cleaned = script.replace('\n', '။')
    chunks = [c.strip() + "။" for c in cleaned.split("။") if c.strip()]
    return chunks if chunks else [script]

# ဝါကျအတွင်းရှိ စာတန်းထိုးကို ၁၀ လုံးမှ ၁၅ လုံးကြား ဖြတ်တောက်မည့်စနစ်
def get_display_chunks(text: str) -> list[str]:
    cleaned = text.replace("။", "").strip()
    break_words = ["၊", "ပြီး", "လို့", "တာ", "တယ်", "အောင်", "တော့", "၍", "မို့လို့"]
    chunks = []
    current = ""
    for char in cleaned:
        current += char
        c_len = len(current.replace(" ", ""))
        if c_len >= 10:
            if any(current.strip().endswith(bw) for bw in break_words) or c_len >= 15:
                chunks.append(current.strip())
                current = ""
    if current.strip():
        chunks.append(current.strip())
    return chunks

# Multithreading ဖြင့် အသံများကို ပြိုင်တူထုတ်ယူခြင်း (အလွန်မြန်ဆန်သည်)
def generate_microsoft_tts(script: str, voice: str) -> bytes:
    key = os.getenv("AZURE_SPEECH_KEY", "").strip()
    region = os.getenv("AZURE_SPEECH_REGION", "southeastasia").strip()
    if not key: raise RuntimeError("Microsoft Voice setting မသတ်မှတ်ရသေးပါ။")
    
    sentences = get_sentence_chunks(script)
    selected_voice = MICROSOFT_VOICES.get(voice, DEFAULT_MICROSOFT_VOICE)
    
    def fetch(txt):
        if not txt.strip(): return b""
        ssml = f'<speak version="1.0" xml:lang="my-MM" xmlns="http://www.w3.org/2001/10/synthesis"><voice name="{selected_voice}">{xml_escape(txt)}</voice></speak>'
        try:
            res = requests.post(
                f"https://{region}.tts.speech.microsoft.com/cognitiveservices/v1",
                headers={"Ocp-Apim-Subscription-Key": key, "Content-Type": "application/ssml+xml", "X-Microsoft-OutputFormat": "audio-24khz-48kbitrate-mono-mp3"},
                data=ssml.encode("utf-8"), timeout=(10, 30)
            )
            return res.content if res.ok else b""
        except: return b""

    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        audio_chunks = list(executor.map(fetch, sentences))
        
    script_hash = hashlib.md5(script.encode('utf-8')).hexdigest()
    CHUNK_CACHE[script_hash] = {"texts": sentences, "audios": audio_chunks}
    
    return audio_chunks[0] if audio_chunks else b""

def generate_gemini_tts(script: str, voice: str, api_key: str) -> bytes:
    if not api_key: raise RuntimeError("Gemini API Key မရှိပါ။")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}"
    sentences = get_sentence_chunks(script)
    
    def fetch(txt):
        if not txt.strip(): return b""
        payload = {
            "contents": [{"role": "user", "parts": [{"text": txt}]}],
            "generationConfig": {"responseModalities": ["AUDIO"], "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}}}
        }
        try:
            res = requests.post(url, json=payload, timeout=(10, 30))
            audio_b64 = res.json()["candidates"][0]["content"]["parts"][0]["inlineData"]["data"]
            return base64.b64decode(audio_b64)
        except: return b""
            
    with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
        audio_chunks = list(executor.map(fetch, sentences))
        
    script_hash = hashlib.md5(script.encode('utf-8')).hexdigest()
    CHUNK_CACHE[script_hash] = {"texts": sentences, "audios": audio_chunks}
    
    return audio_chunks[0] if audio_chunks else b""

def get_audio_duration(audio_path: Path) -> float:
    try:
        res = _run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(audio_path)], timeout=15)
        return float(res.stdout.strip() or 0)
    except Exception: return 0.0

def process_audio_speed(input_wav: Path, speed_val: str, output_wav: Path) -> float:
    try: speed_float = float(re.sub(r"[^\d.]", "", str(speed_val)) or 1.0)
    except ValueError: speed_float = 1.0
    
    if speed_float != 1.0:
        _run(["ffmpeg", "-y", "-i", str(input_wav), "-af", f"atempo={speed_float}", str(output_wav)], timeout=60)
    else:
        shutil.copy(input_wav, output_wav)
    return get_audio_duration(output_wav)

def ass_color(value: str, alpha: int = 0) -> str:
    color = re.sub(r"[^0-9a-fA-F]", "", value or "")[-6:].rjust(6, "F")
    return f"&H{max(0, min(255, alpha)):02X}{color[4:6]}{color[2:4]}{color[:2]}"

def fitted_source_rect(source: dict[str, float | int], out_width: int, out_height: int) -> dict[str, int]:
    source_width = max(1, int(source["width"]))
    source_height = max(1, int(source["height"]))
    scale = min(out_width / source_width, out_height / source_height)
    width = max(2, round(source_width * scale))
    height = max(2, round(source_height * scale))
    return {"x": (out_width - width) // 2, "y": (out_height - height) // 2, "width": width, "height": height}

def srt_to_ass(srt: str, settings: dict[str, Any], width: int, height: int, source_rect: dict[str, int] | None = None) -> str:
    scale_factor = (height / 720.0)
    raw_size = float(settings.get("subtitle_size", 20))
    font_size = max(20, min(80, round(raw_size * 1.8 * scale_factor)))
    
    visible = source_rect or {"x": 0, "y": 0, "width": width, "height": height}
    x = int(visible["x"]) + math.floor(int(visible["width"]) * max(0, min(100, int(settings.get("subtitle_x", 50)))) / 100 + 0.5)
    y = int(visible["y"]) + math.floor(int(visible["height"]) * max(0, min(100, int(settings.get("subtitle_y", 82)))) / 100 + 0.5)
    
    mode = str(settings.get("subtitle_background", "Solid background"))
    border_style = 3 if mode == "Solid background" else 1
    opacity = max(0, min(100, int(settings.get("subtitle_opacity", 70))))
    back_alpha = 255 - round(opacity * 255 / 100)
    font = FONT_FAMILIES.get(str(settings.get("subtitle_font", "Noto Sans Myanmar")), "Noto Sans Myanmar")
    
    outline_thickness = 0 if border_style == 3 else 1
    shadow_thickness = 0 if border_style == 3 else 1
    
    header = [
        "[Script Info]", "ScriptType: v4.00+", f"PlayResX: {width}", f"PlayResY: {height}", "",
        "[V4+ Styles]",
        "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding",
        f"Style: Default,{font},{font_size},{ass_color(str(settings.get('subtitle_color', '#FFD166')))},{ass_color(str(settings.get('subtitle_color', '#FFD166')))},{ass_color(str(settings.get('subtitle_outline', '#000000')))},{ass_color(str(settings.get('subtitle_background_color', '#000000')), back_alpha)},-1,0,0,0,100,100,0,0,{border_style},{outline_thickness},{shadow_thickness},2,20,20,20,1",
        "", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text",
    ]
    events: list[str] = []
    
    for block in re.split(r"\n\s*\n", srt.strip()):
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if len(lines) < 3 or "-->" not in lines[1]: continue
        start, end = (piece.strip() for piece in lines[1].split("-->", 1))
        try:
            def convert(value: str) -> str:
                hours, minutes, seconds_ms = value.split(":")
                seconds, milliseconds = seconds_ms.split(",")
                return f"{int(hours)}:{int(minutes):02d}:{int(seconds):02d}.{int(milliseconds) // 10:02d}"
            caption = " ".join(lines[2:]).replace("{", "\\{").replace("}", "\\}")
            events.append(f"Dialogue: 0,{convert(start)},{convert(end)},Default,,0,0,0,,{{\\an5\\pos({x},{y})}}{caption}")
        except ValueError: continue
    return "\n".join(header + events) + "\n"

def render_final(video_path: Path, tts_wav: bytes, settings: dict[str, Any], output_path: Path) -> Path:
    source = probe_video(video_path)
    aspect = str(settings.get("aspect", "9:16"))
    scale = 854
    if aspect == "16:9": out_w, out_h = round(scale * 16 / 9), scale
    elif aspect == "1:1": out_w, out_h = scale, scale
    else: out_w, out_h = scale, round(scale * 16 / 9)
    out_w -= out_w % 2
    out_h -= out_h % 2
    visible_rect = fitted_source_rect(source, out_w, out_h)
    
    temp_paths: list[Path] = []
    
    # -------------------------------------------------------------
    # ဝါကျအလိုက် အသံထုတ်ပြီး SRT တွက်သည့်စနစ် (Hybrid Method)
    # -------------------------------------------------------------
    script_str = str(settings.get("script", ""))
    script_hash = hashlib.md5(script_str.encode('utf-8')).hexdigest()
    cached = CHUNK_CACHE.get(script_hash)
    speed_val = str(settings.get("voiceSpeed", "1.0"))
    
    processed_audio_path = Path(tempfile.mktemp(suffix="_processed.wav"))
    temp_paths.append(processed_audio_path)
    actual_audio_duration = 0.0
    final_srt_text = ""
    
    if cached and len(cached["texts"]) == len(cached["audios"]):
        temp_chunk_dir = Path(tempfile.mkdtemp(prefix="speed_chunks_"))
        temp_paths.append(temp_chunk_dir)
        concat_lines = []
        srt_output = []
        current_time = 0.0
        srt_idx = 1
        
        for idx, (sentence, aud_bytes) in enumerate(zip(cached["texts"], cached["audios"])):
            if not aud_bytes: continue
            raw_p = temp_chunk_dir / f"raw_{idx}.mp3"
            raw_p.write_bytes(aud_bytes)
            proc_p = temp_chunk_dir / f"proc_{idx}.wav"
            
            chunk_dur = process_audio_speed(raw_p, speed_val, proc_p)
            concat_lines.append(f"file '{proc_p.name}'")
            
            display_chunks = get_display_chunks(sentence)
            if display_chunks:
                total_chars = sum(len(c.replace(" ", "")) for c in display_chunks)
                sentence_start = current_time
                for d_chunk in display_chunks:
                    c_len = len(d_chunk.replace(" ", ""))
                    piece_dur = (c_len / total_chars) * chunk_dur if total_chars > 0 else 0
                    end_time = sentence_start + piece_dur
                    srt_output.append(f"{srt_idx}\n{clock(sentence_start)} --> {clock(end_time)}\n{d_chunk}")
                    srt_idx += 1
                    sentence_start = end_time
            current_time += chunk_dur
            
        list_path = temp_chunk_dir / "list.txt"
        list_path.write_text("\n".join(concat_lines))
        _run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(list_path), "-c", "copy", str(processed_audio_path)], timeout=120)
        final_srt_text = "\n\n".join(srt_output)
        actual_audio_duration = current_time
    else:
        # Fallback processing
        raw_p = Path(tempfile.mktemp(suffix=".mp3"))
        raw_p.write_bytes(tts_wav)
        temp_paths.append(raw_p)
        actual_audio_duration = process_audio_speed(raw_p, speed_val, processed_audio_path)
    
    target_dur = actual_audio_duration if actual_audio_duration > 0 else float(source["duration"])
    v_pts_factor = target_dur / float(source["duration"]) if float(source["duration"]) > 0 else 1.0

    video_filters = [f"setpts={v_pts_factor:.4f}*PTS-STARTPTS"]
    if settings.get("mirror"): video_filters.append("hflip")
    
    video_filters.extend([f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:flags=lanczos", f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:color=black"])
    graph = f"[0:v]{','.join(video_filters)}[v0]"
    current_v = "v0"
    
    # -------------------------------------------------------------
    # Blur Coordinate Crash Fix (Invalid chroma_param radius ဖြေရှင်းချက်)
    # -------------------------------------------------------------
    if settings.get("blur_enabled"):
        source_w = max(1, float(source["width"]))
        source_h = max(1, float(source["height"]))
        scale_ratio = min(out_w / source_w, out_h / source_h)
        scaled_w = source_w * scale_ratio
        scaled_h = source_h * scale_ratio
        pad_x = (out_w - scaled_w) / 2
        pad_y = (out_h - scaled_h) / 2

        for idx, mask in enumerate(settings.get("blur_masks", [])):
            bx = max(0, int(float(mask["x"]) * scaled_w + pad_x))
            by = max(0, int(float(mask["y"]) * scaled_h + pad_y))
            bw = max(1, int(float(mask["width"]) * scaled_w))
            bh = max(1, int(float(mask["height"]) * scaled_h))
            
            bw = min(bw, out_w - bx)
            bh = min(bh, out_h - by)
            
            # သင်္ချာနည်းဖြင့် Boxblur Radius ကို အလိုအလျောက် အကြီးဆုံးဖြစ်အောင် ကန့်သတ်ပေးခြင်း
            safe_radius = max(0, min(15, int(min(bw, bh) / 2) - 1))
            
            next_v = f"blur{idx}"
            graph += f";[{current_v}]split=2[bg{idx}][toblur{idx}];[toblur{idx}]crop={bw}:{bh}:{bx}:{by},boxblur={safe_radius}:5[blurred{idx}];[bg{idx}][blurred{idx}]overlay={bx}:{by}[{next_v}]"
            current_v = next_v
        
    if settings.get("subtitles", True):
        srt = str(settings.get("subtitle_srt") or final_srt_text)
        ass_path = Path(tempfile.mktemp(suffix=".ass"))
        ass_path.write_text(srt_to_ass(srt, settings, out_w, out_h, visible_rect), encoding="utf-8", newline="\n")
        temp_paths.append(ass_path)
        font_file = FONT_FILES.get(str(settings.get("subtitle_font")), FONT_FILES["Noto Sans Myanmar"])
        font_dir = Path(tempfile.mkdtemp(prefix="fonts-"))
        shutil.copy2(font_file, font_dir / font_file.name)
        temp_paths.append(font_dir)
        next_v = "vsub"
        graph += f";[{current_v}]ass=filename='{str(ass_path).replace(':', r'\:')}':fontsdir='{str(font_dir).replace(':', r'\:')}'[{next_v}]"
        current_v = next_v

    inputs = ["ffmpeg", "-y", "-i", str(video_path), "-i", str(processed_audio_path)]
    
    a_filters = []
    current_a = "1:a"
    orig_audio = str(settings.get("originalAudio", "Mute"))
    
    if source.get("has_audio") and orig_audio != "Mute":
        vol = "0.15" if orig_audio == "Low" else "0.7"
        a_filters.append(f"[0:a]volume={vol}[orig_a]")
        a_filters.append(f"[1:a][orig_a]amix=inputs=2:duration=first:dropout_transition=2[mixed_a]")
        current_a = "mixed_a"
        
    bgm_path_str = settings.get("music_path")
    if bgm_path_str:
        bgm_path = Path(bgm_path_str)
        if bgm_path.exists():
            inputs.extend(["-i", str(bgm_path)])
            bgm_idx = 2
            bgm_vol = float(settings.get("music_volume", 24)) / 100.0
            a_filters.append(f"[{bgm_idx}:a]volume={bgm_vol}[bgm_a]")
            a_filters.append(f"[{current_a}][bgm_a]amix=inputs=2:duration=first:dropout_transition=2[final_a]")
            current_a = "final_a"

    if a_filters:
        graph += ";" + ";".join(a_filters)
        audio_inputs = f"[{current_a}]"
    else:
        audio_inputs = current_a

    # Preset ကို "ultrafast" သို့ ပြောင်းထားသဖြင့် Render အချိန် ၅ ဆ ပိုမြန်မည်
    command = inputs + [
        "-filter_complex", graph,
        "-map", f"[{current_v}]", "-map", audio_inputs,
        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23", "-pix_fmt", "yuv420p",
        "-r", "30", "-c:a", "aac", "-b:a", "192k", "-t", f"{target_dur:.3f}", 
        "-movflags", "+faststart", str(output_path),
    ]
    
    try:
        _run(command, timeout=1200)
        if not output_path.exists() or output_path.stat().st_size < 1024: raise RuntimeError("Final MP4 မဖန်တီးနိုင်ပါ။")
        return output_path
    finally:
        for path in temp_paths:
            if path.is_dir(): shutil.rmtree(path, ignore_errors=True)
            else: path.unlink(missing_ok=True)
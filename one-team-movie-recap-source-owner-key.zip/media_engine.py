"""Server-side media pipeline for One Team Movie Recap."""

from __future__ import annotations
import base64, io, json, math, os, wave, re, shutil, subprocess, tempfile, time, unicodedata, hashlib
import urllib.parse
from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape as xml_escape
import requests
from PIL import Image, ImageDraw, ImageFont, ImageFilter

ROOT = Path(__file__).resolve().parent
FONTS = ROOT / "fonts"

FALLBACK_TEXT_MODELS = ["gemini-3.7-flash", "gemini-3.6-flash", "gemini-3.5-flash", "gemini-3.1-pro", "gemini-2.5-flash"]
DEFAULT_MICROSOFT_VOICE = "my-MM-NilarNeural"

GEMINI_VOICES = ["Aoede", "Charon", "Fenrir", "Kore", "Leda", "Orus", "Puck", "Zephyr", "Achernar", "Enceladus"]
MICROSOFT_VOICES = {
    "Nilar": "my-MM-NilarNeural", "Thiha": "my-MM-ThihaNeural",
    "Ava": "en-US-AvaMultilingualNeural", "Andrew": "en-US-AndrewMultilingualNeural",
    "Emma": "en-US-EmmaMultilingualNeural", "Brian": "en-US-BrianMultilingualNeural",
    "Vivienne": "fr-FR-VivienneMultilingualNeural", "Remy": "fr-FR-RemyMultilingualNeural",
    "Seraphina": "de-DE-SeraphinaMultilingualNeural", "Florian": "de-DE-FlorianMultilingualNeural",
    "Xiaoxiao": "zh-CN-XiaoxiaoMultilingualNeural", "Giuseppe": "it-IT-GiuseppeMultilingualNeural"
}

FONT_FILES = {
    "Noto Sans Myanmar": FONTS / "NotoSansMyanmar-Regular.ttf",
    "Pyidaungsu": FONTS / "pyidaungsu_regular.ttf",
    "Pyidaungsu Bold": FONTS / "pyidaungsu_bold.ttf",
    "A13_WenYoe Regular": FONTS / "A13_WenYoe-Regular.ttf"
}
FONT_FAMILIES = {
    "Noto Sans Myanmar": "Noto Sans Myanmar",
    "Pyidaungsu": "Pyidaungsu Green",
    "Pyidaungsu Bold": "Pyidaungsu Green",
    "A13_WenYoe Regular": "A13_WenYoe Regular"
}

def _run(command: list[str], timeout: int = 1200) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0: raise RuntimeError((result.stderr or "FFmpeg failed")[-1800:])
    return result

def get_audio_duration(audio_path: Path) -> float:
    try:
        res = _run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(audio_path)], timeout=15)
        return float(res.stdout.strip() or 0.0)
    except:
        return 0.0

def probe_video(path: Path) -> dict[str, Any]:
    try:
        result = _run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,duration:stream_tags=rotate:stream_side_data=rotation", "-of", "json", str(path)], timeout=45)
        stream = (json.loads(result.stdout).get("streams") or [{}])[0]
        width, height = int(stream.get("width") or 0), int(stream.get("height") or 0)
        rotation = 0
        for candidate in [(stream.get("tags") or {}).get("rotate"), *((item or {}).get("rotation") for item in stream.get("side_data_list") or [])]:
            try: rotation = int(float(candidate)) % 360; break
            except (TypeError, ValueError): continue
        if rotation in {90, 270}: width, height = height, width
        duration = float(stream.get("duration") or 0)
        if not duration:
            dur_res = _run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)], timeout=45)
            duration = float(dur_res.stdout.strip() or 0)
            
        has_audio = False
        try:
            a_res = _run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(path)], timeout=15)
            if "audio" in a_res.stdout.lower(): has_audio = True
        except: pass
        
        if width < 2 or height < 2 or duration <= 0: raise ValueError("missing video metadata")
        return {"width": width, "height": height, "duration": duration, "has_audio": has_audio}
    except Exception as exc:
        raise RuntimeError("Video information ကိုမဖတ်နိုင်ပါ။") from exc

# --- AI အတွက် Video ထဲမှ ပုံရိပ်များ ခွဲထုတ်သည့်စနစ် (Vision Extraction) ---
def extract_frames(video_path: Path, output_dir: Path, num_frames: int = 8) -> list[Path]:
    try: dur = probe_video(video_path).get("duration", 0)
    except: dur = 0
    if dur <= 0: return []
    interval = max(1.0, dur / (num_frames + 1))
    frames = []
    for i in range(1, num_frames + 1):
        t = i * interval
        out = output_dir / f"frame_{i}.jpg"
        try:
            _run(["ffmpeg", "-y", "-ss", str(t), "-i", str(video_path), "-vframes", "1", "-q:v", "2", "-s", "640x360", str(out)], timeout=15)
            if out.exists() and out.stat().st_size > 0: frames.append(out)
        except: pass
    return frames

def extract_media_fast(video_path: Path, output_dir: Path) -> tuple[Path | None, list[Path]]:
    output_dir.mkdir(parents=True, exist_ok=True)
    audio_path = output_dir / "audio.mp3"
    try: _run(["ffmpeg", "-y", "-i", str(video_path), "-vn", "-ar", "16000", "-ac", "1", "-b:a", "128k", str(audio_path)], timeout=45)
    except Exception: audio_path = None
    return audio_path, []

def _generate_content(api_key: str, parts: list[dict[str, Any]], *, config: dict[str, Any], timeout: int) -> dict[str, Any]:
    for current_model in FALLBACK_TEXT_MODELS:
        try:
            response = requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/{current_model}:generateContent", params={"key": api_key}, json={"contents": [{"role": "user", "parts": parts}], "generationConfig": config}, timeout=(10, timeout))
            if response.ok: return response.json()
            time.sleep(1.0)
        except Exception: time.sleep(1.0)
    raise RuntimeError("AI ဆာဗာများ အားလုံး အလုပ်များနေပါသည်။")

def generate_script(api_key: str, video_path: Path, mime_type: str, language: str, duration_seconds: int, tone: str, recap_type: str, timing_mode: str, progress=None) -> str:
    temp_dir = Path(tempfile.mkdtemp(prefix="fast-scan-"))
    try:
        # ၁။ အသံခွဲထုတ်ခြင်း
        audio_path, _ = extract_media_fast(video_path, temp_dir)
        has_audio = audio_path and audio_path.exists() and audio_path.stat().st_size > 1024
        
        # ၂။ ပုံရိပ်များခွဲထုတ်ခြင်း (AI Vision အတွက်)
        frames = extract_frames(video_path, temp_dir, num_frames=8)
        
        parts: list[dict[str, Any]] = []
        
        # Video Frames ထည့်သွင်းခြင်း
        for f in frames:
            parts.append({"inlineData": {"mimeType": "image/jpeg", "data": base64.b64encode(f.read_bytes()).decode("utf-8")}})
            
        # Audio ထည့်သွင်းခြင်း
        if has_audio:
            parts.append({"inlineData": {"mimeType": "audio/mp3", "data": base64.b64encode(audio_path.read_bytes()).decode("utf-8")}})
        
        # ၃။ Recap အမျိုးအစားအလိုက် Prompt သတ်မှတ်ခြင်း (Dynamic Auto-Mode)
        if recap_type == "Simple Movie" and has_audio:
            instruction = (
                f"You are an expert AI dubbing translator. Listen to the audio and translate the exact spoken dialogue into {language}. "
                f"Tone: {tone}. Video duration: {duration_seconds} seconds. "
                "CRITICAL RULES: "
                "1. Keep the exact meaning of the spoken words. Do not add any extra storytelling. "
                "2. If there is NO speech (silent or only music), return an empty string. "
                "3. Return ONLY the translated spoken text."
            )
        elif not has_audio or recap_type == "Silent Recap":
            instruction = (
                f"You are a master storyteller. The provided video has no dialogue. Look at the visual frames to understand the actions, emotions, and environment. "
                f"Create a highly engaging, descriptive narrative story in {language} based on what you see. "
                f"Tone: {tone}. Video duration: {duration_seconds} seconds. "
                "CRITICAL RULES: Return ONLY the narrative spoken text."
            )
        else:
            instruction = (
                f"You are a professional movie recapper. Look at the visual frames AND listen to the audio. "
                f"Translate the dialogue naturally AND describe the actions contextually like a flowing story in {language}. "
                f"Tone: {tone}. Video duration: {duration_seconds} seconds. "
                "CRITICAL RULES: Ensure the script fits this duration perfectly. Return ONLY the spoken text, without any formatting."
            )

        parts.append({"text": instruction})
        
        res = _generate_content(api_key, parts, config={"temperature": 0.3}, timeout=180)
        text = "\n".join(str(p.get("text") or "") for c in res.get("candidates", []) for p in c.get("content", {}).get("parts", [])).strip()
        if not text: raise RuntimeError("Script မပြန်လာပါ။")
        return text
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

# -------------------------------------------------------------------------------------
# MASTER PROMPT ဖြင့် ကာဘာပုံ အလိုအလျောက် ဆွဲထုတ်သည့်စနစ် 
# -------------------------------------------------------------------------------------
def generate_thumbnail(script: str, api_key: str, output_path: Path) -> Path | None:
    try:
        parts = []
        instruction = f"Generate a short viral Burmese hook (max 4 words) for this video recap script. Context: {script[:500]}"
        parts.append({"text": instruction})
        
        hook_text = "ဘာဖြစ်သွားတာလဲ?"
        try:
            res = _generate_content(api_key, parts, config={"temperature": 0.7}, timeout=60)
            text_res = "\n".join(str(p.get("text") or "") for c in res.get("candidates", []) for p in c.get("content", {}).get("parts", [])).strip()
            if text_res: hook_text = text_res[:25]
        except: pass
        
        master_prompt = f"""Create a viral cinematic YouTube thumbnail based on the following movie scene: {script[:500]}

Main Subject:
Keep the main focus on a central character from the scene. Enhance facial details, sharp eyes, emotional expression, realistic skin texture, dramatic lighting, ultra HD quality.

Background:
Create a dramatic Korean drama/movie style background related to the title. Add depth, cinematic atmosphere, realistic environment, emotional storytelling, bokeh lights, volumetric lighting.

Composition:
Place the main character large in the foreground.
Add supporting characters or important scene elements in the background.
Create tension and curiosity.

Thumbnail Effects:
Red arrows pointing to important clues. Red circle highlighting key evidence or hidden detail. Glow effects around important objects. High contrast and vibrant colors. Professional YouTube thumbnail style.

Text: Add large Burmese title: "{hook_text}"
Typography: Bold Burmese font. Yellow, white and cyan text colors. Black shadow and thick outline. Easy to read on mobile.
Style: Korean drama thumbnail, viral Facebook reel cover, clickable thumbnail, cinematic movie poster, hyper realistic, 8K quality, dramatic storytelling, high engagement, professional news recap style. Aspect Ratio: 3:4 vertical thumbnail."""

        try:
            imagen_url = f"https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-fast-generate-001:predict?key={api_key}"
            imagen_payload = {"instances": [{"prompt": master_prompt}], "parameters": {"sampleCount": 1, "aspectRatio": "3:4"}}
            img_res = requests.post(imagen_url, json=imagen_payload, timeout=60)
            if img_res.ok:
                img_b64 = img_res.json()["predictions"][0]["bytesBase64Encoded"]
                with open(output_path, "wb") as f: f.write(base64.b64decode(img_b64))
                return output_path
        except: pass
            
        return None
    except Exception as e:
        print("Thumbnail generation failed:", e)
        return None

def generate_microsoft_tts(script: str, voice: str) -> bytes:
    key = os.getenv("AZURE_SPEECH_KEY", "").strip()
    region = os.getenv("AZURE_SPEECH_REGION", "southeastasia").strip()
    if not key: raise RuntimeError("Microsoft Voice setting မသတ်မှတ်ရသေးပါ။")
    
    selected_voice = MICROSOFT_VOICES.get(voice, DEFAULT_MICROSOFT_VOICE)
    ssml = f'<speak version="1.0" xml:lang="my-MM" xmlns="http://www.w3.org/2001/10/synthesis"><voice name="{selected_voice}"><prosody rate="+0%">{xml_escape(script)}</prosody></voice></speak>'
    
    try: import azure.cognitiveservices.speech as speechsdk
    except ImportError: raise RuntimeError("azure-cognitiveservices-speech package ကို requirements.txt တွင် မတွေ့ပါ။")

    speech_config = speechsdk.SpeechConfig(subscription=key, region=region)
    speech_config.set_speech_synthesis_output_format(speechsdk.SpeechSynthesisOutputFormat.Audio24Khz48KBitRateMonoMp3)
    
    stream = speechsdk.audio.PullAudioOutputStream()
    audio_config = speechsdk.audio.AudioOutputConfig(stream=stream)
    synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
    
    word_boundaries = []
    def word_boundary_cb(evt):
        dur = evt.duration
        dur_ms = dur.total_seconds() * 1000 if hasattr(dur, 'total_seconds') else float(dur) / 10000
        word_boundaries.append({"word": evt.text, "offset_ms": evt.audio_offset / 10000, "duration_ms": dur_ms})
        
    synthesizer.synthesis_word_boundary.connect(word_boundary_cb)
    result = synthesizer.speak_ssml_async(ssml).get()
    
    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        if not word_boundaries: raise RuntimeError("Microsoft ဆာဗာမှ ဤစကားလုံးများအတွက် အချိန်အတိအကျ ပြန်လည်မပေးပို့ပါ။")
            
        srt_lines = []
        break_words = ["။", "၊", "သောအခါ", "အောင်", "၍", "ပြီး", "လို့", "သောကြောင့်", "မို့လို့", "သည်", "ပါ", "တယ်", "မယ်"]
        chunks, current_chunk = [], []
        for w_info in word_boundaries:
            current_chunk.append(w_info)
            text_so_far = " ".join([w["word"] for w in current_chunk])
            char_count = len(text_so_far.replace(" ", ""))
            if (char_count >= 10 and any(text_so_far.strip().endswith(bw) for bw in break_words)) or char_count > 18:
                chunks.append(current_chunk)
                current_chunk = []
        if current_chunk: chunks.append(current_chunk)
            
        def clock(ms: float) -> str:
            ms = int(max(0, ms))
            return f"{ms // 3_600_000:02d}:{(ms // 60_000) % 60:02d}:{(ms // 1000) % 60:02d},{ms % 1000:03d}"
            
        for idx, chunk in enumerate(chunks):
            start_ms = chunk[0]["offset_ms"]
            end_ms = chunk[-1]["offset_ms"] + chunk[-1]["duration_ms"]
            text = " ".join([w["word"] for w in chunk])
            adjusted_end = end_ms - 50 if end_ms - start_ms > 200 else end_ms
            srt_lines.append(f"{idx + 1}\n{clock(start_ms)} --> {clock(adjusted_end)}\n{text.strip()}")
            
        CACHE_DIR = Path(tempfile.gettempdir()) / "srt_cache"
        CACHE_DIR.mkdir(exist_ok=True)
        h = hashlib.md5(script.encode('utf-8')).hexdigest()
        (CACHE_DIR / f"{h}.srt").write_text("\n\n".join(srt_lines), encoding="utf-8")
        
        return result.audio_data
    else: raise RuntimeError(f"Microsoft Voice ဆာဗာ ချို့ယွင်းနေပါသည်။: {result.reason}")

def generate_gemini_tts(script: str, voice: str, api_key: str) -> bytes:
    if not api_key: raise RuntimeError("Gemini API Key မရှိပါ။")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}"
    payload = {"contents": [{"role": "user", "parts": [{"text": script}]}], "generationConfig": {"responseModalities": ["AUDIO"], "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}}}}
    response = requests.post(url, json=payload, timeout=(10, 80))
    if not response.ok: raise RuntimeError(f"Gemini Voice Error: {response.status_code}")
    try: return base64.b64decode(response.json()["candidates"][0]["content"]["parts"][0]["inlineData"]["data"])
    except Exception as e: raise RuntimeError("Gemini မှ အသံဖိုင်ပြန်မလာပါ။") from e

def make_srt(script: str, duration: float) -> str:
    cleaned = script.strip()
    if not cleaned: return ""

    h = hashlib.md5(script.encode('utf-8')).hexdigest()
    cache_file = Path(tempfile.gettempdir()) / "srt_cache" / f"{h}.srt"
    if cache_file.exists(): return cache_file.read_text(encoding="utf-8")
    
    words = cleaned.replace('\n', ' ').split(' ')
    chunks, current_chunk = [], ""
    break_words = ["။", "၊", "သောအခါ", "အောင်", "၍", "ပြီး", "လို့", "သောကြောင့်", "မို့လို့", "သည်", "ပါ", "တယ်", "မယ်"]
    
    for word in words:
        if not word.strip(): continue
        current_chunk += word + " "
        char_count = len(current_chunk.replace(" ", ""))
        if (char_count >= 10 and any(current_chunk.strip().endswith(bw) for bw in break_words)) or char_count > 18:
            chunks.append(current_chunk.strip())
            current_chunk = ""
    if current_chunk.strip(): chunks.append(current_chunk.strip())

    total_weight = sum([len(c.replace(" ", "")) * 1.5 + (20 if c.endswith("။") else 10 if c.endswith("၊") else 0) for c in chunks])
    if total_weight == 0: return ""

    def clock(value: float) -> str:
        ms = int(max(0, value) * 1000)
        return f"{ms // 3_600_000:02d}:{(ms // 60_000) % 60:02d}:{(ms // 1000) % 60:02d},{ms % 1000:03d}"

    srt_output, current_time = [], 0.0
    for index, (line, weight) in enumerate(zip(chunks, [len(c.replace(" ", "")) * 1.5 + (20 if c.endswith("။") else 10 if c.endswith("၊") else 0) for c in chunks])):
        piece_duration = (weight / total_weight) * duration
        end_time = current_time + piece_duration
        adjusted_end = end_time - 0.05 if end_time - current_time > 0.2 else end_time
        srt_output.append(f"{index + 1}\n{clock(current_time)} --> {clock(adjusted_end)}\n{line.strip()}")
        current_time = end_time
    return "\n\n".join(srt_output)

def ass_color(value: str, alpha: int = 0) -> str:
    color = re.sub(r"[^0-9a-fA-F]", "", value or "")[-6:].rjust(6, "F")
    return f"&H{max(0, min(255, alpha)):02X}{color[4:6]}{color[2:4]}{color[:2]}"

def fitted_source_rect(source: dict[str, float | int], out_width: int, out_height: int) -> dict[str, int]:
    scale = min(out_width / max(1, int(source["width"])), out_height / max(1, int(source["height"])))
    w, h = max(2, round(max(1, int(source["width"])) * scale)), max(2, round(max(1, int(source["height"])) * scale))
    return {"x": (out_width - w) // 2, "y": (out_height - h) // 2, "width": w, "height": h}

def srt_to_ass(srt: str, settings: dict[str, Any], width: int, height: int, source_rect: dict[str, int] | None = None, speed_factor: float = 1.0) -> str:
    scale_factor = (height / 720.0)
    font_size = max(20, min(80, round(float(settings.get("subtitle_size", 20)) * 1.8 * scale_factor)))
    visible = source_rect or {"x": 0, "y": 0, "width": width, "height": height}
    x = int(visible["x"]) + math.floor(int(visible["width"]) * max(0, min(100, int(settings.get("subtitle_x", 50)))) / 100 + 0.5)
    y = int(visible["y"]) + math.floor(int(visible["height"]) * max(0, min(100, int(settings.get("subtitle_y", 82)))) / 100 + 0.5)
    
    solid_bg = str(settings.get("subtitle_background", "solid")).strip().lower() in {"solid", "solid background"}
    back_alpha = 255 - round(max(0, min(100, int(settings.get("subtitle_opacity", 70)))) * 255 / 100)
    font = FONT_FAMILIES.get(str(settings.get("subtitle_font", "Noto Sans Myanmar")), "Noto Sans Myanmar")
    
    outline_c, primary_c, bg_c = ass_color(str(settings.get('subtitle_outline', '#000000'))), ass_color(str(settings.get('subtitle_color', '#FFD166'))), ass_color(str(settings.get('subtitle_background_color', '#000000')), back_alpha)
    
    header = ["[Script Info]", "ScriptType: v4.00+", f"PlayResX: {width}", f"PlayResY: {height}", "", "[V4+ Styles]", "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding"]
    
    if solid_bg:
        header.append(f"Style: BoxStyle,{font},{font_size},&HFF000000,&HFF000000,{bg_c},{bg_c},-1,0,0,0,100,100,0,0,3,3,0,2,20,20,20,1")
    header.append(f"Style: TextStyle,{font},{font_size},{primary_c},{primary_c},{outline_c},&H00000000,-1,0,0,0,100,100,0,0,1,3,2,2,20,20,20,1")
    header.extend(["", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text"])
    
    events = []
    for block in re.split(r"\n\s*\n", srt.strip()):
        lines = [l.strip() for l in block.splitlines() if l.strip()]
        if len(lines) < 3 or "-->" not in lines[1]: continue
        start, end = (p.strip() for p in lines[1].split("-->", 1))
        try:
            def convert(value: str) -> str:
                h, m, s_ms = value.split(":")
                s, ms = s_ms.split(",")
                new_ms = int((int(h)*3600000 + int(m)*60000 + int(s)*1000 + int(ms)) / speed_factor)
                return f"{new_ms // 3600000}:{(new_ms // 60000) % 60:02d}:{(new_ms // 1000) % 60:02d}.{(new_ms % 1000) // 10:02d}"
            caption = " ".join(lines[2:]).replace("{", "\\{").replace("}", "\\}")
            if solid_bg: events.append(f"Dialogue: 0,{convert(start)},{convert(end)},BoxStyle,,0,0,0,,{{\\an5\\pos({x},{y})}}{caption}")
            events.append(f"Dialogue: 1,{convert(start)},{convert(end)},TextStyle,,0,0,0,,{{\\an5\\pos({x},{y})}}{caption}")
        except ValueError: continue
    return "\n".join(header + events) + "\n"

def create_text_image(text: str, font_path: Path, output_path: Path, font_size: int):
    try: font = ImageFont.truetype(str(font_path), font_size)
    except: font = ImageFont.load_default()
    dummy = Image.new("RGBA", (1, 1), (0, 0, 0, 0))
    bbox = ImageDraw.Draw(dummy).textbbox((0, 0), text, font=font)
    img = Image.new("RGBA", (bbox[2] - bbox[0] + 20, bbox[3] - bbox[1] + 20), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    stroke = max(1, int(font_size * 0.05))
    for dx in range(-stroke, stroke+1):
        for dy in range(-stroke, stroke+1):
            draw.text((10+dx, 10+dy), text, font=font, fill="black")
    draw.text((10, 10), text, font=font, fill="white")
    img.save(output_path, "PNG")

def render_final(video_path: Path, tts_wav: bytes, settings: dict[str, Any], output_path: Path) -> Path:
    source = probe_video(video_path)
    aspect = str(settings.get("aspect", "9:16"))
    scale = 854
    out_w, out_h = (round(scale * 16 / 9), scale) if aspect == "16:9" else (scale, scale) if aspect == "1:1" else (scale, round(scale * 16 / 9))
    out_w -= out_w % 2; out_h -= out_h % 2
    visible_rect = fitted_source_rect(source, out_w, out_h)
    
    temp_paths = []
    raw_audio_path = Path(tempfile.mktemp(suffix=".mp3"))
    raw_audio_path.write_bytes(tts_wav)
    temp_paths.append(raw_audio_path)
    
    raw_tts_dur = get_audio_duration(raw_audio_path)
    vid_duration = float(source["duration"])
    if raw_tts_dur <= 0: raw_tts_dur = vid_duration
    
    # --- ရုပ်နှင့်အသံ အတိုအရှည် အလိုအလျောက် ချိန်ညှိသည့်စနစ် (Auto Video Time-Stretch) ---
    speed_float = float(settings.get("speed") or settings.get("videoSpeed") or 1.0)
    
    # Recap အမျိုးအစားမရွေး မြန်မာအသံကြာချိန် (TTS Duration) အတိုင်း Video ကို ဆွဲဆန့်/ကျုံ့ ခြင်း
    target_dur = raw_tts_dur / speed_float if speed_float > 0 else raw_tts_dur
    v_pts_factor = target_dur / vid_duration if vid_duration > 0 else 1.0

    video_filters = [f"setpts={v_pts_factor:.4f}*PTS-STARTPTS", "fps=30"]
    if settings.get("mirror"): video_filters.append("hflip")
    if settings.get("zoom_enabled"): video_filters.append("crop=iw*0.96:ih*0.96")
    if settings.get("color_effect"): video_filters.append("eq=brightness=0.02:saturation=1.15:contrast=1.05")
    video_filters.append("unsharp=5:5:0.8:3:3:0.4")
    video_filters.extend([f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:flags=lanczos", f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:color=black"])
    
    graph = f"[0:v]{','.join(video_filters)}[v0]"
    current_v = "v0"
    
    if settings.get("blur_enabled"):
        raw_b = int(settings.get("blur_strength", 10))
        luma_r, chroma_r = max(1, min(20, raw_b)), max(1, min(14, raw_b // 2 if raw_b > 2 else 1))
        for idx, mask in enumerate(settings.get("blur_masks", [])):
            vx, vy, vw, vh = visible_rect["x"], visible_rect["y"], visible_rect["width"], visible_rect["height"]
            bx, by = max(1, vx + int(float(mask["x"]) * vw)), max(1, vy + int(float(mask["y"]) * vh))
            bw, bh = max(1, min(int(float(mask["width"]) * vw), out_w - bx - 1)), max(1, min(int(float(mask["height"]) * vh), out_h - by - 1))
            next_v = f"blur{idx}"
            graph += f";[{current_v}]split=2[bg{idx}][toblur{idx}];[toblur{idx}]crop={bw}:{bh}:{bx}:{by},boxblur={luma_r}:{chroma_r}[blurred{idx}];[bg{idx}][blurred{idx}]overlay={bx}:{by}[{next_v}]"
            current_v = next_v

    inputs = ["ffmpeg", "-y", "-i", str(video_path), "-i", str(raw_audio_path)]

    if settings.get("logo_enabled", True):
        logo_str, logo_text = settings.get("logo_path") or settings.get("watermark_path"), str(settings.get("logo_text", "")).strip()
        lx_pct, ly_pct, l_size = max(0, min(100, int(settings.get("logo_x", 84)))) / 100.0, max(0, min(100, int(settings.get("logo_y", 86)))) / 100.0, max(10, min(100, int(settings.get("logo_size", 22)))) / 100.0
        target_w = int(out_w * l_size)

        if logo_str and Path(str(logo_str)).exists():
            inputs.extend(["-i", str(logo_str)])
            next_v = "vlogo"
            graph += f";[{inputs.count('-i') - 1}:v]scale={target_w}:-1[wm];[{current_v}][wm]overlay=W*{lx_pct}-w/2:H*{ly_pct}-h/2[{next_v}]"
            current_v = next_v
        elif logo_text:
            text_img_path = Path(tempfile.mktemp(suffix=".png"))
            create_text_image(logo_text, FONT_FILES.get(str(settings.get("subtitle_font", "Noto Sans Myanmar")), FONT_FILES["Noto Sans Myanmar"]), text_img_path, int(out_h * l_size * 0.3))
            temp_paths.append(text_img_path)
            inputs.extend(["-i", str(text_img_path)])
            next_v = "vlogo"
            graph += f";[{current_v}][{inputs.count('-i') - 1}:v]overlay=W*{lx_pct}-w/2:H*{ly_pct}-h/2[{next_v}]"
            current_v = next_v
        
    if settings.get("subtitles", True):
        srt = str(settings.get("subtitle_srt") or make_srt(str(settings.get("script") or ""), raw_tts_dur))
        ass_path = Path(tempfile.mktemp(suffix=".ass"))
        ass_path.write_text(srt_to_ass(srt, settings, out_w, out_h, visible_rect, speed_float), encoding="utf-8", newline="\n")
        temp_paths.append(ass_path)
        font_dir = Path(tempfile.mkdtemp(prefix="fonts-"))
        shutil.copy2(FONT_FILES.get(str(settings.get("subtitle_font")), FONT_FILES["Noto Sans Myanmar"]), font_dir)
        temp_paths.append(font_dir)
        next_v = "vsub"
        graph += f";[{current_v}]ass=filename='{str(ass_path).replace(':', r'\:')}':fontsdir='{str(font_dir).replace(':', r'\:')}'[{next_v}]"
        current_v = next_v
    
    current_a_mix = "1:a" 
    a_filters = []
    
    if speed_float != 1.0:
        a_filters.append(f"[{current_a_mix}]atempo={speed_float}[tts_speed]")
        current_a_mix = "tts_speed"

    orig_audio = str(settings.get("originalAudio", "Mute"))
    if not orig_audio: orig_audio = str(settings.get("original_audio", "Mute"))
    has_orig = source.get("has_audio") and orig_audio != "Mute"
    
    if has_orig:
        vol = "0.15" if orig_audio == "Low" else "0.7"
        t, tempo_filters = vid_duration / target_dur if target_dur > 0 else 1.0, []
        while t < 0.5: tempo_filters.append("atempo=0.5"); t /= 0.5
        while t > 2.0: tempo_filters.append("atempo=2.0"); t /= 2.0
        tempo_filters.append(f"atempo={t:.4f}")
        
        a_filters.append(f"[0:a]volume={vol},{','.join(tempo_filters)}[orig_a]")
        in_a = current_a_mix if ":" in current_a_mix else f"[{current_a_mix}]"
        a_filters.append(f"{in_a}[orig_a]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[mixed_1]")
        current_a_mix = "mixed_1"
        
    bgm_path_str = settings.get("music_path")
    if bool(bgm_path_str) and Path(str(bgm_path_str)).exists() and orig_audio != "Normal":
        inputs.extend(["-stream_loop", "-1", "-i", str(bgm_path_str)])
        a_filters.append(f"[{inputs.count('-i') - 1}:a]volume={float(settings.get('music_volume', 24)) / 100.0}[bgm_a]")
        in_a = current_a_mix if ":" in current_a_mix else f"[{current_a_mix}]"
        a_filters.append(f"{in_a}[bgm_a]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[mixed_2]")
        current_a_mix = "mixed_2"

    if a_filters: graph += ";" + ";".join(a_filters)

    command = inputs + [
        "-filter_complex", graph,
        "-map", f"[{current_v}]", "-map", current_a_mix if ":" in current_a_mix else f"[{current_a_mix}]",
        "-c:v", "libx264", "-preset", "faster", "-crf", "26", "-pix_fmt", "yuv420p", "-r", "30", 
        "-c:a", "aac", "-b:a", "128k", "-t", f"{target_dur:.3f}", "-movflags", "+faststart", str(output_path),
    ]
    
    try:
        _run(command, timeout=2400)
        if not output_path.exists() or output_path.stat().st_size < 1024: raise RuntimeError("Final MP4 မဖန်တီးနိုင်ပါ။")
        return output_path
    finally:
        for p in temp_paths: (shutil.rmtree(p, ignore_errors=True) if p.is_dir() else p.unlink(missing_ok=True))
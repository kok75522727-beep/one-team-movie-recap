"""Server-side media pipeline for One Team Movie Recap."""

from __future__ import annotations
import base64, io, json, math, os, wave, re, shutil, subprocess, tempfile, time, unicodedata, hashlib
from pathlib import Path
from typing import Any
from xml.sax.saxutils import escape as xml_escape
import requests

ROOT = Path(__file__).resolve().parent
FONTS = ROOT / "fonts"

FALLBACK_TEXT_MODELS = ["gemini-3.7-flash", "gemini-3.6-flash", "gemini-3.5-flash", "gemini-3.1-pro", "gemini-2.5-flash"]
DEFAULT_MICROSOFT_VOICE = "my-MM-NilarNeural"

GEMINI_VOICES = ["Aoede", "Charon", "Fenrir", "Kore", "Leda", "Orus", "Puck", "Zephyr", "Achernar", "Enceladus"]
MICROSOFT_VOICES = {
    "Nilar": "my-MM-NilarNeural", "Thiha": "my-MM-ThihaNeural",
    "Ava": "en-US-AvaMultilingualNeural", "Andrew": "en-US-AndrewMultilingualNeural",
    "Emma": "en-US-EmmaMultilingualNeural", "Brian": "en-US-BrianMultilingualNeural",
    "Vivienne": "fr-FR-VivienneMultilingualNeural", "Remy": "fr-FR-RemyMultilingualNeural",
    "Seraphina": "de-DE-SeraphinaMultilingualNeural", "Florian": "de-DE-FlorianMultilingualNeural",
    "Xiaoxiao": "zh-CN-XiaoxiaoMultilingualNeural", "Giuseppe": "it-IT-GiuseppeMultilingualNeural"
}

FONT_FILES = {
    "Noto Sans Myanmar": FONTS / "NotoSansMyanmar-Regular.ttf",
    "Pyidaungsu": FONTS / "pyidaungsu_regular.ttf",
    "Pyidaungsu Bold": FONTS / "pyidaungsu_bold.ttf",
    "A13_WenYoe Regular": FONTS / "A13_WenYoe-Regular.ttf"
}
FONT_FAMILIES = {
    "Noto Sans Myanmar": "Noto Sans Myanmar",
    "Pyidaungsu": "Pyidaungsu Green",
    "Pyidaungsu Bold": "Pyidaungsu Green",
    "A13_WenYoe Regular": "A13_WenYoe Regular"
}

def _run(command: list[str], timeout: int = 1200) -> subprocess.CompletedProcess[str]:
    result = subprocess.run(command, capture_output=True, text=True, timeout=timeout)
    if result.returncode != 0: raise RuntimeError((result.stderr or "FFmpeg failed")[-1800:])
    return result

def probe_video(path: Path) -> dict[str, Any]:
    try:
        result = _run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,duration:stream_tags=rotate:stream_side_data=rotation", "-of", "json", str(path)], timeout=45)
        stream = (json.loads(result.stdout).get("streams") or [{}])[0]
        width, height = int(stream.get("width") or 0), int(stream.get("height") or 0)
        rotation = 0
        for candidate in [(stream.get("tags") or {}).get("rotate"), *((item or {}).get("rotation") for item in stream.get("side_data_list") or [])]:
            try: rotation = int(float(candidate)) % 360; break
            except (TypeError, ValueError): continue
        if rotation in {90, 270}: width, height = height, width
        duration = float(stream.get("duration") or 0)
        if not duration:
            dur_res = _run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)], timeout=45)
            duration = float(dur_res.stdout.strip() or 0)
            
        has_audio = False
        try:
            a_res = _run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=codec_type", "-of", "csv=p=0", str(path)], timeout=15)
            if "audio" in a_res.stdout.lower(): has_audio = True
        except: pass
        
        if width < 2 or height < 2 or duration <= 0: raise ValueError("missing video metadata")
        return {"width": width, "height": height, "duration": duration, "has_audio": has_audio}
    except Exception as exc:
        raise RuntimeError("Video information ကိုမဖတ်နိုင်ပါ။") from exc

def extract_media_fast(video_path: Path, output_dir: Path) -> tuple[Path | None, list[Path]]:
    output_dir.mkdir(parents=True, exist_ok=True)
    audio_path = output_dir / "audio.mp3"
    try: _run(["ffmpeg", "-y", "-i", str(video_path), "-vn", "-ar", "16000", "-ac", "1", "-b:a", "128k", str(audio_path)], timeout=45)
    except Exception: audio_path = None
    return audio_path, []

def _generate_content(api_key: str, parts: list[dict[str, Any]], *, config: dict[str, Any], timeout: int) -> dict[str, Any]:
    for current_model in FALLBACK_TEXT_MODELS:
        try:
            response = requests.post(f"https://generativelanguage.googleapis.com/v1beta/models/{current_model}:generateContent", params={"key": api_key}, json={"contents": [{"role": "user", "parts": parts}], "generationConfig": config}, timeout=(10, timeout))
            if response.ok: return response.json()
            time.sleep(1.0)
        except Exception: time.sleep(1.0)
    raise RuntimeError("AI ဆာဗာများ အားလုံး အလုပ်များနေပါသည်။")

def generate_script(api_key: str, video_path: Path, mime_type: str, language: str, duration_seconds: int, tone: str, recap_type: str, timing_mode: str, progress=None) -> str:
    temp_dir = Path(tempfile.mkdtemp(prefix="fast-scan-"))
    try:
        audio_path, _ = extract_media_fast(video_path, temp_dir)
        parts: list[dict[str, Any]] = []
        if audio_path and audio_path.exists() and audio_path.stat().st_size > 0:
            parts.append({"inlineData": {"mimeType": "audio/mp3", "data": base64.b64encode(audio_path.read_bytes()).decode("utf-8")}})
        
        if recap_type == "Simple Movie":
            instruction = (
                f"You are an expert dubbing scriptwriter. Translate and adapt the dialogue into {language} to match the original acting and timing. "
                f"Tone: {tone}. "
                "CRITICAL RULES: "
                "1. Keep the exact meaning and dialogue accurately. "
                f"2. The video duration is {duration_seconds} seconds. Ensure the spoken text fits perfectly within this time frame. "
                "3. Return ONLY the spoken text, without any formatting."
            )
        else:
            instruction = (
                f"You are a professional movie recapper and storyteller. Translate the following video audio into {language}. "
                f"Tone: {tone}. "
                "CRITICAL RULES: "
                "1. Translate the complete meaning naturally, like a flowing storytelling narrative, not a rigid word-for-word translation. "
                f"2. The video duration is {duration_seconds} seconds. Ensure the total script length fits this duration naturally. "
                "3. Return ONLY the spoken text, without any formatting."
            )

        parts.append({"text": instruction})
        
        res = _generate_content(api_key, parts, config={"temperature": 0.3}, timeout=180)
        text = "\n".join(str(p.get("text") or "") for c in res.get("candidates", []) for p in c.get("content", {}).get("parts", [])).strip()
        if not text: raise RuntimeError("Script မပြန်လာပါ။")
        return text
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)

def generate_microsoft_tts(script: str, voice: str) -> bytes:
    key = os.getenv("AZURE_SPEECH_KEY", "").strip()
    region = os.getenv("AZURE_SPEECH_REGION", "southeastasia").strip()
    if not key: raise RuntimeError("Microsoft Voice setting မသတ်မှတ်ရသေးပါ။")
    
    selected_voice = MICROSOFT_VOICES.get(voice, DEFAULT_MICROSOFT_VOICE)
    # Speed အမြန်နှုန်း ပြောင်းလဲခြင်း မလုပ်ဘဲ 1.0x (Normal) ဖြင့်သာ တောင်းယူမည်။ (သင်္ချာနည်းမလိုတော့ပါ)
    ssml = f'<speak version="1.0" xml:lang="my-MM" xmlns="http://www.w3.org/2001/10/synthesis"><voice name="{selected_voice}"><prosody rate="+0%">{xml_escape(script)}</prosody></voice></speak>'
    
    try:
        import azure.cognitiveservices.speech as speechsdk
    except ImportError:
        raise RuntimeError("azure-cognitiveservices-speech package ကို requirements.txt တွင် မတွေ့ပါ။")

    speech_config = speechsdk.SpeechConfig(subscription=key, region=region)
    speech_config.set_speech_synthesis_output_format(speechsdk.SpeechSynthesisOutputFormat.Audio24Khz48KBitRateMonoMp3)
    
    stream = speechsdk.audio.PullAudioOutputStream()
    audio_config = speechsdk.audio.AudioOutputConfig(stream=stream)
    synthesizer = speechsdk.SpeechSynthesizer(speech_config=speech_config, audio_config=audio_config)
    
    word_boundaries = []
    def word_boundary_cb(evt):
        word_boundaries.append({
            "word": evt.text, "offset_ms": evt.audio_offset / 10000, "duration_ms": evt.duration / 10000
        })
    synthesizer.synthesis_word_boundary.connect(word_boundary_cb)
    
    result = synthesizer.speak_ssml_async(ssml).get()
    
    if result.reason == speechsdk.ResultReason.SynthesizingAudioCompleted:
        if not word_boundaries:
            # အကယ်၍ Microsoft မှ အချိန်အတိအကျ မပေးပို့ခဲ့ပါက၊ သင်္ချာနည်းဖြင့် မတွက်ဘဲ Error တိုက်ရိုက်ပြပါမည်။
            raise RuntimeError("Microsoft ဆာဗာမှ ဤစကားလုံးများအတွက် အချိန်အတိအကျ (Word Boundaries) ပြန်လည်မပေးပို့ပါ။")
            
        srt_lines = []
        break_words = ["။", "၊", "သောအခါ", "အောင်", "၍", "ပြီး", "လို့", "သောကြောင့်", "မို့လို့", "သည်", "ပါ", "တယ်", "မယ်"]
        chunks = []
        current_chunk = []
        for w_info in word_boundaries:
            current_chunk.append(w_info)
            text_so_far = " ".join([w["word"] for w in current_chunk])
            char_count = len(text_so_far.replace(" ", ""))
            is_break = any(text_so_far.strip().endswith(bw) for bw in break_words)
            if (char_count >= 10 and is_break) or char_count > 18:
                chunks.append(current_chunk)
                current_chunk = []
        if current_chunk: chunks.append(current_chunk)
            
        def clock(ms: float) -> str:
            ms = int(max(0, ms))
            return f"{ms // 3_600_000:02d}:{(ms // 60_000) % 60:02d}:{(ms // 1000) % 60:02d},{ms % 1000:03d}"
            
        for idx, chunk in enumerate(chunks):
            start_ms = chunk[0]["offset_ms"]
            end_ms = chunk[-1]["offset_ms"] + chunk[-1]["duration_ms"]
            text = " ".join([w["word"] for w in chunk])
            adjusted_end = end_ms - 50 if end_ms - start_ms > 200 else end_ms
            srt_lines.append(f"{idx + 1}\n{clock(start_ms)} --> {clock(adjusted_end)}\n{text.strip()}")
            
        CACHE_DIR = Path(tempfile.gettempdir()) / "srt_cache"
        CACHE_DIR.mkdir(exist_ok=True)
        h = hashlib.md5(script.encode('utf-8')).hexdigest()
        (CACHE_DIR / f"{h}.srt").write_text("\n\n".join(srt_lines), encoding="utf-8")
        
        return result.audio_data
    else:
        raise RuntimeError(f"Microsoft Voice ဆာဗာ ချို့ယွင်းနေပါသည်။: {result.reason}")

def generate_gemini_tts(script: str, voice: str, api_key: str) -> bytes:
    if not api_key: raise RuntimeError("Gemini API Key မရှိပါ။")
    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key={api_key}"
    payload = {
        "contents": [{"role": "user", "parts": [{"text": script}]}],
        "generationConfig": {"responseModalities": ["AUDIO"], "speechConfig": {"voiceConfig": {"prebuiltVoiceConfig": {"voiceName": voice}}}}
    }
    response = requests.post(url, json=payload, timeout=(10, 80))
    if not response.ok: raise RuntimeError(f"Gemini Voice Error: {response.status_code}")
    try:
        data = response.json()
        audio_b64 = data["candidates"][0]["content"]["parts"][0]["inlineData"]["data"]
        return base64.b64decode(audio_b64)
    except Exception as e:
        raise RuntimeError("Gemini မှ အသံဖိုင်ပြန်မလာပါ။") from e

def make_srt(script: str, duration: float) -> str:
    # ဤ Function သည် Gemini AI အသံများ (Word Boundary မရနိုင်သော အသံများ) အတွက်သာ အလုပ်လုပ်မည်ဖြစ်ပါသည်။
    # Microsoft အသံအတွက် Cache ထဲမှ တိုက်ရိုက်ယူပါမည်။ သင်္ချာနည်းဖြင့် ထပ်မတွက်တော့ပါ။
    cleaned = script.strip()
    if not cleaned: return ""

    h = hashlib.md5(script.encode('utf-8')).hexdigest()
    cache_file = Path(tempfile.gettempdir()) / "srt_cache" / f"{h}.srt"
    if cache_file.exists():
        return cache_file.read_text(encoding="utf-8")
    
    words = cleaned.replace('\n', ' ').split(' ')
    chunks = []
    current_chunk = ""
    break_words = ["။", "၊", "သောအခါ", "အောင်", "၍", "ပြီး", "လို့", "သောကြောင့်", "မို့လို့", "သည်", "ပါ", "တယ်", "မယ်"]
    
    for word in words:
        if not word.strip(): continue
        current_chunk += word + " "
        char_count = len(current_chunk.replace(" ", ""))
        is_break = any(current_chunk.strip().endswith(bw) for bw in break_words)
        if (char_count >= 10 and is_break) or char_count > 18:
            chunks.append(current_chunk.strip())
            current_chunk = ""
            
    if current_chunk.strip(): chunks.append(current_chunk.strip())

    total_weight = 0
    chunk_weights = []
    for chunk in chunks:
        base_weight = len(chunk.replace(" ", "")) * 1.5
        if chunk.endswith("။"): base_weight += 20  
        elif chunk.endswith("၊"): base_weight += 10  
        chunk_weights.append(base_weight)
        total_weight += base_weight

    if total_weight == 0: return ""

    def clock(value: float) -> str:
        ms = int(max(0, value) * 1000)
        return f"{ms // 3_600_000:02d}:{(ms // 60_000) % 60:02d}:{(ms // 1000) % 60:02d},{ms % 1000:03d}"

    srt_output = []
    current_time = 0.0
    for index, (line, weight) in enumerate(zip(chunks, chunk_weights)):
        piece_duration = (weight / total_weight) * duration
        end_time = current_time + piece_duration
        adjusted_end = end_time - 0.05 if end_time - current_time > 0.2 else end_time
        srt_output.append(f"{index + 1}\n{clock(current_time)} --> {clock(adjusted_end)}\n{line.strip()}")
        current_time = end_time
        
    return "\n\n".join(srt_output)

def ass_color(value: str, alpha: int = 0) -> str:
    color = re.sub(r"[^0-9a-fA-F]", "", value or "")[-6:].rjust(6, "F")
    return f"&H{max(0, min(255, alpha)):02X}{color[4:6]}{color[2:4]}{color[:2]}"

def fitted_source_rect(source: dict[str, float | int], out_width: int, out_height: int) -> dict[str, int]:
    source_width = max(1, int(source["width"]))
    source_height = max(1, int(source["height"]))
    scale = min(out_width / source_width, out_height / source_height)
    width = max(2, round(source_width * scale))
    height = max(2, round(source_height * scale))
    return {"x": (out_width - width) // 2, "y": (out_height - height) // 2, "width": width, "height": height}

def srt_to_ass(srt: str, settings: dict[str, Any], width: int, height: int, source_rect: dict[str, int] | None = None) -> str:
    scale_factor = (height / 720.0)
    raw_size = float(settings.get("subtitle_size", 20))
    font_size = max(20, min(80, round(raw_size * 1.8 * scale_factor)))
    
    visible = source_rect or {"x": 0, "y": 0, "width": width, "height": height}
    x = int(visible["x"]) + math.floor(int(visible["width"]) * max(0, min(100, int(settings.get("subtitle_x", 50)))) / 100 + 0.5)
    y = int(visible["y"]) + math.floor(int(visible["height"]) * max(0, min(100, int(settings.get("subtitle_y", 82)))) / 100 + 0.5)
    
    mode = str(settings.get("subtitle_background", "solid")).strip().lower()
    solid_bg = mode in {"solid", "solid background"}
    
    outline_thickness = 3
    shadow_thickness = 2
    
    opacity = max(0, min(100, int(settings.get("subtitle_opacity", 70))))
    back_alpha = 255 - round(opacity * 255 / 100)
    font = FONT_FAMILIES.get(str(settings.get("subtitle_font", "Noto Sans Myanmar")), "Noto Sans Myanmar")
    
    outline_color = ass_color(str(settings.get('subtitle_outline', '#000000')))
    primary_color = ass_color(str(settings.get('subtitle_color', '#FFD166')))
    bg_color = ass_color(str(settings.get('subtitle_background_color', '#000000')), back_alpha)
    
    header = [
        "[Script Info]", "ScriptType: v4.00+", f"PlayResX: {width}", f"PlayResY: {height}", "",
        "[V4+ Styles]",
        "Format: Name,Fontname,Fontsize,PrimaryColour,SecondaryColour,OutlineColour,BackColour,Bold,Italic,Underline,StrikeOut,ScaleX,ScaleY,Spacing,Angle,BorderStyle,Outline,Shadow,Alignment,MarginL,MarginR,MarginV,Encoding"
    ]
    
    if solid_bg:
        transparent = "&HFF000000"
        header.append(f"Style: BoxStyle,{font},{font_size},{transparent},{transparent},{bg_color},{bg_color},-1,0,0,0,100,100,0,0,3,3,0,2,20,20,20,1")
        header.append(f"Style: TextStyle,{font},{font_size},{primary_color},{primary_color},{outline_color},&H00000000,-1,0,0,0,100,100,0,0,1,{outline_thickness},{shadow_thickness},2,20,20,20,1")
    else:
        header.append(f"Style: TextStyle,{font},{font_size},{primary_color},{primary_color},{outline_color},&H00000000,-1,0,0,0,100,100,0,0,1,{outline_thickness},{shadow_thickness},2,20,20,20,1")

    header.extend(["", "[Events]", "Format: Layer,Start,End,Style,Name,MarginL,MarginR,MarginV,Effect,Text"])
    events: list[str] = []
    
    for block in re.split(r"\n\s*\n", srt.strip()):
        lines = [line.strip() for line in block.splitlines() if line.strip()]
        if len(lines) < 3 or "-->" not in lines[1]: continue
        start, end = (piece.strip() for piece in lines[1].split("-->", 1))
        try:
            def convert(value: str) -> str:
                hours, minutes, seconds_ms = value.split(":")
                seconds, milliseconds = seconds_ms.split(",")
                return f"{int(hours)}:{int(minutes):02d}:{int(seconds):02d}.{int(milliseconds) // 10:02d}"
            caption = " ".join(lines[2:]).replace("{", "\\{").replace("}", "\\}")
            
            if solid_bg:
                events.append(f"Dialogue: 0,{convert(start)},{convert(end)},BoxStyle,,0,0,0,,{{\\an5\\pos({x},{y})}}{caption}")
            events.append(f"Dialogue: 1,{convert(start)},{convert(end)},TextStyle,,0,0,0,,{{\\an5\\pos({x},{y})}}{caption}")
        except ValueError: continue
    return "\n".join(header + events) + "\n"

def get_audio_duration(audio_path: Path) -> float:
    try:
        res = _run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(audio_path)], timeout=15)
        return float(res.stdout.strip() or 0)
    except Exception: return 0.0

def render_final(video_path: Path, tts_wav: bytes, settings: dict[str, Any], output_path: Path) -> Path:
    source = probe_video(video_path)
    aspect = str(settings.get("aspect", "9:16"))
    scale = 854
    if aspect == "16:9": out_w, out_h = round(scale * 16 / 9), scale
    elif aspect == "1:1": out_w, out_h = scale, scale
    else: out_w, out_h = scale, round(scale * 16 / 9)
    out_w -= out_w % 2
    out_h -= out_h % 2
    visible_rect = fitted_source_rect(source, out_w, out_h)
    
    try: speed_float = float(re.sub(r"[^\d.]", "", str(settings.get("voiceSpeed", "1.0"))) or 1.0)
    except ValueError: speed_float = 1.0

    temp_paths: list[Path] = []
    
    # 1.0x Normal Speed TTS File ကိုသာ အမြဲတမ်းအသုံးပြုမည်
    raw_audio_path = Path(tempfile.mktemp(suffix=".mp3"))
    raw_audio_path.write_bytes(tts_wav)
    temp_paths.append(raw_audio_path)
    
    raw_tts_dur = get_audio_duration(raw_audio_path)
    if raw_tts_dur <= 0: raw_tts_dur = float(source["duration"])
    
    target_dur = raw_tts_dur / speed_float if speed_float > 0 else raw_tts_dur

    v_pts_factor = raw_tts_dur / float(source["duration"]) if float(source["duration"]) > 0 else 1.0

    video_filters = [f"setpts={v_pts_factor:.4f}*PTS-STARTPTS"]
    if settings.get("mirror"): video_filters.append("hflip")
    if settings.get("zoom_enabled"): video_filters.append("crop=iw*0.96:ih*0.96")
    if settings.get("color_effect"): video_filters.append("eq=brightness=0.02:saturation=1.12:contrast=1.05")
    video_filters.append("unsharp=5:5:0.8:3:3:0.4")
    
    video_filters.extend([f"scale={out_w}:{out_h}:force_original_aspect_ratio=decrease:flags=lanczos", f"pad={out_w}:{out_h}:(ow-iw)/2:(oh-ih)/2:color=black"])
    
    graph = f"[0:v]{','.join(video_filters)}[v0]"
    current_v = "v0"
    
    if settings.get("blur_enabled"):
        for idx, mask in enumerate(settings.get("blur_masks", [])):
            bx = max(1, int(float(mask["x"]) * out_w))
            by = max(1, int(float(mask["y"]) * out_h))
            bw = max(1, min(int(float(mask["width"]) * out_w), out_w - bx - 1))
            bh = max(1, min(int(float(mask["height"]) * out_h), out_h - by - 1))
            next_v = f"blur{idx}"
            graph += f";[{current_v}]split=2[bg{idx}][toblur{idx}];[toblur{idx}]crop={bw}:{bh}:{bx}:{by},boxblur=20:5[blurred{idx}];[bg{idx}][blurred{idx}]overlay={bx}:{by}[{next_v}]"
            current_v = next_v

    inputs = ["ffmpeg", "-y", "-i", str(video_path), "-i", str(raw_audio_path)]

    if settings.get("logo_path") or settings.get("watermark_path"):
        logo_str = settings.get("logo_path") or settings.get("watermark_path")
        if logo_str and Path(str(logo_str)).exists():
            inputs.extend(["-i", str(logo_str)])
            logo_idx = inputs.count("-i") - 1
            next_v = "vlogo"
            graph += f";[{logo_idx}:v]scale=150:-1[wm];[{current_v}][wm]overlay=W-w-20:20[{next_v}]"
            current_v = next_v
        
    if settings.get("subtitles", True):
        srt = str(settings.get("subtitle_srt") or make_srt(str(settings.get("script") or ""), raw_tts_dur))
        ass_path = Path(tempfile.mktemp(suffix=".ass"))
        ass_path.write_text(srt_to_ass(srt, settings, out_w, out_h, visible_rect), encoding="utf-8", newline="\n")
        temp_paths.append(ass_path)
        font_file = FONT_FILES.get(str(settings.get("subtitle_font")), FONT_FILES["Noto Sans Myanmar"])
        font_dir = Path(tempfile.mkdtemp(prefix="fonts-"))
        shutil.copy2(font_file, font_dir / font_file.name)
        temp_paths.append(font_dir)
        next_v = "vsub"
        graph += f";[{current_v}]ass=filename='{str(ass_path).replace(':', r'\:')}':fontsdir='{str(font_dir).replace(':', r'\:')}'[{next_v}]"
        current_v = next_v
        
    # စာတန်းထိုးနှင့် ဗီဒီယိုကို အတိအကျ ပေါင်းစပ်ပြီးမှသာ Speed ပြောင်းလဲခြင်း
    if speed_float != 1.0:
        next_v = "vsped"
        graph += f";[{current_v}]setpts={1.0/speed_float:.4f}*PTS[{next_v}]"
        current_v = next_v
    
    a_filters = []
    current_a_mix = "[1:a]"
    orig_audio = str(settings.get("originalAudio", "Mute"))
    
    has_orig = source.get("has_audio") and orig_audio != "Mute"
    bgm_path_str = settings.get("music_path")
    use_bgm = bool(bgm_path_str) and Path(str(bgm_path_str)).exists() and orig_audio != "Normal"
    
    if has_orig:
        vol = "0.15" if orig_audio == "Low" else "0.7"
        a_filters.append(f"[0:a]volume={vol}[orig_a]")
        a_filters.append(f"{current_a_mix}[orig_a]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[mixed_1]")
        current_a_mix = "[mixed_1]"
        
    if use_bgm:
        inputs.extend(["-i", str(bgm_path_str)])
        bgm_idx = inputs.count("-i") - 1
        bgm_vol = float(settings.get("music_volume", 24)) / 100.0
        a_filters.append(f"[{bgm_idx}:a]volume={bgm_vol}[bgm_a]")
        a_filters.append(f"{current_a_mix}[bgm_a]amix=inputs=2:duration=first:dropout_transition=2:normalize=0[mixed_2]")
        current_a_mix = "[mixed_2]"

    if speed_float != 1.0:
        final_a = "final_a"
        a_filters.append(f"{current_a_mix}atempo={speed_float}[{final_a}]")
        audio_inputs = f"[{final_a}]"
    else:
        audio_inputs = current_a_mix

    if a_filters:
        graph += ";" + ";".join(a_filters)

    command = inputs + [
        "-filter_complex", graph,
        "-map", f"[{current_v}]", "-map", audio_inputs,
        "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-pix_fmt", "yuv420p",
        "-r", "30", "-c:a", "aac", "-b:a", "192k", "-t", f"{target_dur:.3f}", 
        "-movflags", "+faststart", str(output_path),
    ]
    
    try:
        _run(command, timeout=2400)
        if not output_path.exists() or output_path.stat().st_size < 1024: raise RuntimeError("Final MP4 မဖန်တီးနိုင်ပါ။")
        return output_path
    finally:
        for path in temp_paths:
            if path.is_dir(): shutil.rmtree(path, ignore_errors=True)
            else: path.unlink(missing_ok=True)
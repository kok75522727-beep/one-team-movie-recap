const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const VOICE_CATALOG = [
  { id: 'Nilar', name: 'နီလာ', vip: false }, { id: 'Thiha', name: 'သီဟ', vip: false },
  { id: 'Ava', name: 'အေးမြတ်', vip: false }, { id: 'Andrew', name: 'အောင်ဒင်', vip: false }
];

let previewAudio = null;

const state = {
  projectId: crypto.randomUUID(), video: null, videoUrl: '', dimensions: null,
  masks: [], jobId: '', dragging: null, activeTab: 'blur', isLink: false,
  uploaded: { logo: '', music: '' }, logoUrl: '', auth: null, accessToken: '', member: null,
};
const video = $('#sourceVideo');
const stage = $('#videoStage');
const layer = $('#overlayLayer');

function displayRect() {
  const r = stage.getBoundingClientRect(); 
  const vw = video.videoWidth || 9; const vh = video.videoHeight || 16;
  const scale = Math.min(r.width / vw, r.height / vh); 
  const width = vw * scale; const height = vh * scale;
  return { left: (r.width - width) / 2, top: (r.height - height) / 2, width, height };
}
function clamp(n, lower, upper) { return Math.max(lower, Math.min(upper, n)); }
function output(input, target, suffix = '') { const el = $(target); if (el && input) el.textContent = `${input.value}${suffix}`; }
function stagePoint(x, y) { const r = displayRect(); return { x: r.left + x * r.width / 100, y: r.top + y * r.height / 100 }; }
function relativePoint(x, y) { const r = displayRect(); return { x: clamp((x - r.left) / r.width, 0, 1), y: clamp((y - r.top) / r.height, 0, 1) }; }
function authHeaders() { return state.accessToken ? { Authorization: `Bearer ${state.accessToken}` } : {}; }

function settings() {
  return {
    subtitles: $('#subtitleEnabled')?.checked ?? true,
    subtitle_text: $('#subtitleText')?.value || 'စာတန်းနေရာ (Center)',
    subtitle_font: $('#subtitleFont')?.value || 'Noto Sans Myanmar',
    subtitle_size: +($('#subtitleSize')?.value || 20),
    subtitle_color: $('#subtitleColor')?.value || '#ffd166',
    subtitle_outline: $('#subtitleOutline')?.value || '#000000',
    subtitle_background: $('#subtitleBackground')?.value || 'Solid background',
    subtitle_opacity: +($('#subtitleOpacity')?.value || 70),
    subtitle_x: +($('#subtitleX')?.value || 50),
    subtitle_y: +($('#subtitleY')?.value || 82),
    blur_enabled: $('#blurEnabled')?.checked ?? false,
    blur_strength: +($('#blurStrength')?.value || 18),
    blur_layer: $('#blurLayer')?.value || 'background',
    blur_masks: state.masks,
    mirror: $('#mirror')?.checked ?? false,
    original_audio: $('#originalAudio')?.value || 'Mute',
    logo_enabled: $('#logoEnabled')?.checked ?? false,
    logo_path: state.uploaded.logo,
    logo_text: $('#logoText')?.value || '',
    logo_size: +($('#logoSize')?.value || 22),
    logo_x: +($('#logoX')?.value || 84),
    logo_y: +($('#logoY')?.value || 86),
    music_path: state.uploaded.music,
    music_volume: +($('#musicVolume')?.value || 24),
    voice: $('#voice')?.value || 'Nilar',
    language: $('#language')?.value || 'Myanmar',
    tone: $('#tone')?.value || 'Cinematic',
    voiceSpeed: $('#voiceSpeed')?.value || '1.0',
    aspect: $('#aspect')?.value || '9:16',
    quality: '720p',
    recapType: $('#recapType')?.value || 'Movie Recap',
    source_url: state.isLink ? state.videoUrl : null,
    duration: state.dimensions?.duration || 0,
  };
}

function renderVoiceGrid() {
  const container = $('#voiceGrid'); if (!container) return;
  const currentVoice = $('#voice').value;
  container.innerHTML = VOICE_CATALOG.map((v) => `
    <div class="voice-card ${currentVoice === v.id ? 'selected' : ''}" data-voice-id="${v.id}">
      <span class="voice-name">${v.name}</span>
    </div>
  `).join('');
  container.querySelectorAll('.voice-card').forEach((card) => {
    card.addEventListener('click', () => {
      $('#voice').value = card.dataset.voiceId;
      container.querySelectorAll('.voice-card').forEach((c) => c.classList.remove('selected'));
      card.classList.add('selected');
    });
  });
}

window.oneTeamSaveKey = () => {
  const key = String($('#apiKey').value || '').trim();
  if (!key) { alert('API Key ထည့်ပါ'); return false; }
  sessionStorage.setItem('one-team-gemini-key', key); $('#apiKey').value = ''; $('#keySheet').classList.add('hidden');
  return true;
};
function savedKey() { return sessionStorage.getItem('one-team-gemini-key') || ''; }

function redraw() {
  layer.replaceChildren(); const set = settings();
  if (set.blur_enabled && (state.activeTab === 'blur' || state.activeTab === 'subtitle')) {
    state.masks.forEach((mask, index) => addBoxElement(mask, index, state.activeTab === 'subtitle'));
  }
  if ((state.activeTab === 'subtitle' || state.activeTab === 'blur') && set.subtitles) {
    addSubtitleElement(set);
  }
  if (state.activeTab === 'logo' && set.logo_enabled) addLogoElement(set);
}

function addSubtitleElement(set) {
  const node = document.createElement('div'); 
  node.className = `subtitle-overlay ${set.subtitle_background === 'Solid background' ? 'solid' : ''}`;
  node.textContent = set.subtitle_text; 
  node.style.color = set.subtitle_color; 
  node.style.textShadow = `2px 2px 2px ${set.subtitle_outline},-2px -2px 2px ${set.subtitle_outline}`;
  node.style.fontSize = `${Math.max(16, set.subtitle_size * 1.2)}px`; 
  node.style.border = '2px dashed rgba(255, 255, 255, 0.7)'; // Center alignment border
  node.style.textAlign = 'center';
  layer.append(node);
  const area = displayRect(); 
  node.style.width = '200px'; 
  const p = stagePoint(set.subtitle_x, set.subtitle_y);
  // Center alignment offset
  node.style.left = `${clamp(p.x - node.offsetWidth / 2, area.left, area.left + area.width - node.offsetWidth)}px`; 
  node.style.top = `${clamp(p.y - node.offsetHeight / 2, area.top, area.top + area.height - node.offsetHeight)}px`; 
  dragNode(node, 'subtitle');
}

function addBoxElement(mask, index, isGhost = false) {
  const area = displayRect(); const node = document.createElement('div'); 
  node.className = `blur-box ${isGhost ? 'ghost-blur' : ''}`; node.dataset.index = index;
  node.style.left = `${area.left + mask.x * area.width}px`; node.style.top = `${area.top + mask.y * area.height}px`; 
  node.style.width = `${mask.width * area.width}px`; node.style.height = `${mask.height * area.height}px`;
  if (!isGhost) { const handle = document.createElement('i'); handle.className = 'resize-handle'; node.append(handle); dragNode(node, 'blur'); }
  layer.append(node);
}

function addLogoElement(set) {
  const area = displayRect(); const node = document.createElement('div'); node.className = 'logo-overlay'; 
  node.style.width = `${clamp(area.width * set.logo_size / 100, 72, area.width)}px`;
  if (state.logoUrl) { const image = document.createElement('img'); image.src = state.logoUrl; node.append(image); }
  if (set.logo_text) { const text = document.createElement('span'); text.textContent = set.logo_text; node.append(text); }
  if (!node.childNodes.length) node.textContent = 'Logo'; const handle = document.createElement('i'); handle.className = 'resize-handle'; node.append(handle); layer.append(node);
  const p = stagePoint(set.logo_x, set.logo_y); node.style.left = `${clamp(p.x - node.offsetWidth / 2, area.left, area.left + area.width - node.offsetWidth)}px`; node.style.top = `${clamp(p.y - node.offsetHeight / 2, area.top, area.top + area.height - node.offsetHeight)}px`; dragNode(node, 'logo');
}

function dragNode(node, type) {
  node.addEventListener('pointerdown', (event) => { event.preventDefault(); node.setPointerCapture(event.pointerId); const r = node.getBoundingClientRect(); const s = stage.getBoundingClientRect(); state.dragging = { node, type, resize: event.target.classList.contains('resize-handle'), sx: event.clientX, sy: event.clientY, x: r.left - s.left, y: r.top - s.top, w: r.width, h: r.height }; });
  node.addEventListener('pointermove', (event) => { 
    const d = state.dragging; if (!d || d.node !== node) return; 
    const area = displayRect(); const dx = event.clientX - d.sx; const dy = event.clientY - d.sy; 
    if (d.resize && type === 'blur') { d.w = clamp(d.w + dx, 24, area.left + area.width - d.x); d.h = clamp(d.h + dy, 24, area.top + area.height - d.y); node.style.width = `${d.w}px`; node.style.height = `${d.h}px`; } 
    else if (d.resize && type === 'logo') { d.w = clamp(d.w + dx, 72, area.left + area.width - d.x); node.style.width = `${d.w}px`; } 
    else { d.x = clamp(d.x + dx, area.left, area.left + area.width - node.offsetWidth); d.y = clamp(d.y + dy, area.top, area.top + area.height - node.offsetHeight); node.style.left = `${d.x}px`; node.style.top = `${d.y}px`; } 
    d.sx = event.clientX; d.sy = event.clientY; 
  });
  const finish = () => { 
    const d = state.dragging; if (!d || d.node !== node) return; 
    if (type === 'subtitle') { const p = relativePoint(d.x + node.offsetWidth / 2, d.y + node.offsetHeight / 2); $('#subtitleX').value = Math.round(p.x * 100); $('#subtitleY').value = Math.round(p.y * 100); output($('#subtitleX'), '#subtitleXValue'); output($('#subtitleY'), '#subtitleYValue'); } 
    else if (type === 'logo') { const p = relativePoint(d.x + node.offsetWidth / 2, d.y + node.offsetHeight / 2); const area = displayRect(); $('#logoX').value = Math.round(p.x * 100); $('#logoY').value = Math.round(p.y * 100); $('#logoSize').value = Math.round(clamp(node.offsetWidth / area.width * 100, 10, 45)); output($('#logoX'), '#logoXValue'); output($('#logoY'), '#logoYValue'); output($('#logoSize'), '#logoSizeValue'); } 
    else { const p = relativePoint(d.x, d.y); const area = displayRect(); const index = +node.dataset.index; state.masks[index] = { x: p.x, y: p.y, width: clamp(node.offsetWidth / area.width, .01, 1 - p.x), height: clamp(node.offsetHeight / area.height, .01, 1 - p.y) }; } 
    state.dragging = null; 
  };
  node.addEventListener('pointerup', finish); node.addEventListener('pointercancel', finish); node.addEventListener('lostpointercapture', finish);
}

function selectTab(tab) { state.activeTab = tab; $$('.tab').forEach((item) => item.classList.toggle('active', item.dataset.tab === tab)); $$('.tab-page').forEach((page) => page.classList.toggle('active', page.dataset.page === tab)); redraw(); }
async function uploadAsset(input, kind) { const file = input.files?.[0]; if (!file) return; const data = new FormData(); data.append('file', file); data.append('kind', kind); data.append('project_id', state.projectId); const response = await fetch('/api/assets', { method: 'POST', body: data }); const body = await response.json(); if (!response.ok) { alert(body.detail || 'ဖိုင်တင်မရပါ'); return; } state.uploaded[kind] = body.path; input.closest('label').classList.add('uploaded'); if (kind === 'logo') { if (state.logoUrl) URL.revokeObjectURL(state.logoUrl); state.logoUrl = URL.createObjectURL(file); redraw(); } }
async function uploadVideo(file) { 
  const form = new FormData(); form.append('file', file); form.append('project_id', state.projectId); 
  const response = await fetch('/api/video', { method: 'POST', body: form }); 
  const body = await response.json(); 
  if (!response.ok) throw new Error(body.detail || 'Video တင်မရပါ'); 
  state.dimensions = body; $('#videoName').textContent = file.name; $('#videoMeta').textContent = `${Math.round(body.duration)} sec · Ready`; $('#sessionStatus').textContent = 'Ready to edit'; $('#exportButton').disabled = false; 
}
function selectFile(event) { 
  const file = event.target.files?.[0]; if (!file) return; state.video = file; 
  if (state.videoUrl) URL.revokeObjectURL(state.videoUrl); state.videoUrl = URL.createObjectURL(file); video.src = state.videoUrl; 
  $('#emptyState').classList.add('hidden'); stage.classList.remove('hidden'); 
  uploadVideo(file).catch((error) => alert(error.message)); 
}

const fetchBtn = $('#fetchLinkBtn');
if (fetchBtn) {
    fetchBtn.addEventListener('click', async () => {
        const url = $('#linkInput').value.trim();
        if (!url) { alert('Link ထည့်ပေးပါ'); return; }
        
        $('#linkInputContainer').classList.add('hidden');
        $('#uploadHint').classList.add('hidden');
        $('#linkLoadingContainer').classList.remove('hidden');
        $('#sessionStatus').textContent = 'Video ကို ဆာဗာသို့ ဒေါင်းလုဒ်ဆွဲနေပါသည်...';
        
        try {
            const res = await fetch('/api/link-preview', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url })
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || 'Link ဖွင့်မရပါ');
            
            state.projectId = data.project_id; state.videoUrl = data.video_url; state.isLink = false; 
            state.video = { name: "Link_Video.mp4" }; state.dimensions = { duration: data.duration };
            video.src = data.video_url;
            $('#emptyState').classList.add('hidden'); stage.classList.remove('hidden'); 
            $('#videoName').textContent = "Link မှ Video"; $('#sessionStatus').textContent = 'Ready to edit'; $('#exportButton').disabled = false;
        } catch (e) {
            alert(e.message);
            $('#linkLoadingContainer').classList.add('hidden');
            $('#linkInputContainer').classList.remove('hidden');
            $('#uploadHint').classList.remove('hidden');
        }
    });
}

function setJob(job) { 
    const progress = +job.progress || 0; $('#jobProgress').style.width = `${progress}%`; $('#jobPercent').textContent = `${progress}%`; $('#jobTitle').textContent = job.message || 'Final Video လုပ်နေပါတယ်'; 
    const order = ['upload', 'script', 'voice', 'render']; const active = order.indexOf(job.step); 
    $$('#jobSteps li').forEach((li, index) => li.className = index < active ? 'done' : index === active ? 'active' : ''); 
    if (job.status === 'done') { 
        $('#downloadButton').href = job.download_url; $('#downloadButton').classList.remove('hidden'); $('#cancelJob').classList.add('hidden'); $('#jobTitle').textContent = 'Final MP4 အဆင်သင့်ပါပြီ'; 
        if (video && job.download_url) { video.src = job.download_url; video.controls = true; video.play(); }
    } 
    if (['error', 'cancelled'].includes(job.status)) { $('#jobError').textContent = job.error || 'Video ထုတ်မရပါ'; $('#jobError').classList.remove('hidden'); $('#cancelJob').classList.add('hidden'); } 
}
async function exportVideo() { 
    if (!state.video && !state.videoUrl) return; 
    if (!savedKey()) { $('#keySheet').classList.remove('hidden'); return; } 
    $('#jobCard').classList.remove('hidden'); $('#jobError').classList.add('hidden'); $('#downloadButton').classList.add('hidden'); $('#cancelJob').classList.remove('hidden'); $('#exportButton').disabled = true; 
    try { 
        const response = await fetch('/api/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json', ...authHeaders() }, body: JSON.stringify({ project_id: state.projectId, settings: settings(), simple_api_key: savedKey() }) }); 
        const job = await response.json(); 
        if (!response.ok) throw new Error(job.detail || 'Export မစနိုင်ပါ'); 
        state.jobId = job.id; setJob(job); pollJob(); 
    } catch (error) { $('#jobError').textContent = error.message; $('#jobError').classList.remove('hidden'); $('#exportButton').disabled = false; } 
}
async function pollJob() { if (!state.jobId) return; const response = await fetch(`/api/jobs/${state.jobId}`); const job = await response.json(); setJob(job); if (['queued', 'running'].includes(job.status)) window.setTimeout(pollJob, 1500); else $('#exportButton').disabled = false; }

$$('.tab').forEach((button) => button.addEventListener('click', () => selectTab(button.dataset.tab)));
$('#videoInput').addEventListener('change', selectFile); $('#logoInput').addEventListener('change', (event) => uploadAsset(event.target, 'logo')); $('#musicInput').addEventListener('change', (event) => uploadAsset(event.target, 'music'));
$('#addBlur').addEventListener('click', () => { state.masks.push({ x: .32, y: .3, width: .3, height: .16 }); $('#blurEnabled').checked = true; redraw(); });
['subtitleEnabled', 'blurEnabled', 'blurLayer', 'subtitleText', 'subtitleFont', 'subtitleColor', 'subtitleOutline', 'subtitleBackground', 'mirror', 'logoEnabled', 'logoText', 'aspect', 'recapType', 'originalAudio', 'voice', 'language', 'tone', 'voiceSpeed'].forEach((id) => { const el = $(`#${id}`); if (el) ['input', 'change'].forEach((event) => el.addEventListener(event, redraw)); });
[['subtitleSize', '#subtitleSizeValue'], ['subtitleOpacity', '#subtitleOpacityValue'], ['subtitleX', '#subtitleXValue'], ['subtitleY', '#subtitleYValue'], ['blurStrength', '#blurStrengthValue'], ['musicVolume', '#musicVolumeValue'], ['logoSize', '#logoSizeValue'], ['logoX', '#logoXValue'], ['logoY', '#logoYValue']].forEach(([input, target]) => { const el = $(`#${input}`); if (el) el.addEventListener('input', () => { output(el, target, ''); redraw(); }); });

video.addEventListener('loadedmetadata', () => { redraw(); requestAnimationFrame(redraw); window.setTimeout(redraw, 50); }); video.addEventListener('loadeddata', redraw); window.addEventListener('resize', redraw);
$('#exportButton').addEventListener('click', exportVideo); $('#keyButton').addEventListener('click', () => $('#keySheet').classList.remove('hidden')); $('#cancelJob').addEventListener('click', () => fetch(`/api/jobs/${state.jobId}/cancel`, { method: 'POST' })); $('#saveKey').addEventListener('click', window.oneTeamSaveKey); $('#closeKeySheet').addEventListener('click', () => $('#keySheet').classList.add('hidden')); 
renderVoiceGrid();
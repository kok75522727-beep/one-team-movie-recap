const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

let currentProjectId = "proj_" + Math.random().toString(36).substring(2, 9);
let previewAudio = null;

// --- Supabase / Backend Session စစ်ဆေးခြင်း (မူလစနစ် အပြည့်အစုံ) ---
async function initSession() {
  const sessionStatus = $("#sessionStatus");
  const ownerBtn = $("#ownerButton");

  try {
    const res = await fetch("/api/membership");
    if (!res.ok) throw new Error();
    const data = await res.json();

    const email = data.email || "အသုံးပြုသူ";
    let planLabel = "Simple Trial";

    if (data.is_admin) {
      planLabel = "Owner Pro 👑";
      if (ownerBtn) {
        ownerBtn.classList.remove("hidden");
        ownerBtn.onclick = () => window.location.assign("/owner");
      }
    } else if (data.plan === "pro" || data.tier === "vip") {
      planLabel = "Pro VIP 👑";
    } else {
      planLabel = `Simple (${data.trial_days_remaining || 0} ရက်ကျန်)`;
    }

    if (sessionStatus) {
      sessionStatus.textContent = `${email} · ${planLabel}`;
    }
  } catch (err) {
    if (sessionStatus) {
      sessionStatus.textContent = "Guest Mode · လော့ဂင်ဝင်ပါ";
    }
  }
}

// --- Tab ပြောင်းလဲခြင်း ---
$$(".tab").forEach((button) => {
  button.addEventListener("click", () => {
    $$(".tab").forEach((b) => b.classList.remove("active"));
    $$(".tab-page").forEach((p) => p.classList.remove("active"));
    button.classList.add("active");
    const target = $(`.tab-page[data-page="${button.dataset.tab}"]`);
    if (target) target.classList.add("active");
  });
});

// --- Sliders ---
[["blurStrength", "blurStrengthValue"], ["subtitleSize", "subtitleSizeValue"]].forEach(([inp, out]) => {
  const inputEl = $(`#${inp}`);
  const outEl = $(`#${out}`);
  if (inputEl && outEl) {
    inputEl.addEventListener("input", () => { outEl.textContent = inputEl.value; });
  }
});

// --- Video ဖိုင်တင်ခြင်း ---
$("#videoInput")?.addEventListener("change", async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;

  $("#videoName").textContent = file.name;
  $("#sourceVideo").src = URL.createObjectURL(file);
  $("#emptyState").classList.add("hidden");
  $("#videoStage").classList.remove("hidden");
  $("#exportButton").disabled = false;

  const form = new FormData();
  form.append("file", file);
  form.append("project_id", currentProjectId);

  try {
    const res = await fetch("/api/video", { method: "POST", body: form });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || "Video တင်မရပါ");
    $("#videoMeta").textContent = `${(file.size / 1024 / 1024).toFixed(1)} MB · ${Math.round(data.duration)}s · Ready`;
  } catch (err) {
    alert(err.message);
  }
});

// --- အသံ စမ်းနားထောင်ခြင်း (▶ စမ်းနားထောင်) ---
$("#previewVoiceBtn")?.addEventListener("click", async () => {
  const btn = $("#previewVoiceBtn");
  if (previewAudio) {
    previewAudio.pause();
    previewAudio = null;
    btn.textContent = "▶ စမ်းနားထောင်";
    return;
  }

  const voiceId = $("#voice").value;
  btn.textContent = "စောင့်ပါ…";

  try {
    const res = await fetch("/api/preview-ms-voice", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ voice: voiceId })
    });
    if (!res.ok) throw new Error("အသံထုတ်မရပါ");

    const blob = await res.blob();
    previewAudio = new Audio(URL.createObjectURL(blob));
    btn.textContent = "■ ရပ်မယ်";
    previewAudio.play();
    previewAudio.onended = () => { btn.textContent = "▶ စမ်းနားထောင်"; previewAudio = null; };
  } catch (err) {
    alert("အသံစမ်းနားထောင်ရန် အဆင်မပြေပါ: " + err.message);
    btn.textContent = "▶ စမ်းနားထောင်";
  }
});

// --- Video Export စနစ် ---
$("#exportButton")?.addEventListener("click", async () => {
  const exportBtn = $("#exportButton");
  exportBtn.disabled = true;
  $("#jobCard")?.classList.remove("hidden");
  $("#downloadButton")?.classList.add("hidden");
  $("#jobError")?.classList.add("hidden");

  const payload = {
    project_id: currentProjectId,
    settings: {
      voice: $("#voice")?.value || "Nilar",
      language: $("#language")?.value || "Myanmar",
      tone: $("#tone")?.value || "Cinematic",
      recapType: $("#recapType")?.value || "Movie Recap",
      blur_enabled: $("#blurEnabled")?.checked || false,
      subtitles: $("#subtitleEnabled")?.checked || true
    },
    simple_api_key: sessionStorage.getItem("one-team-gemini-key") || ""
  };

  try {
    const res = await fetch("/api/jobs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    const job = await res.json();
    if (!res.ok) throw new Error(job.detail || "Export စတင်၍ မရပါ");

    const jobId = job.id;
    const interval = setInterval(async () => {
      const cRes = await fetch(`/api/jobs/${jobId}`);
      const cJob = await cRes.json();

      $("#jobProgress").style.width = `${cJob.progress}%`;
      $("#jobPercent").textContent = `${cJob.progress}% - ${cJob.message}`;

      if (cJob.status === "done") {
        clearInterval(interval);
        $("#downloadButton").href = cJob.download_url;
        $("#downloadButton").classList.remove("hidden");
        exportBtn.disabled = false;
      } else if (cJob.status === "error") {
        clearInterval(interval);
        $("#jobError").textContent = cJob.error;
        $("#jobError").classList.remove("hidden");
        exportBtn.disabled = false;
      }
    }, 2000);
  } catch (err) {
    $("#jobError").textContent = err.message;
    $("#jobError").classList.remove("hidden");
    exportBtn.disabled = false;
  }
});

// --- API Key & Plan Sheets ---
$("#keyButton")?.addEventListener("click", () => $("#keySheet")?.classList.remove("hidden"));
$("#closeKeySheet")?.addEventListener("click", () => $("#keySheet")?.classList.add("hidden"));
$("#saveKey")?.addEventListener("click", () => {
  const k = $("#apiKey")?.value.trim();
  if (k) sessionStorage.setItem("one-team-gemini-key", k);
  $("#keySheet")?.classList.add("hidden");
  alert("API Key မှတ်သားပြီးပါပြီ");
});

initSession();
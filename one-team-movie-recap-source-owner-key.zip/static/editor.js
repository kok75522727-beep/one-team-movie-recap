const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

let previewAudio = null;

const state = {
  projectId: crypto.randomUUID(),
  video: null,
  videoUrl: '',
  jobId: '',
  member: { email: "owner@oneteam.com", is_admin: true, plan: "pro", tier: "vip" } // တိုက်ရိုက် Pro ပေးထားပါသည်
};

// စတင်ချိန်တွင် Account အခြေအနေ ပြသခြင်း
function initApp() {
  $('#sessionStatus').textContent = 'Pro VIP · Unlimited Ready';
  $('#ownerButton').classList.remove('hidden');
  $('#ownerButton').onclick = () => window.location.assign('/owner');
}

// Tab ပြောင်းလဲခြင်း
$$('.tab').forEach((button) => {
  button.addEventListener('click', () => {
    $$('.tab').forEach((b) => b.classList.remove('active'));
    $$('.tab-page').forEach((p) => p.classList.remove('active'));
    button.classList.add('active');
    const target = $(`.tab-page[data-page="${button.dataset.tab}"]`);
    if (target) target.classList.add('active');
  });
});

// Slider တန်ဖိုးများ ပြသခြင်း
[['subtitleSize', '#subtitleSizeValue'], ['subtitleOpacity', '#subtitleOpacityValue'], 
 ['subtitleX', '#subtitleXValue'], ['subtitleY', '#subtitleYValue'], 
 ['blurStrength', '#blurStrengthValue'], ['musicVolume', '#musicVolumeValue'], 
 ['logoSize', '#logoSizeValue'], ['logoX', '#logoXValue'], ['logoY', '#logoYValue']].forEach(([input, target]) => {
  const el = $(`#${input}`);
  if (el) el.addEventListener('input', () => { const t = $(target); if (t) t.textContent = el.value; });
});

// Video ဖိုင် တင်ခြင်း
$('#videoInput').addEventListener('change', async (e) => {
  const file = e.target.files?.[0];
  if (!file) return;

  $('#videoName').textContent = file.name;
  $('#sourceVideo').src = URL.createObjectURL(file);
  $('#emptyState').classList.add('hidden');
  $('#videoStage').classList.remove('hidden');
  $('#exportButton').disabled = false;

  const form = new FormData();
  form.append('file', file);
  form.append('project_id', state.projectId);

  try {
    const res = await fetch('/api/video', { method: 'POST', body: form });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Video တင်မရပါ');
    $('#videoMeta').textContent = `${(file.size / 1024 / 1024).toFixed(1)} MB · ${Math.round(data.duration)}s · Ready`;
  } catch (err) {
    alert(err.message);
  }
});

// အသံ စမ်းနားထောင်သည့် လုပ်ဆောင်ချက် (▶ စမ်းနားထောင်)
$('#previewVoiceBtn')?.addEventListener('click', async () => {
  const btn = $('#previewVoiceBtn');
  if (previewAudio) {
    previewAudio.pause();
    previewAudio = null;
    btn.textContent = '▶ စမ်းနားထောင်';
    return;
  }

  const voiceId = $('#voice').value;
  btn.textContent = 'စောင့်ပါ…';

  try {
    const res = await fetch('/api/preview-ms-voice', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ voice: voiceId })
    });
    if (!res.ok) throw new Error('အသံထုတ်မရပါ');

    const blob = await res.blob();
    previewAudio = new Audio(URL.createObjectURL(blob));
    btn.textContent = '■ ရပ်မယ်';
    previewAudio.play();
    previewAudio.onended = () => { btn.textContent = '▶ စမ်းနားထောင်'; previewAudio = null; };
  } catch (err) {
    alert('အသံနမူနာ မရနိုင်သေးပါ: ဆာဗာ Azure Key စစ်ဆေးပါ');
    btn.textContent = '▶ စမ်းနားထောင်';
  }
});

// Video Export လုပ်ဆောင်ချက်
$('#exportButton').addEventListener('click', async () => {
  $('#exportButton').disabled = true;
  $('#jobCard').classList.remove('hidden');
  $('#downloadButton').classList.add('hidden');
  $('#jobError').classList.add('hidden');

  const payload = {
    project_id: state.projectId,
    settings: {
      voice: $('#voice').value,
      language: $('#language').value,
      tone: $('#tone').value,
      voiceSpeed: $('#voiceSpeed').value,
      recapType: $('#recapType').value,
      blur_enabled: $('#blurEnabled').checked,
      subtitles: $('#subtitleEnabled').checked
    },
    simple_api_key: sessionStorage.getItem('one-team-gemini-key') || ''
  };

  try {
    const res = await fetch('/api/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const job = await res.json();
    if (!res.ok) throw new Error(job.detail || 'Export မစနိုင်ပါ');
    
    state.jobId = job.id;
    pollJob();
  } catch (err) {
    $('#jobError').textContent = err.message;
    $('#jobError').classList.remove('hidden');
    $('#exportButton').disabled = false;
  }
});

async function pollJob() {
  if (!state.jobId) return;
  const res = await fetch(`/api/jobs/${state.jobId}`);
  const job = await res.json();
  
  $('#jobProgress').style.width = `${job.progress}%`;
  $('#jobPercent').textContent = `${job.progress}% - ${job.message}`;
  
  if (job.status === 'done') {
    $('#downloadButton').href = job.download_url;
    $('#downloadButton').classList.remove('hidden');
    $('#exportButton').disabled = false;
  } else if (job.status === 'error') {
    $('#jobError').textContent = job.error;
    $('#jobError').classList.remove('hidden');
    $('#exportButton').disabled = false;
  } else {
    setTimeout(pollJob, 1500);
  }
}

// API Key သိမ်းဆည်းရန်
$('#keyButton').onclick = () => $('#keySheet').classList.remove('hidden');
$('#closeKeySheet').onclick = () => $('#keySheet').classList.add('hidden');
$('#saveKey').onclick = () => {
  const k = $('#apiKey').value.trim();
  if (k) sessionStorage.setItem('one-team-gemini-key', k);
  $('#keySheet').classList.add('hidden');
  alert('API Key မှတ်သားပြီးပါပြီ');
};

initApp();
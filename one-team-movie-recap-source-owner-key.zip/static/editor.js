const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const VOICE_CATALOG = [
  { id: 'Nilar', name: 'နီလာ (အမျိုးသမီး)', vip: false },
  { id: 'Thiha', name: 'သီဟ (အမျိုးသား)', vip: false },
  { id: 'Kore', name: 'ကုသိုလ် (ကြည်လင်)', vip: false },
  { id: 'Puck', name: 'ပန်းနု (သွက်လက်)', vip: false },
  { id: 'Charon', name: 'ချမ်းသာ (နက်ရှိုင်း)', vip: false },
  { id: 'Fenrir', name: 'ဖုန်းမော် (ပြတ်သား)', vip: false },
  { id: 'Aoede', name: 'အိမ့်စည် (ငြိမ့်ညောင်း)', vip: false },
  { id: 'Leda', name: 'လရောင် (နူးညံ့)', vip: false },
  { id: 'Orus', name: 'အာကာ (ရဲရင့်)', vip: false },
  { id: 'Zephyr', name: 'ဇေယျာ (တည်ငြိမ်)', vip: false },
  { id: 'Achernar', name: 'အောင်ချမ်း (ဆန်းကြယ်)', vip: false },
  { id: 'Enceladus', name: 'ဧကရာဇ် (ခမ်းနား)', vip: false },
  { id: 'Ava', name: 'အေးမြတ်', vip: false },
  { id: 'Andrew', name: 'အောင်ဒင်', vip: false },
  { id: 'Emma', name: 'အိအိမွန်', vip: false },
  { id: 'Brian', name: 'ဘုန်းမြတ်', vip: false },
  { id: 'Vivienne', name: 'ဝေဝေခိုင်', vip: false },
  { id: 'Remy', name: 'ရဲရင့်အောင်', vip: false },
  { id: 'Seraphina', name: 'စန္ဒီ', vip: false },
  { id: 'Florian', name: 'ဖြိုးမင်း', vip: false },
  { id: 'Xiaoxiao', name: 'ဆုဆုလှိုင်', vip: false },
  { id: 'Giuseppe', name: 'ဂျော်နီ', vip: false },
];

let previewAudio = null;

const state = {
  projectId: crypto.randomUUID(), video: null, videoUrl: '', dimensions: null,
  masks: [], jobId: '', dragging: null, activeTab: 'blur', isLink: false,
  uploaded: { logo: '', music: '' }, logoUrl: '', auth: null, accessToken: '', member: null,
  catalog: null, selectedPayment: null,
};

const video = $('#sourceVideo');
const stage = $('#videoStage');
const layer = $('#overlayLayer');

function displayRect() {
  const r = stage ? stage.getBoundingClientRect() : {width: 0, height: 0, left: 0, top: 0}; 
  const vw = (video && video.videoWidth) ? video.videoWidth : 9; 
  const vh = (video && video.videoHeight) ? video.videoHeight : 16;
  const scale = Math.min(r.width / vw, r.height / vh); 
  const width = vw * scale; const height = vh * scale;
  return { left: (r.width - width) / 2, top: (r.height - height) / 2, width, height };
}
function clamp(n, lower, upper) { return Math.max(lower, Math.min(upper, n)); }
function output(input, target, suffix = '') { const el = $(target); if (el && input) el.textContent = `${input.value}${suffix}`; }
function stagePoint(x, y) { const r = displayRect(); return { x: r.left + x * r.width / 100, y: r.top + y * r.height / 100 }; }
function relativePoint(x, y) { const r = displayRect(); return { x: clamp((x - r.left) / r.width, 0, 1), y: clamp((y - r.top) / r.height, 0, 1) }; }
function authHeaders() { return state.accessToken ? { Authorization: `Bearer ${state.accessToken}` } : {}; }
async function bridgeSession() { if (!state.accessToken) return false; return (await fetch('/api/browser-session', { method: 'POST', headers: authHeaders() })).ok; }
function escapeHtml(value) { const node = document.createElement('span'); node.textContent = String(value || ''); return node.innerHTML; }
function mmk(value) { return `${Number(value || 0).toLocaleString()} ကျပ်`; }

function settings() {
  return {
    subtitles: $('#subtitleEnabled')?.checked ?? true,
    subtitle_text: $('#subtitleText')?.value || 'စာတန်းနေရာ (Center)',
    subtitle_font: $('#subtitleFont')?.value || 'Noto Sans Myanmar',
    subtitle_size: +($('#subtitleSize')?.value || 20),
    subtitle_color: $('#subtitleColor')?.value || '#ffd166',
    subtitle_outline: $('#subtitleOutline')?.value || '#000000',
    subtitle_background: $('#subtitleBackground')?.value || 'solid',
    subtitle_opacity: +($('#subtitleOpacity')?.value || 70),
    subtitle_x: +($('#subtitleX')?.value || 50),
    subtitle_y: +($('#subtitleY')?.value || 82),
    blur_enabled: $('#blurEnabled')?.checked ?? false,
    blur_strength: +($('#blurStrength')?.value || 18),
    blur_layer: $('#blurLayer')?.value || 'S',
    blur_masks: state.masks,
    mirror: $('#mirror')?.checked ?? false,
    zoom_enabled: $('#zoomEnabled')?.checked ?? false,
    color_effect: $('#colorEffect')?.checked ?? false,
    original_audio: $('#originalAudio')?.value || 'Mute',
    logo_enabled: $('#logoEnabled')?.checked ?? false,
    logo_path: state.uploaded.logo,
    logo_text: $('#logoText')?.value || '',
    logo_size: +($('#logoSize')?.value || 22),
    logo_x: +($('#logoX')?.value || 84),
    logo_y: +($('#logoY')?.value || 86),
    music_path: state.uploaded.music,
    music_volume: +($('#musicVolume')?.value || 24),
    voice: $('#voice')?.value || 'Nilar',
    language: $('#language')?.value || 'Myanmar',
    tone: $('#tone')?.value || 'Cinematic',
    voiceSpeed: $('#voiceSpeed')?.value || '1.0',
    aspect: $('#aspect')?.value || '9:16',
    quality: '720p',
    recapType: $('#recapType')?.value || 'Movie Recap',
    source_url: state.isLink ? state.videoUrl : null,
    duration: state.dimensions?.duration || 0,
  };
}

function renderVoiceGrid() {
  const container = $('#voiceGrid'); if (!container) return;
  const currentVoice = $('#voice')?.value || 'Nilar';
  container.innerHTML = VOICE_CATALOG.map((v) => `
    <div class="voice-card ${currentVoice === v.id ? 'selected' : ''}" data-voice-id="${v.id}" data-vip="${v.vip}">
      <div class="voice-card-info">
        <span class="voice-name">${escapeHtml(v.name)}</span>
      </div>
      <button class="voice-play-btn" type="button" data-play="${v.id}">▶</button>
    </div>
  `).join('');
  container.querySelectorAll('.voice-card').forEach((card) => {
    card.addEventListener('click', (e) => {
      if (e.target.closest('.voice-play-btn')) return;
      if ($('#voice')) $('#voice').value = card.dataset.voiceId;
      container.querySelectorAll('.voice-card').forEach((c) => c.classList.remove('selected'));
      card.classList.add('selected');
    });
  });
  container.querySelectorAll('.voice-play-btn').forEach((btn) => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const vId = btn.dataset.play;
      playVoiceSample(vId, btn);
    });
  });
}

function playVoiceSample(voiceId, btn) {
  if (previewAudio) {
    previewAudio.pause(); previewAudio = null;
    $$('.voice-play-btn').forEach((b) => b.textContent = '▶');
  }
  btn.textContent = '■';
  fetch('/api/preview-ms-voice', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ voice: voiceId })
  }).then(res => {
    if (!res.ok) throw new Error("Audio fail"); return res.blob();
  }).then(blob => {
    previewAudio = new Audio(URL.createObjectURL(blob));
    previewAudio.play();
    previewAudio.onended = () => { btn.textContent = '▶'; previewAudio = null; };
  }).catch(() => {
    const utter = new SpeechSynthesisUtterance("မင်္ဂလာပါ၊ One Team မှ ကြိုဆိုပါတယ်။");
    utter.rate = 1.0; window.speechSynthesis.speak(utter); btn.textContent = '▶';
  });
}

window.oneTeamSaveKey = () => {
  const keyInput = $('#apiKey');
  const key = keyInput ? String(keyInput.value || '').trim() : '';
  if (!key) { alert('API Key ထည့်ပါ'); return false; }
  sessionStorage.setItem('one-team-gemini-key', key); 
  if(keyInput) keyInput.value = ''; 
  if($('#keySheet')) $('#keySheet').classList.add('hidden');
  return true;
};
function savedKey() { return sessionStorage.getItem('one-team-gemini-key') || ''; }
function requiresUserKey() { return true; }

function redraw() {
  if (!layer) return;
  layer.replaceChildren(); const set = settings();
  if (set.blur_enabled && (state.activeTab === 'blur' || state.activeTab === 'subtitle')) {
    state.masks.forEach((mask, index) => addBoxElement(mask, index, state.activeTab === 'subtitle'));
  }
  if ((state.activeTab === 'subtitle' || state.activeTab === 'blur') && set.subtitles) {
    addSubtitleElement(set);
  }
  if (state.activeTab === 'logo' && set.logo_enabled) addLogoElement(set);
}

function addSubtitleElement(set) {
  const node = document.createElement('div'); 
  node.className = `subtitle-overlay ${String(set.subtitle_background).toLowerCase() === 'solid' || String(set.subtitle_background) === 'Solid background' ? 'solid' : ''}`;
  node.textContent = set.subtitle_text || 'စာတန်းနေရာ (Center)'; 
  node.style.color = set.subtitle_color; 
  node.style.textShadow = `2px 2px 2px ${set.subtitle_outline},-2px -2px 2px ${set.subtitle_outline}`;
  node.style.fontSize = `${Math.max(16, set.subtitle_size * 1.2)}px`; 
  node.style.border = '2px dashed rgba(255, 255, 255, 0.7)'; 
  node.style.textAlign = 'center';
  node.style.whiteSpace = 'nowrap';
  node.style.padding = '4px 8px';
  
  layer.append(node);
  const area = displayRect(); 
  
  const p = stagePoint(set.subtitle_x, set.subtitle_y);
  node.style.left = `${clamp(p.x - node.offsetWidth / 2, area.left, area.left + area.width - node.offsetWidth)}px`; 
  node.style.top = `${clamp(p.y - node.offsetHeight / 2, area.top, area.top + area.height - node.offsetHeight)}px`; 
  dragNode(node, 'subtitle');
}

function addBoxElement(mask, index, isGhost = false) {
  const area = displayRect(); const node = document.createElement('div'); 
  node.className = `blur-box ${isGhost ? 'ghost-blur' : ''}`; node.dataset.index = index;
  node.style.left = `${area.left + mask.x * area.width}px`; node.style.top = `${area.top + mask.y * area.height}px`; 
  node.style.width = `${mask.width * area.width}px`; node.style.height = `${mask.height * area.height}px`;
  if (!isGhost) { const handle = document.createElement('i'); handle.className = 'resize-handle'; node.append(handle); dragNode(node, 'blur'); }
  layer.append(node);
}

function addLogoElement(set) {
  const area = displayRect(); const node = document.createElement('div'); node.className = 'logo-overlay'; 
  node.style.width = `${clamp(area.width * set.logo_size / 100, 72, area.width)}px`;
  if (state.logoUrl) { const image = document.createElement('img'); image.src = state.logoUrl; node.append(image); }
  if (set.logo_text) { const text = document.createElement('span'); text.textContent = set.logo_text; node.append(text); }
  if (!node.childNodes.length) node.textContent = 'Logo'; const handle = document.createElement('i'); handle.className = 'resize-handle'; node.append(handle); layer.append(node);
  const p = stagePoint(set.logo_x, set.logo_y); node.style.left = `${clamp(p.x - node.offsetWidth / 2, area.left, area.left + area.width - node.offsetWidth)}px`; node.style.top = `${clamp(p.y - node.offsetHeight / 2, area.top, area.top + area.height - node.offsetHeight)}px`; dragNode(node, 'logo');
}

function dragNode(node, type) {
  node.addEventListener('pointerdown', (event) => { event.preventDefault(); node.setPointerCapture(event.pointerId); const r = node.getBoundingClientRect(); const s = stage.getBoundingClientRect(); state.dragging = { node, type, resize: event.target.classList.contains('resize-handle'), sx: event.clientX, sy: event.clientY, x: r.left - s.left, y: r.top - s.top, w: r.width, h: r.height }; });
  node.addEventListener('pointermove', (event) => { 
    const d = state.dragging; if (!d || d.node !== node) return; 
    const area = displayRect(); const dx = event.clientX - d.sx; const dy = event.clientY - d.sy; 
    if (d.resize && type === 'blur') { d.w = clamp(d.w + dx, 24, area.left + area.width - d.x); d.h = clamp(d.h + dy, 24, area.top + area.height - d.y); node.style.width = `${d.w}px`; node.style.height = `${d.h}px`; } 
    else if (d.resize && type === 'logo') { d.w = clamp(d.w + dx, 72, area.left + area.width - d.x); node.style.width = `${d.w}px`; } 
    else { d.x = clamp(d.x + dx, area.left, area.left + area.width - node.offsetWidth); d.y = clamp(d.y + dy, area.top, area.top + area.height - node.offsetHeight); node.style.left = `${d.x}px`; node.style.top = `${d.y}px`; } 
    d.sx = event.clientX; d.sy = event.clientY; 
  });
  const finish = () => { 
    const d = state.dragging; if (!d || d.node !== node) return; 
    if (type === 'subtitle') { const p = relativePoint(d.x + node.offsetWidth / 2, d.y + node.offsetHeight / 2); if($('#subtitleX')) $('#subtitleX').value = Math.round(p.x * 100); if($('#subtitleY')) $('#subtitleY').value = Math.round(p.y * 100); output($('#subtitleX'), '#subtitleXValue'); output($('#subtitleY'), '#subtitleYValue'); } 
    else if (type === 'logo') { const p = relativePoint(d.x + node.offsetWidth / 2, d.y + node.offsetHeight / 2); const area = displayRect(); if($('#logoX')) $('#logoX').value = Math.round(p.x * 100); if($('#logoY')) $('#logoY').value = Math.round(p.y * 100); if($('#logoSize')) $('#logoSize').value = Math.round(clamp(node.offsetWidth / area.width * 100, 10, 45)); output($('#logoX'), '#logoXValue'); output($('#logoY'), '#logoYValue'); output($('#logoSize'), '#logoSizeValue'); } 
    else { const p = relativePoint(d.x, d.y); const area = displayRect(); const index = +node.dataset.index; state.masks[index] = { x: p.x, y: p.y, width: clamp(node.offsetWidth / area.width, .01, 1 - p.x), height: clamp(node.offsetHeight / area.height, .01, 1 - p.y) }; } 
    state.dragging = null; 
  };
  node.addEventListener('pointerup', finish); node.addEventListener('pointercancel', finish); node.addEventListener('lostpointercapture', finish);
}

function selectTab(tab) { state.activeTab = tab; $$('.tab').forEach((item) => item.classList.toggle('active', item.dataset.tab === tab)); $$('.tab-page').forEach((page) => page.classList.toggle('active', page.dataset.page === tab)); redraw(); }
async function uploadAsset(input, kind) { const file = input.files?.[0]; if (!file) return; const data = new FormData(); data.append('file', file); data.append('kind', kind); data.append('project_id', state.projectId); const response = await fetch('/api/assets', { method: 'POST', body: data }); const body = await response.json(); if (!response.ok) { alert(body.detail || 'ဖိုင်တင်မရပါ'); return; } state.uploaded[kind] = body.path; input.closest('label').classList.add('uploaded'); if (kind === 'logo') { if (state.logoUrl) URL.revokeObjectURL(state.logoUrl); state.logoUrl = URL.createObjectURL(file); redraw(); } }

async function uploadVideo(file) { 
  const form = new FormData(); form.append('file', file); form.append('project_id', state.projectId); 
  const response = await fetch('/api/video', { method: 'POST', body: form }); 
  const body = await response.json(); 
  if (!response.ok) throw new Error(body.detail || 'Video တင်မရပါ'); 
  state.dimensions = body; 
  if($('#videoName')) $('#videoName').textContent = file.name; 
  if($('#videoMeta')) $('#videoMeta').textContent = `${Math.round(body.duration)} sec · Ready`; 
  if($('#sessionStatus')) $('#sessionStatus').textContent = 'Ready to edit'; 
  if($('#exportButton')) $('#exportButton').disabled = false; 
}
function selectFile(event) { 
  const file = event.target.files?.[0]; if (!file) return; state.video = file; 
  if (state.videoUrl) URL.revokeObjectURL(state.videoUrl); state.videoUrl = URL.createObjectURL(file); 
  if (video) video.src = state.videoUrl; 
  if($('#emptyState')) $('#emptyState').classList.add('hidden'); 
  if(stage) stage.classList.remove('hidden'); 
  uploadVideo(file).catch((error) => alert(error.message)); 
}

function setJob(job) { 
    const progress = +job.progress || 0; 
    if($('#jobProgress')) $('#jobProgress').style.width = `${progress}%`; 
    if($('#jobPercent')) $('#jobPercent').textContent = `${progress}%`; 
    if($('#jobTitle')) $('#jobTitle').textContent = job.message || 'Final Video လုပ်နေပါတယ်'; 
    const order = ['upload', 'script', 'voice', 'render']; const active = order.indexOf(job.step); 
    $$('#jobSteps li').forEach((li, index) => li.className = index < active ? 'done' : index === active ? 'active' : ''); 
    if (job.status === 'done') { 
        if($('#downloadButton')) { $('#downloadButton').href = job.download_url; $('#downloadButton').classList.remove('hidden'); }
        if($('#cancelJob')) $('#cancelJob').classList.add('hidden'); 
        if($('#jobTitle')) $('#jobTitle').textContent = 'Final MP4 အဆင်သင့်ပါပြီ'; 
        if (video && job.download_url) { video.src = job.download_url; video.controls = true; video.play(); }
    } 
    if (['error', 'cancelled'].includes(job.status)) { 
        if($('#jobError')) { $('#jobError').textContent = job.error || 'Video ထုတ်မရပါ'; $('#jobError').classList.remove('hidden'); }
        if($('#cancelJob')) $('#cancelJob').classList.add('hidden'); 
    } 
}
async function exportVideo() { 
    if (!state.video && !state.videoUrl) return; 
    if (!state.accessToken) { window.location.assign('/login'); return; } 
    if (requiresUserKey() && !savedKey()) { if($('#keySheet')) $('#keySheet').classList.remove('hidden'); return; } 
    if($('#jobCard')) $('#jobCard').classList.remove('hidden'); 
    if($('#jobError')) $('#jobError').classList.add('hidden'); 
    if($('#downloadButton')) $('#downloadButton').classList.add('hidden'); 
    if($('#cancelJob')) $('#cancelJob').classList.remove('hidden'); 
    if($('#exportButton')) $('#exportButton').disabled = true; 
    try { 
        const response = await fetch('/api/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json', ...authHeaders() }, body: JSON.stringify({ project_id: state.projectId, settings: settings(), simple_api_key: savedKey() }) }); 
        const job = await response.json(); 
        if (!response.ok) throw new Error(job.detail || 'Export မစနိုင်ပါ'); 
        state.jobId = job.id; setJob(job); pollJob(); 
    } catch (error) { 
        if($('#jobError')) { $('#jobError').textContent = error.message; $('#jobError').classList.remove('hidden'); }
        if($('#exportButton')) $('#exportButton').disabled = false; 
    } 
}
async function pollJob() { if (!state.jobId) return; const response = await fetch(`/api/jobs/${state.jobId}`); const job = await response.json(); setJob(job); if (['queued', 'running'].includes(job.status)) window.setTimeout(pollJob, 1500); else if($('#exportButton')) $('#exportButton').disabled = false; }

function planTitle(member) { 
  if (!member) return 'Account ဝင်မယ်'; 
  if (member.is_admin) return 'Owner Pro'; 
  const credits = member.credit_balance || 0;
  const days = member.trial_days_remaining || 0;
  let creditInfo = credits > 0 ? ` · ${credits} Credits` : '';
  if (member.plan === 'simple') return `Trial (${days} ရက်)${creditInfo}`; 
  if (member.plan === 'pro') return `${member.subscription_tier === 'gold_vip' ? 'Gold VIP' : 'Silver VIP'} (${days} ရက်)${creditInfo}`; 
  return credits > 0 ? `${credits} Credits` : (member.trial_expired ? 'Trial ကုန်ပြီ' : 'Plan ဝယ်မယ်'); 
}

function setMembership(member) { 
  state.member = member || null; renderVoiceGrid();
  const title = planTitle(member); 
  if($('#planButton')) $('#planButton').textContent = title; 
  if($('#ownerButton')) $('#ownerButton').classList.toggle('hidden', !member?.is_admin); 
  if($('#sessionStatus')) $('#sessionStatus').textContent = member ? `${title} · ${member.email}` : 'Account ဝင်ပြီးမှ Export လုပ်ပါ'; 
}

async function refreshMembership() { 
  if (!state.accessToken) return;
  try {
      const response = await fetch('/api/membership', { headers: authHeaders() }); 
      if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          if($('#sessionStatus')) $('#sessionStatus').textContent = errorData.detail || 'Account အချက်အလက် ယူမရပါ'; return;
      }
      setMembership(await response.json()); 
  } catch (e) { if($('#sessionStatus')) $('#sessionStatus').textContent = 'Connection error'; }
}

async function loadPlans() { if (state.catalog) return state.catalog; const response = await fetch('/api/plans'); state.catalog = await response.json(); return state.catalog; }
function updateDestination() { const item = state.catalog?.destinations?.[$('#paymentMethod')?.value]; if($('#paymentDestination')) $('#paymentDestination').textContent = item ? `${$('#paymentMethod').value} · ${item.phone} · ${item.account_name}` : ''; }
function openPayment(kind, key) { 
  const items = kind === 'plan' ? state.catalog?.plans : state.catalog?.credit_packs;
  const offer = items?.find((item) => item.key === key); 
  if (!offer) return; state.selectedPayment = { kind, key, offer }; 
  if($('#paymentSelected')) $('#paymentSelected').textContent = `${offer.label} · ${mmk(offer.price)} · ${offer.description}`; 
  if($('#paymentForm')) { $('#paymentForm').classList.remove('hidden'); $('#paymentForm').scrollIntoView({ behavior: 'smooth', block: 'nearest' }); }
  if($('#paymentNote')) $('#paymentNote').textContent = ''; 
  updateDestination(); 
}

function renderOffers(catalog) { 
  const plans = (catalog.plans || []).map((item) => `
    <article class="offer"><div><strong>${escapeHtml(item.label)}</strong><p>${escapeHtml(item.description)}</p><b>${mmk(item.price)} / 30 ရက်</b></div><button data-kind="plan" data-key="${escapeHtml(item.key)}" type="button">ဝယ်ယူမည်</button></article>
  `).join(''); 
  const credits = (catalog.credit_packs || []).map((item) => `
    <article class="offer"><div><strong>${escapeHtml(item.label)}</strong><p>${escapeHtml(item.description)}</p><b>${mmk(item.price)}</b></div><button data-kind="credits" data-key="${escapeHtml(item.key)}" type="button">ဝယ်ယူမည်</button></article>
  `).join('');
  if($('#planList')) $('#planList').innerHTML = `<p class="plan-section-title">VIP Monthly Plans (လစဉ်ကြေး)</p>${plans}<p class="plan-section-title" style="margin-top: 15px;">Credit Packs (ခရက်ဒစ် အထုပ်များ)</p>${credits}`; 
}

async function openPlanSheet() { if (!state.accessToken) { window.location.assign('/login'); return; } if($('#planSheet')) $('#planSheet').classList.remove('hidden'); try { const catalog = await loadPlans(); renderOffers(catalog); const pending = state.member?.pending_payment ? ' · Payment စစ်နေပါတယ်' : ''; if($('#accountStatus')) $('#accountStatus').textContent = `${planTitle(state.member)}${pending} · Video ကိုစိတ်ကြိုက်ထုတ်လို့ရပါတယ်`; updateDestination(); } catch { if($('#accountStatus')) $('#accountStatus').textContent = 'Plan အချက်အလက်မရသေးပါ'; } }
async function submitPayment() { if (!state.selectedPayment) return; const transactionId = $('#transactionId')?.value.trim(); if (!transactionId || transactionId.length < 4) { if($('#paymentNote')) $('#paymentNote').textContent = 'Transaction ID မှန်မှန်ထည့်ပါ'; return; } const form = new FormData(); form.append('kind', state.selectedPayment.kind); form.append('offer_key', state.selectedPayment.key); form.append('payment_method', $('#paymentMethod')?.value || ''); form.append('transaction_id', transactionId); const receipt = $('#receiptInput')?.files?.[0]; if (receipt) form.append('receipt', receipt); if($('#submitPayment')) $('#submitPayment').disabled = true; if($('#paymentNote')) $('#paymentNote').textContent = 'ပို့နေပါတယ်…'; try { const response = await fetch('/api/payments', { method: 'POST', headers: authHeaders(), body: form }); const body = await response.json(); if (!response.ok) throw new Error(body.detail || 'ငွေလွှဲအချက်အလက်မပို့နိုင်ပါ'); if($('#paymentNote')) $('#paymentNote').textContent = body.message; if($('#paymentForm')) $('#paymentForm').classList.add('hidden'); await refreshMembership(); } catch (error) { if($('#paymentNote')) $('#paymentNote').textContent = error.message; } finally { if($('#submitPayment')) $('#submitPayment').disabled = false; } }

async function initializeAuth() { 
  try { 
    const config = await (await fetch('/api/auth-config')).json(); 
    if (config.enabled !== 'true' || !window.supabase) { if($('#sessionStatus')) $('#sessionStatus').textContent = 'Account Database setting မပြည့်သေးပါ'; return; } 
    state.auth = window.supabase.createClient(config.url, config.anon_key); 
    const { data: { session } } = await state.auth.auth.getSession(); 
    state.accessToken = session?.access_token || ''; 
    if (!state.accessToken || !await bridgeSession()) { 
      if (window.location.pathname !== '/login') window.location.replace('/login'); return; 
    } 
    await refreshMembership(); 
    state.auth.auth.onAuthStateChange(async (_event, sessionNow) => { 
      state.accessToken = sessionNow?.access_token || ''; 
      if (!state.accessToken) { 
        await fetch('/api/browser-session', { method: 'DELETE' }); 
        if (window.location.pathname !== '/login') window.location.replace('/login'); 
      } else if (await bridgeSession()) { refreshMembership(); }
    }); 
  } catch { if($('#sessionStatus')) $('#sessionStatus').textContent = 'Account စစ်မရသေးပါ။ ခဏနောက်ပြန်စမ်းပါ'; } 
}

function attachEvt(selector, evt, handler) { const el = $(selector); if (el) el.addEventListener(evt, handler); }

$$('.tab').forEach((button) => button.addEventListener('click', () => selectTab(button.dataset.tab)));
attachEvt('#videoInput', 'change', selectFile); 
attachEvt('#logoInput', 'change', (event) => uploadAsset(event.target, 'logo')); 
attachEvt('#musicInput', 'change', (event) => uploadAsset(event.target, 'music'));
attachEvt('#addBlur', 'click', () => { state.masks.push({ x: .32, y: .3, width: .3, height: .16 }); if($('#blurEnabled')) $('#blurEnabled').checked = true; redraw(); });

['subtitleEnabled', 'blurEnabled', 'blurLayer', 'subtitleText', 'subtitleFont', 'subtitleColor', 'subtitleOutline', 'subtitleBackground', 'mirror', 'zoomEnabled', 'colorEffect', 'logoEnabled', 'logoText', 'aspect', 'recapType', 'originalAudio', 'voice', 'language', 'tone', 'voiceSpeed'].forEach((id) => { const el = $(`#${id}`); if (el) ['input', 'change'].forEach((event) => el.addEventListener(event, redraw)); });
[['subtitleSize', '#subtitleSizeValue'], ['subtitleOpacity', '#subtitleOpacityValue'], ['subtitleX', '#subtitleXValue'], ['subtitleY', '#subtitleYValue'], ['blurStrength', '#blurStrengthValue'], ['musicVolume', '#musicVolumeValue'], ['logoSize', '#logoSizeValue'], ['logoX', '#logoXValue'], ['logoY', '#logoYValue']].forEach(([input, target]) => { const el = $(`#${input}`); if (el) el.addEventListener('input', () => { output(el, target, ''); redraw(); }); });

if (video) { video.addEventListener('loadedmetadata', () => { redraw(); requestAnimationFrame(redraw); window.setTimeout(redraw, 50); }); video.addEventListener('loadeddata', redraw); }
window.addEventListener('resize', redraw);

attachEvt('#exportButton', 'click', exportVideo); 
attachEvt('#keyButton', 'click', () => { if($('#keySheet')) $('#keySheet').classList.remove('hidden'); }); 
attachEvt('#cancelJob', 'click', () => fetch(`/api/jobs/${state.jobId}/cancel`, { method: 'POST' })); 
attachEvt('#saveKey', 'click', window.oneTeamSaveKey); 
attachEvt('#closeKeySheet', 'click', () => { if($('#keySheet')) $('#keySheet').classList.add('hidden'); }); 
attachEvt('#planButton', 'click', openPlanSheet); 
attachEvt('#closePlanSheet', 'click', () => { if($('#planSheet')) $('#planSheet').classList.add('hidden'); }); 
attachEvt('#ownerButton', 'click', () => window.location.assign('/owner')); 
attachEvt('#paymentMethod', 'change', updateDestination); 
attachEvt('#planList', 'click', (event) => { const button = event.target.closest('button[data-kind]'); if (button) openPayment(button.dataset.kind, button.dataset.key); }); 
attachEvt('#submitPayment', 'click', submitPayment);

const fetchBtn = $('#fetchLinkBtn');
if (fetchBtn) {
    fetchBtn.addEventListener('click', async () => {
        const url = $('#linkInput')?.value.trim();
        if (!url) { alert('Link ထည့်ပေးပါ'); return; }
        
        if($('#linkInputContainer')) $('#linkInputContainer').classList.add('hidden');
        if($('#uploadHint')) $('#uploadHint').classList.add('hidden');
        if($('#uploadLabel')) $('#uploadLabel').classList.add('hidden');
        if($('#linkLoadingContainer')) $('#linkLoadingContainer').classList.remove('hidden');
        if($('#sessionStatus')) $('#sessionStatus').textContent = 'Video ကို ဆာဗာသို့ချိတ်ဆက်နေပါသည်...';
        
        try {
            const res = await fetch('/api/link-preview', {
                method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ url })
            });
            const data = await res.json();
            if (!res.ok) throw new Error(data.detail || 'Link ဖွင့်မရပါ');
            
            const dlJobId = data.job_id;
            
            const pollDl = async () => {
                try {
                    const pRes = await fetch(`/api/jobs/${dlJobId}`);
                    const job = await pRes.json();
                    
                    if (job.status === 'error') {
                        throw new Error(job.error || 'ဒေါင်းလုဒ်ဆွဲ၍ မရပါ။');
                    }
                    
                    if (job.status === 'running') {
                        const pct = job.progress || 0;
                        if($('#linkProgressText')) $('#linkProgressText').textContent = job.message || `Video ကို ဆွဲယူနေပါသည်... ${pct}%`;
                        if($('#linkProgressBar')) $('#linkProgressBar').style.width = `${pct}%`;
                        setTimeout(pollDl, 1500);
                    } else if (job.status === 'done') {
                        state.projectId = job.project_id; 
                        state.videoUrl = job.video_url; 
                        state.isLink = true; 
                        state.video = { name: "Link_Video.mp4" }; 
                        state.dimensions = { duration: job.duration };
                        
                        if (video) {
                            video.src = job.video_url;
                            video.load();
                        }
                        if($('#emptyState')) $('#emptyState').classList.add('hidden'); 
                        if(stage) stage.classList.remove('hidden'); 
                        if($('#videoName')) $('#videoName').textContent = "Link မှ Video"; 
                        if($('#sessionStatus')) $('#sessionStatus').textContent = 'Ready to edit'; 
                        if($('#exportButton')) $('#exportButton').disabled = false;
                    }
                } catch (e) {
                    alert(e.message);
                    if($('#sessionStatus')) $('#sessionStatus').textContent = e.message;
                    if($('#linkLoadingContainer')) $('#linkLoadingContainer').classList.add('hidden');
                    if($('#linkInputContainer')) $('#linkInputContainer').classList.remove('hidden');
                    if($('#uploadHint')) $('#uploadHint').classList.remove('hidden');
                    if($('#uploadLabel')) $('#uploadLabel').classList.remove('hidden');
                }
            };
            
            pollDl();
            
        } catch (e) {
            alert(e.message);
            if($('#sessionStatus')) $('#sessionStatus').textContent = e.message;
            if($('#linkLoadingContainer')) $('#linkLoadingContainer').classList.add('hidden');
            if($('#linkInputContainer')) $('#linkInputContainer').classList.remove('hidden');
            if($('#uploadHint')) $('#uploadHint').classList.remove('hidden');
            if($('#uploadLabel')) $('#uploadLabel').classList.remove('hidden');
        }
    });
}

renderVoiceGrid();
window.setTimeout(() => void initializeAuth(), 0);
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

const state = {
  projectId: crypto.randomUUID(), video: null, videoUrl: '', dimensions: null,
  masks: [], jobId: '', dragging: null, activeTab: 'subtitle',
  uploaded: { logo: '', music: '' }, logoUrl: '', auth: null, accessToken: '', member: null,
  catalog: null, selectedPayment: null,
};
const video = $('#sourceVideo');
const stage = $('#videoStage');
const layer = $('#overlayLayer');

function displayRect() {
  const r = stage.getBoundingClientRect(); const vw = video.videoWidth || 9; const vh = video.videoHeight || 16;
  const scale = Math.min(r.width / vw, r.height / vh); const width = vw * scale; const height = vh * scale;
  return { left: (r.width - width) / 2, top: (r.height - height) / 2, width, height };
}
function clamp(n, lower, upper) { return Math.max(lower, Math.min(upper, n)); }
function output(input, target, suffix = '') { $(target).textContent = `${input.value}${suffix}`; }
function stagePoint(x, y) { const r = displayRect(); return { x: r.left + x * r.width / 100, y: r.top + y * r.height / 100 }; }
function relativePoint(x, y) { const r = displayRect(); return { x: clamp((x - r.left) / r.width, 0, 1), y: clamp((y - r.top) / r.height, 0, 1) }; }
function authHeaders() { return state.accessToken ? { Authorization: `Bearer ${state.accessToken}` } : {}; }
async function bridgeSession() { if (!state.accessToken) return false; return (await fetch('/api/browser-session', { method: 'POST', headers: authHeaders() })).ok; }
function escapeHtml(value) { const node = document.createElement('span'); node.textContent = String(value || ''); return node.innerHTML; }
function mmk(value) { return `${Number(value || 0).toLocaleString()} ကျပ်`; }

function settings() {
  return {
    subtitles: $('#subtitleEnabled').checked, subtitle_text: $('#subtitleText').value,
    subtitle_font: $('#subtitleFont').value, subtitle_size: +$('#subtitleSize').value,
    subtitle_color: $('#subtitleColor').value, subtitle_outline: $('#subtitleOutline').value,
    subtitle_background: $('#subtitleBackground').value, subtitle_opacity: +$('#subtitleOpacity').value,
    subtitle_x: +$('#subtitleX').value, subtitle_y: +$('#subtitleY').value,
    blur_enabled: $('#blurEnabled').checked, blur_strength: +$('#blurStrength').value, blur_masks: state.masks,
    auto_zoom: $('#autoZoom').checked, mirror: $('#mirror').checked, color_filter: $('#colorFilter').checked,
    background_blur: $('#backgroundBlur').checked, pitch_alter: $('#pitchAlter').checked,
    original_audio: $('#originalAudio').value, logo_enabled: $('#logoEnabled').checked, logo_path: state.uploaded.logo,
    logo_text: $('#logoText').value, logo_size: +$('#logoSize').value, logo_x: +$('#logoX').value, logo_y: +$('#logoY').value,
    music_path: state.uploaded.music, music_volume: +$('#musicVolume').value, voice: $('#voice').value,
    language: $('#language').value, duration: +$('#duration').value, tone: $('#tone').value,
    aspect: $('#aspect').value, quality: $('#quality').value, type: $('#recapType').value,
  };
}

function requiresUserKey() { return true; }
function savedKey() { return sessionStorage.getItem('one-team-gemini-key') || ''; }
window.oneTeamSaveKey = () => {
  const key = String($('#apiKey').value || '').trim();
  if (!key) { alert('API Key ထည့်ပါ'); return false; }
  sessionStorage.setItem('one-team-gemini-key', key); $('#apiKey').value = ''; $('#keySheet').classList.add('hidden');
  $('#sessionStatus').textContent = 'API Key အဆင်သင့် · Export လုပ်လို့ရပါပြီ'; return true;
};

function redraw() {
  layer.replaceChildren(); const set = settings();
  if (state.activeTab === 'blur' && set.blur_enabled) state.masks.forEach((mask, index) => addBoxElement(mask, index));
  if (state.activeTab === 'subtitle' && set.subtitles) addSubtitleElement(set);
  if (state.activeTab === 'logo' && set.logo_enabled) addLogoElement(set);
}
function addSubtitleElement(set) {
  const node = document.createElement('div'); node.className = `subtitle-overlay ${set.subtitle_background === 'Solid background' ? 'solid' : ''}`;
  node.textContent = set.subtitle_text || 'စာတန်းထိုး နေရာ'; node.style.color = set.subtitle_color; node.style.textShadow = `2px 2px 2px ${set.subtitle_outline},-2px -2px 2px ${set.subtitle_outline}`;
  node.style.fontSize = `${Math.max(16, set.subtitle_size * .92)}px`; node.style.fontFamily = `${set.subtitle_font}, 'Noto Sans Myanmar', sans-serif`; layer.append(node);
  const area = displayRect(); node.style.maxWidth = `${Math.max(40, area.width - 8)}px`; const p = stagePoint(set.subtitle_x, set.subtitle_y);
  node.style.left = `${clamp(p.x - node.offsetWidth / 2, area.left, area.left + area.width - node.offsetWidth)}px`; node.style.top = `${clamp(p.y - node.offsetHeight / 2, area.top, area.top + area.height - node.offsetHeight)}px`; dragNode(node, 'subtitle');
}
function addBoxElement(mask, index) {
  const area = displayRect(); const node = document.createElement('div'); node.className = 'blur-box'; node.dataset.index = index;
  node.style.left = `${area.left + mask.x * area.width}px`; node.style.top = `${area.top + mask.y * area.height}px`; node.style.width = `${mask.width * area.width}px`; node.style.height = `${mask.height * area.height}px`;
  const handle = document.createElement('i'); handle.className = 'resize-handle'; node.append(handle); layer.append(node); dragNode(node, 'blur');
}
function addLogoElement(set) {
  const area = displayRect(); const node = document.createElement('div'); node.className = 'logo-overlay'; node.style.width = `${clamp(area.width * set.logo_size / 100, 72, area.width)}px`; node.style.fontSize = `${Math.max(13, set.logo_size * .75)}px`;
  if (state.logoUrl) { const image = document.createElement('img'); image.src = state.logoUrl; image.alt = 'Logo preview'; node.append(image); }
  if (set.logo_text) { const text = document.createElement('span'); text.textContent = set.logo_text; node.append(text); }
  if (!node.childNodes.length) node.textContent = 'Logo'; const handle = document.createElement('i'); handle.className = 'resize-handle'; node.append(handle); layer.append(node);
  const p = stagePoint(set.logo_x, set.logo_y); node.style.left = `${clamp(p.x - node.offsetWidth / 2, area.left, area.left + area.width - node.offsetWidth)}px`; node.style.top = `${clamp(p.y - node.offsetHeight / 2, area.top, area.top + area.height - node.offsetHeight)}px`; dragNode(node, 'logo');
}
function dragNode(node, type) {
  node.addEventListener('pointerdown', (event) => { event.preventDefault(); node.setPointerCapture(event.pointerId); const r = node.getBoundingClientRect(); const s = stage.getBoundingClientRect(); state.dragging = { node, type, resize: event.target.classList.contains('resize-handle'), sx: event.clientX, sy: event.clientY, x: r.left - s.left, y: r.top - s.top, w: r.width, h: r.height }; });
  node.addEventListener('pointermove', (event) => { const d = state.dragging; if (!d || d.node !== node) return; const area = displayRect(); const dx = event.clientX - d.sx; const dy = event.clientY - d.sy; if (d.resize && type === 'blur') { d.w = clamp(d.w + dx, 24, area.left + area.width - d.x); d.h = clamp(d.h + dy, 24, area.top + area.height - d.y); node.style.width = `${d.w}px`; node.style.height = `${d.h}px`; } else if (d.resize && type === 'logo') { d.w = clamp(d.w + dx, 72, area.left + area.width - d.x); node.style.width = `${d.w}px`; } else { d.x = clamp(d.x + dx, area.left, area.left + area.width - node.offsetWidth); d.y = clamp(d.y + dy, area.top, area.top + area.height - node.offsetHeight); node.style.left = `${d.x}px`; node.style.top = `${d.y}px`; } d.sx = event.clientX; d.sy = event.clientY; });
  const finish = () => { const d = state.dragging; if (!d || d.node !== node) return; if (type === 'subtitle') { const p = relativePoint(d.x + node.offsetWidth / 2, d.y + node.offsetHeight / 2); $('#subtitleX').value = Math.round(p.x * 100); $('#subtitleY').value = Math.round(p.y * 100); output($('#subtitleX'), '#subtitleXValue'); output($('#subtitleY'), '#subtitleYValue'); } else if (type === 'logo') { const p = relativePoint(d.x + node.offsetWidth / 2, d.y + node.offsetHeight / 2); const area = displayRect(); $('#logoX').value = Math.round(p.x * 100); $('#logoY').value = Math.round(p.y * 100); $('#logoSize').value = Math.round(clamp(node.offsetWidth / area.width * 100, 10, 45)); output($('#logoX'), '#logoXValue'); output($('#logoY'), '#logoYValue'); output($('#logoSize'), '#logoSizeValue'); } else { const p = relativePoint(d.x, d.y); const area = displayRect(); const index = +node.dataset.index; state.masks[index] = { x: p.x, y: p.y, width: clamp(node.offsetWidth / area.width, .01, 1 - p.x), height: clamp(node.offsetHeight / area.height, .01, 1 - p.y) }; } state.dragging = null; };
  node.addEventListener('pointerup', finish); node.addEventListener('pointercancel', finish); node.addEventListener('lostpointercapture', finish);
}

function selectTab(tab) { state.activeTab = tab; $$('.tab').forEach((item) => item.classList.toggle('active', item.dataset.tab === tab)); $$('.tab-page').forEach((page) => page.classList.toggle('active', page.dataset.page === tab)); redraw(); }
async function uploadAsset(input, kind) { const file = input.files?.[0]; if (!file) return; const data = new FormData(); data.append('file', file); data.append('kind', kind); data.append('project_id', state.projectId); const response = await fetch('/api/assets', { method: 'POST', body: data }); const body = await response.json(); if (!response.ok) { alert(body.detail || 'ဖိုင်တင်မရပါ'); return; } state.uploaded[kind] = body.path; input.closest('label').classList.add('uploaded'); if (kind === 'logo') { if (state.logoUrl) URL.revokeObjectURL(state.logoUrl); state.logoUrl = URL.createObjectURL(file); redraw(); } }
async function uploadVideo(file) { const form = new FormData(); form.append('file', file); form.append('project_id', state.projectId); $('#sessionStatus').textContent = 'Video တင်နေပါတယ်…'; const response = await fetch('/api/video', { method: 'POST', body: form }); const body = await response.json(); if (!response.ok) throw new Error(body.detail || 'Video တင်မရပါ'); state.dimensions = body; $('#videoName').textContent = file.name; $('#videoMeta').textContent = `${(file.size / 1024 / 1024).toFixed(1)} MB · ${Math.round(body.duration)} sec · Ready`; $('#sessionStatus').textContent = 'Ready to edit'; $('#exportButton').disabled = false; }
function selectFile(event) { const file = event.target.files?.[0]; if (!file) return; if (file.size > 200 * 1024 * 1024) { alert('200MB ထက်မကျော်ပါစေနဲ့'); return; } state.video = file; if (state.videoUrl) URL.revokeObjectURL(state.videoUrl); state.videoUrl = URL.createObjectURL(file); video.src = state.videoUrl; $('#emptyState').classList.add('hidden'); stage.classList.remove('hidden'); uploadVideo(file).catch((error) => { $('#sessionStatus').textContent = error.message; alert(error.message); }); }
function setJob(job) { const progress = +job.progress || 0; $('#jobProgress').style.width = `${progress}%`; $('#jobPercent').textContent = `${progress}%`; $('#jobTitle').textContent = job.message || 'Final Video လုပ်နေပါတယ်'; const order = ['upload', 'script', 'voice', 'render']; const active = order.indexOf(job.step); $$('#jobSteps li').forEach((li, index) => li.className = index < active ? 'done' : index === active ? 'active' : ''); if (job.status === 'done') { $('#downloadButton').href = job.download_url; $('#downloadButton').classList.remove('hidden'); $('#cancelJob').classList.add('hidden'); $('#jobTitle').textContent = 'Final MP4 အဆင်သင့်ပါပြီ'; } if (['error', 'cancelled'].includes(job.status)) { $('#jobError').textContent = job.error || job.message || 'Video ထုတ်မရပါ'; $('#jobError').classList.remove('hidden'); $('#cancelJob').classList.add('hidden'); } }
async function exportVideo() { if (!state.video) return; if (!state.accessToken) { window.location.assign('/login'); return; } if (requiresUserKey() && !savedKey()) { $('#keySheet').classList.remove('hidden'); return; } const card = $('#jobCard'); card.classList.remove('hidden'); $('#jobError').classList.add('hidden'); $('#downloadButton').classList.add('hidden'); $('#cancelJob').classList.remove('hidden'); $('#exportButton').disabled = true; try { const response = await fetch('/api/jobs', { method: 'POST', headers: { 'Content-Type': 'application/json', ...authHeaders() }, body: JSON.stringify({ project_id: state.projectId, settings: settings(), simple_api_key: savedKey() }) }); const job = await response.json(); if (!response.ok) throw new Error(job.detail || 'Export မစနိုင်ပါ'); state.jobId = job.id; setJob(job); pollJob(); } catch (error) { $('#jobError').textContent = error.message; $('#jobError').classList.remove('hidden'); $('#exportButton').disabled = false; } }
async function pollJob() { if (!state.jobId) return; const response = await fetch(`/api/jobs/${state.jobId}`); const job = await response.json(); setJob(job); if (['queued', 'running'].includes(job.status)) window.setTimeout(pollJob, 1500); else $('#exportButton').disabled = false; }

function planTitle(member) { if (!member) return 'Account ဝင်မယ်'; if (member.is_admin) return 'Owner Pro'; if (member.plan === 'simple') return `Simple Trial · ${member.trial_days_remaining || 0} ရက်`; if (member.plan === 'pro') return member.tier === 'simple_vip' ? 'Simple VIP' : 'VIP'; return member.trial_expired ? 'Trial ကုန်ပြီ' : 'Plan ဝယ်မယ်'; }
function applyVoiceOptions(member) { const isProTier = member?.is_admin || member?.tier === 'vip'; $$('.pro-ms-voice').forEach((option) => { option.hidden = !isProTier; }); if (!isProTier && $('#voice').selectedOptions[0]?.classList.contains('pro-ms-voice')) $('#voice').value = 'Nilar'; }
function setMembership(member) { state.member = member || null; applyVoiceOptions(member); const title = planTitle(member); $('#planButton').textContent = title; $('#ownerButton').classList.toggle('hidden', !member?.is_admin); $('#sessionStatus').textContent = member ? `${title} · ${member.email}` : 'Account ဝင်ပြီးမှ Export လုပ်ပါ'; $('#keySheetHint').textContent = 'Script နဲ့ အသံအတွက် API Key ထည့်ပါ။ Browser session ထဲတွင်သာခဏသိမ်းမယ်။'; }
async function refreshMembership() { if (!state.accessToken) { window.location.replace('/login'); return; } const response = await fetch('/api/membership', { headers: authHeaders() }); if (!response.ok) { window.location.replace('/login'); return; } setMembership(await response.json()); }
async function loadPlans() { if (state.catalog) return state.catalog; const response = await fetch('/api/plans'); state.catalog = await response.json(); return state.catalog; }
function updateDestination() { const item = state.catalog?.destinations?.[$('#paymentMethod').value]; $('#paymentDestination').textContent = item ? `${$('#paymentMethod').value} · ${item.phone} · ${item.account_name}` : ''; }
function openPayment(kind, key) { if (kind !== 'plan') return; const items = state.catalog?.plans; const offer = items?.find((item) => item.key === key); if (!offer) return; state.selectedPayment = { kind: 'plan', key, offer }; $('#paymentSelected').textContent = `${offer.label} · ${mmk(offer.price)} · ${offer.description}`; $('#paymentForm').classList.remove('hidden'); $('#paymentNote').textContent = ''; $('#paymentForm').scrollIntoView({ behavior: 'smooth', block: 'nearest' }); updateDestination(); }
function renderOffers(catalog) { const plans = (catalog.plans || []).map((item) => `<article class="offer"><div><strong>${escapeHtml(item.label)}</strong><p>${escapeHtml(item.description)}</p><b>${mmk(item.price)} / 30 ရက်</b></div><button data-kind="plan" data-key="${escapeHtml(item.key)}" type="button">ရွေးမယ်</button></article>`).join(''); $('#planList').innerHTML = `<p class="plan-section-title">Monthly Plans</p>${plans}`; }
async function openPlanSheet() { if (!state.accessToken) { window.location.assign('/login'); return; } $('#planSheet').classList.remove('hidden'); try { const catalog = await loadPlans(); renderOffers(catalog); const pending = state.member?.pending_payment ? ' · Payment စစ်နေပါတယ်' : ''; $('#accountStatus').textContent = `${planTitle(state.member)}${pending} · Video ကိုစိတ်ကြိုက်ထုတ်လို့ရပါတယ်`; updateDestination(); } catch { $('#accountStatus').textContent = 'Plan အချက်အလက်မရသေးပါ'; } }
async function submitPayment() { if (!state.selectedPayment) return; const transactionId = $('#transactionId').value.trim(); if (transactionId.length < 4) { $('#paymentNote').textContent = 'Transaction ID မှန်မှန်ထည့်ပါ'; return; } const form = new FormData(); form.append('kind', state.selectedPayment.kind); form.append('offer_key', state.selectedPayment.key); form.append('payment_method', $('#paymentMethod').value); form.append('transaction_id', transactionId); const receipt = $('#receiptInput').files?.[0]; if (receipt) form.append('receipt', receipt); $('#submitPayment').disabled = true; $('#paymentNote').textContent = 'ပို့နေပါတယ်…'; try { const response = await fetch('/api/payments', { method: 'POST', headers: authHeaders(), body: form }); const body = await response.json(); if (!response.ok) throw new Error(body.detail || 'ငွေလွှဲအချက်အလက်မပို့နိုင်ပါ'); $('#paymentNote').textContent = body.message; $('#paymentForm').classList.add('hidden'); await refreshMembership(); } catch (error) { $('#paymentNote').textContent = error.message; } finally { $('#submitPayment').disabled = false; } }
async function initializeAuth() { try { const config = await (await fetch('/api/auth-config')).json(); if (config.enabled !== 'true' || !window.supabase) { $('#sessionStatus').textContent = 'Account Database setting မပြည့်သေးပါ'; return; } state.auth = window.supabase.createClient(config.url, config.anon_key); const { data: { session } } = await state.auth.auth.getSession(); state.accessToken = session?.access_token || ''; if (!state.accessToken || !await bridgeSession()) { window.location.replace('/login'); return; } await refreshMembership(); state.auth.auth.onAuthStateChange(async (_event, sessionNow) => { state.accessToken = sessionNow?.access_token || ''; if (!state.accessToken) { await fetch('/api/browser-session', { method: 'DELETE' }); window.location.replace('/login'); } else if (await bridgeSession()) refreshMembership(); }); } catch { $('#sessionStatus').textContent = 'Account စစ်မရသေးပါ။ ခဏနောက်ပြန်စမ်းပါ'; } }

$$('.tab').forEach((button) => button.addEventListener('click', () => selectTab(button.dataset.tab)));
$('#videoInput').addEventListener('change', selectFile); $('#logoInput').addEventListener('change', (event) => uploadAsset(event.target, 'logo')); $('#musicInput').addEventListener('change', (event) => uploadAsset(event.target, 'music'));
$('#addBlur').addEventListener('click', () => { state.masks.push({ x: .32, y: .3, width: .3, height: .16 }); $('#blurEnabled').checked = true; redraw(); });
['subtitleEnabled', 'blurEnabled', 'subtitleText', 'subtitleFont', 'subtitleColor', 'subtitleOutline', 'subtitleBackground', 'autoZoom', 'mirror', 'colorFilter', 'backgroundBlur', 'pitchAlter', 'logoEnabled', 'logoText', 'aspect', 'quality', 'recapType', 'originalAudio', 'voice', 'language', 'tone'].forEach((id) => ['input', 'change'].forEach((event) => $(`#${id}`).addEventListener(event, redraw)));
[['subtitleSize', '#subtitleSizeValue'], ['subtitleOpacity', '#subtitleOpacityValue'], ['subtitleX', '#subtitleXValue'], ['subtitleY', '#subtitleYValue'], ['blurStrength', '#blurStrengthValue'], ['musicVolume', '#musicVolumeValue'], ['duration', '#durationValue'], ['logoSize', '#logoSizeValue'], ['logoX', '#logoXValue'], ['logoY', '#logoYValue']].forEach(([input, target]) => $(`#${input}`).addEventListener('input', () => { output($(`#${input}`), target, input === 'duration' ? ' sec' : ''); redraw(); }));
video.addEventListener('loadedmetadata', () => { redraw(); requestAnimationFrame(redraw); window.setTimeout(redraw, 50); }); video.addEventListener('loadeddata', redraw); window.addEventListener('resize', redraw);
$('#exportButton').addEventListener('click', exportVideo); $('#keyButton').addEventListener('click', () => $('#keySheet').classList.remove('hidden')); $('#cancelJob').addEventListener('click', () => fetch(`/api/jobs/${state.jobId}/cancel`, { method: 'POST' })); $('#saveKey').addEventListener('click', window.oneTeamSaveKey); $('#closeKeySheet').addEventListener('click', () => $('#keySheet').classList.add('hidden')); $('#planButton').addEventListener('click', openPlanSheet); $('#closePlanSheet').addEventListener('click', () => $('#planSheet').classList.add('hidden')); $('#ownerButton').addEventListener('click', () => window.location.assign('/owner')); $('#paymentMethod').addEventListener('change', updateDestination); $('#planList').addEventListener('click', (event) => { const button = event.target.closest('button[data-kind]'); if (button) openPayment(button.dataset.kind, button.dataset.key); }); $('#submitPayment').addEventListener('click', submitPayment);
window.setTimeout(() => void initializeAuth(), 0);

const $ = (selector) => document.querySelector(selector);
let auth;
let accessToken = '';

function headers() { 
  return { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' }; 
}

function escapeHtml(value) { 
  const node = document.createElement('span'); 
  node.textContent = String(value || ''); 
  return node.innerHTML; 
}

async function fetchJson(url, options = {}) { 
  const response = await fetch(url, { ...options, headers: { ...headers(), ...(options.headers || {}) } }); 
  const body = await response.json(); 
  if (!response.ok) throw new Error(body.detail || 'စနစ်မရသေးပါ'); 
  return body; 
}

function renderPayments(payments) {
  $('#paymentQueue').innerHTML = payments.length ? payments.map((item) => `
    <article class="payment-item">
      <div>
        <strong>${escapeHtml(item.requested_tier || item.request_kind || 'Plan')}</strong>
        <p>${escapeHtml(item.payment_method)} · ${Number(item.amount_mmk || 0).toLocaleString()} ကျပ် · ${escapeHtml(item.transaction_id)}</p>
        <small>${escapeHtml(item.google_subject)}</small>
        ${item.receipt_url ? `<a target="_blank" rel="noopener" href="${escapeHtml(item.receipt_url)}">Receipt ပုံကြည့်မယ်</a>` : '<small>Receipt ပုံမတင်ထားပါ</small>'}
      </div>
      <div class="payment-actions">
        <button data-action="approve" data-id="${Number(item.id)}" type="button">Approve</button>
        <button data-action="reject" data-id="${Number(item.id)}" type="button">Reject</button>
      </div>
    </article>`).join('') : '<p class="help-copy">စစ်ရန် Payment မရှိသေးပါ</p>';
}

async function loadOverview() {
  try { 
    const data = await fetchJson('/api/owner/overview'); 
    $('#vipCount').textContent = data.active_vip_count; 
    $('#simpleCount').textContent = data.active_simple_count; 
    $('#pendingCount').textContent = data.pending_payment_count; 
    $('#tierCount').textContent = Object.entries(data.active_by_tier || {}).map(([key, value]) => `${key}: ${value} ယောက်`).join(' · ') || 'VIP မရှိသေးပါ'; 
    const usage = data.usage_by_plan || {}; 
    $('#usageCount').textContent = `Simple: ${usage.simple?.success || 0} ထုတ် · Pro: ${usage.pro?.success || 0} ထုတ်`; 
    $('#usageFail').textContent = `Simple Fail: ${usage.simple?.failed || 0} · Pro Fail: ${usage.pro?.failed || 0}`; 
    $('#quotaSubject').dataset.members = JSON.stringify(data.members || []); 
    renderPayments(data.payments || []); 
  } catch (error) { 
    $('#paymentQueue').innerHTML = `<p class="job-error">${escapeHtml(error.message)}</p>`; 
  }
}

async function review(event) {
  const button = event.target.closest('button[data-action]'); 
  if (!button) return;
  const action = button.dataset.action; 
  const requestId = button.dataset.id;
  const question = action === 'approve' ? 'ငွေလွှဲကိုစစ်ပြီးပါပြီလား? Plan ကိုတကယ်ဖွင့်မယ်။' : 'ဒီငွေလွှဲတောင်းဆိုမှုကိုပယ်ဖျက်မလား?';
  if (!window.confirm(question)) return;
  const note = window.prompt('Owner Note (မရေးလည်းရ):', '') ?? '';
  button.disabled = true;
  try { 
    await fetchJson(`/api/owner/payments/${requestId}/${action}`, { method: 'POST', body: JSON.stringify({ note }) }); 
    await loadOverview(); 
  } catch (error) { 
    alert(error.message); 
    button.disabled = false; 
  }
}

async function setup() {
  try { 
    const config = await (await fetch('/api/auth-config')).json(); 
    if (config.enabled !== 'true' || !window.supabase) throw new Error('Account Database setting မပြည့်သေးပါ'); 
    auth = window.supabase.createClient(config.url, config.anon_key); 
    const { data: { session } } = await auth.auth.getSession(); 
    accessToken = session?.access_token || ''; 
    if (!accessToken) { 
      window.location.replace('/login'); 
      return; 
    } 
    const bridge = await fetch('/api/browser-session', { method: 'POST', headers: { Authorization: `Bearer ${accessToken}` } }); 
    if (!bridge.ok) { 
      window.location.replace('/login'); 
      return; 
    } 
    await loadOverview(); 
  } catch (error) { 
    $('#paymentQueue').innerHTML = `<p class="job-error">${escapeHtml(error.message)}</p>`; 
  } 
}

async function grantQuota() { 
  const subject = $('#quotaSubject').value.trim(); 
  const extra = Number($('#quotaExtra').value) || 0; 
  const days = Number($('#quotaDays').value) || 0; 
  const repairDays = Number($('#repairDays').value) || 0; 
  
  if (!subject) { 
    $('#quotaNote').textContent = 'Account ID ကို ထည့်သွင်းပါ'; 
    $('#quotaNote').style.color = "red";
    return; 
  } 
  
  try { 
    $('#quotaNote').textContent = 'ထည့်သွင်းနေပါသည်...';
    $('#quotaNote').style.color = "gray";
    
    await fetchJson('/api/owner/quota-override', { 
      method: 'POST', 
      body: JSON.stringify({ google_subject: subject, extra_videos: extra, days, repair_days: repairDays }) 
    }); 
    
    $('#quotaNote').textContent = `✅ ထည့်ပြီးပါပြီ (အပို ${extra} ပုဒ်၊ quota ${days} ရက်၊ repair ${repairDays} ရက်)`; 
    $('#quotaNote').style.color = "green";
    
    // အောင်မြင်လျှင် အကွက်များ ပြန်ရှင်းမည်
    $('#quotaSubject').value = '';
    $('#quotaExtra').value = '0';
    $('#quotaDays').value = '0';
    $('#repairDays').value = '0';
    
    await loadOverview(); 
  } catch (error) { 
    $('#quotaNote').textContent = error.message; 
    $('#quotaNote').style.color = "red";
  } 
}

$('#paymentQueue').addEventListener('click', review); 
$('#refreshOwner').addEventListener('click', loadOverview); 
$('#grantQuota').addEventListener('click', grantQuota); 
window.setTimeout(setup, 0);